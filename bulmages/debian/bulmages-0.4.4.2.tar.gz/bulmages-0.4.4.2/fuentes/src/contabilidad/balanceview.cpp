/***************************************************************************
                          balanceview.cpp  -  description
                             -------------------
    begin                : s�b abr 26 2003
    copyright            : (C) 2003 by Tomeu Borr�s Riera
    email                : tborras@conetxia.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "balanceview.h"
#include "empresa.h"
#include "calendario.h"

#include <qwidget.h>
#include <qlineedit.h>
#include <qdatetimeedit.h>
#include <qfiledialog.h>
#include <qtable.h>
#include <qtoolbutton.h>

#include "balanceprintview.h"


// Incluimos las imagenes que catalogan los tipos de cuentas.
#include "images/cactivo.xpm"
#include "images/cpasivo.xpm"
#include "images/cneto.xpm"
#include "images/cingresos.xpm"
#include "images/cgastos.xpm"

#include <qstring.h>

#define CUENTA           0
#define DENOMINACION     1
#define SALDO_ANT        2
#define DEBE            3
#define HABER           4
#define SALDO           5
#define DEBEEJ				6
#define HABEREJ			7
#define SALDOEJ			8


balanceview::balanceview(empresa *emp, QWidget *parent, const char *name, int  ) : balancedlg(parent,name) {
   fprintf(stderr,"Inicializacion de balanceview\n");
	empresaactual = emp;
   conexionbase = empresaactual->bdempresa();
   numdigitos = empresaactual->numdigitosempresa();
   // Hacemos la carga de los centros de coste. Rellenamos el combobox correspondiente.
   cargacostes();


   delete listado1;
   listado = new QTable1(this,"listado");
   listado->setNumRows( 0 );
   listado->setNumCols( 0 );
   listado->setSelectionMode( QTable::SingleRow );
   listado->setSorting( TRUE );
   listado->setSelectionMode( QTable::SingleRow );
   balancedlgLayout->addWidget( listado, 1, 0 );
   listado->setColumnMovingEnabled( TRUE );
   listado->setNumCols(9);
   listado->horizontalHeader()->setLabel( CUENTA, tr( "Cuenta" ) );
   listado->horizontalHeader()->setLabel( DENOMINACION, tr( "Denominacion" ) );
   listado->horizontalHeader()->setLabel( SALDO_ANT, tr( "Saldo Ant." ) );
   listado->horizontalHeader()->setLabel( DEBE, tr( "Debe Periodo" ) );
   listado->horizontalHeader()->setLabel( HABER, tr( "Haber Periodo" ) );
   listado->horizontalHeader()->setLabel( SALDO, tr( "Saldo Periodo" ) );
   listado->horizontalHeader()->setLabel( DEBEEJ, tr("Debe Ejercicio") );
   listado->horizontalHeader()->setLabel( HABEREJ, tr("Haber Ejercicio") );
   listado->horizontalHeader()->setLabel( SALDOEJ, tr("Saldo Ejercicio") );

   listado->setColumnWidth(CUENTA,75);
   listado->setColumnWidth(DENOMINACION,300);
   listado->setColumnWidth(SALDO_ANT,75);
   listado->setColumnWidth(DEBE,75);
   listado->setColumnWidth(HABER,75);
   listado->setColumnWidth(SALDO,100);
//   listado->setPaletteBackgroundColor(QColor(150,230,230));
    // Establecemos el color de fondo del extracto. El valor lo tiene la clase configuracion que es global.
    listado->setPaletteBackgroundColor(confpr->valor(CONF_BG_BALANCE).c_str());
   
   listado->setReadOnly(TRUE);


   // Inicializamos la tabla de nivel
   combonivel->insertItem("2",0);
   combonivel->insertItem("3",1);
   combonivel->insertItem("4",2);
   combonivel->insertItem("5",3);
   combonivel->insertItem("6",4);
   combonivel->insertItem("7",5);
   
   connect( listado, SIGNAL( contextMenuRequested(int,int,const QPoint&) ), this, SLOT( contextmenu(int,int,const QPoint&) ) );


   // Iniciamos los componentes de la fecha para que al principio aparezcan
   // Como el a�o inicial.
   QString cadena;
   cadena.sprintf("%2.2d/%2.2d/%4.4d",1, 1, QDate::currentDate().year());
   fechainicial1->setText(cadena);
   cadena.sprintf("%2.2d/%2.2d/%4.4d",31, 12, QDate::currentDate().year());
   fechafinal1->setText(cadena);

   fprintf(stderr,"FIN de Inicializacion de balanceview\n");

}// end balanceview

balanceview::~balanceview(){
}




void balanceview::inicializa2(intapunts3view *inta, diarioview1 *diar, extractoview1 *extract) {
   introapunts = inta;
  diario = diar;
  extracto = extract;
}// end inicializa2


void balanceview::cargacostes() {
   // Hacemos la carga de los centros de coste. Rellenamos el combobox correspondiente.
   combocoste->clear();
   QString query="SELECT * FROM c_coste ORDER BY nombre";
   conexionbase->begin();
   cursor2 *cursorcoste = conexionbase->cargacursor(query,"costes");
   conexionbase->commit();
   combocoste->insertItem("--",0);
   ccostes[0]=0;
   int i=1;
   while (!cursorcoste->eof()) {
      combocoste->insertItem(cursorcoste->valor(2),-1);
      ccostes[i++] = atoi(cursorcoste->valor(0));
      cursorcoste->siguienteregistro();
   }// end while
   delete cursorcoste;
}// end cargacostes



/**********************************************************************************
 Esta funcion inicializa la ventana de extracto con los mismos datos
 que la ventana de balance, cuentas, fechas y centros de coste
 y pone la ventan de estracto como la ventana principal.
 De esta forma cuando se pulsa sobre el boton extracto estando en la de balance
 se cambia a la ventana de extracto de la forma correcta.
 **********************************************************************************/
// Si el parametro pasado es un:
// 0 -> del dia actual
// 1 -> del mes actual
// 2 -> del a�o actual
void balanceview::boton_extracto1(int tipo) {
	QDate fecha1, fecha2, fechaact, fechaact1;
	if(!fechainicial1->text().isEmpty()) {
        fechaact = normalizafecha(fechainicial1->text());
        fechaact1 =normalizafecha(fechafinal1->text());
		switch(tipo) {
			case 0:
				fecha1.setYMD(fechaact.year(), fechaact.month(),fechaact.day());
				fecha2.setYMD(fechaact1.year(), fechaact1.month(), fechaact1.day());
			break;
			case 1:
				fecha1.setYMD(fechaact.year(), fechaact.month(),1);
				fecha2.setYMD(fechaact.year(), fechaact.month(), fechaact.daysInMonth());
			break;
			case 2:
				fecha1.setYMD(fechaact.year(), 1,1);
				fecha2.setYMD(fechaact.year(), 12, 31);
			break;
		}// end switch
 		  extracto->inicializa1( listado->text(listado->currentRow(), CUENTA), listado->text(listado->currentRow(), CUENTA),fecha1.toString("dd/MM/yyyy"), fecha2.toString("dd/MM/yyyy"),  ccostes[combocoste->currentItem()]);
   }// end if
   extracto->accept();
   empresaactual->libromayor();
}// end boton_extracto1




// Si el parametro pasado es un:
// 0 -> del dia actual
// 1 -> del mes actual
// 2 -> del a�o actual
void balanceview::boton_diario1(int tipo) {
	QDate fecha1, fecha2, fechaact, fechaact1;
	if(!fechainicial1->text().isEmpty()) {
        fechaact = normalizafecha(fechainicial1->text());
        fechaact1 =normalizafecha(fechafinal1->text());
		switch(tipo) {
			case 0:
				fecha1.setYMD(fechaact.year(), fechaact.month(),fechaact.day());
				fecha2.setYMD(fechaact1.year(), fechaact1.month(), fechaact1.day());
			break;
			case 1:
				fecha1.setYMD(fechaact.year(), fechaact.month(),1);
				fecha2.setYMD(fechaact.year(), fechaact.month(), fechaact.daysInMonth());
			break;
			case 2:
				fecha1.setYMD(fechaact.year(), 1,1);
				fecha2.setYMD(fechaact.year(), 12, 31);
			break;
		}// end switch
   	diario->inicializa1(fecha1.toString("dd/MM/yyyy"), fecha2.toString("dd/MM/yyyy"), 0);
   }// end if
   diario->accept();
   empresaactual->librodiario();
}// end boton_diario1




void balanceview::boton_asiento() {
  empresaactual->muestraapuntes1();
}// end if


/****************************************************************************

*****************************************************************************/
void balanceview::inicializa1(QString codinicial, QString codfinal, QString fecha1, QString fecha2, int idc_coste) {

/********************** Josep *********************/
  fprintf(stderr,"balanceview::inicializa1\n");
  codigoinicial->setText(codinicial);
  codigofinal->setText(codfinal);
  fechainicial1->setText(normalizafecha(fecha1).toString("dd/MM/yyyy"));
  fechafinal1->setText(normalizafecha(fecha2).toString("dd/MM/yyyy"));
  //string s1, s2, s3;

  // Establecemos el centro de coste correspondiente.
  int i=0;
  while (ccostes[i]!=idc_coste && i<100) i++;
  if (i<100) { combocoste->setCurrentItem(i); }

/**************************************************/
   
}// end if


void balanceview::presentar() {
      int j,num1;
      double tsaldoant=0, tdebe=0, thaber=0, tsaldo=0;
      QString query;
      cursor2 *cursorapt;
      QString finicial = fechainicial1->text();
      QString ffinal = fechafinal1->text();
      QString cinicial = codigoinicial->text();
      QString cfinal = codigofinal->text();
      
      QString ejercicio = ffinal.right(4);

      // Hacemos la consulta de los apuntes a listar en la base de datos.
      int idc_coste;
		idc_coste = ccostes[combocoste->currentItem()];

      // La consulta es compleja, requiere la creaci�n de una tabla temporal y de cierta mandanga por lo que puede
		// Causar problemas con el motor de base de datos.
		fprintf(stderr,"BALANCE: Empezamos a hacer la presentacion\n");
      conexionbase->begin();
/*      
		query.sprintf("CREATE TEMPORARY TABLE balancetemp AS SELECT cuenta.idcuenta, codigo, nivel(codigo) AS nivel, cuenta.descripcion, padre, tipocuenta ,debe, haber, tdebe, thaber,(tdebe-thaber) AS tsaldo, (debe-haber) AS saldo, adebe, ahaber, (adebe-ahaber) AS asaldo FROM cuenta LEFT JOIN (SELECT idcuenta, sum(debe) AS tdebe, sum(haber) AS thaber FROM apunte WHERE fecha >= '%s' AND fecha<= '%s' GROUP BY idcuenta) AS t1 ON t1.idcuenta = cuenta.idcuenta LEFT JOIN (SELECT idcuenta, sum(debe) AS adebe, sum(haber) AS ahaber FROM apunte WHERE fecha < '%s' GROUP BY idcuenta) AS t2 ON t2.idcuenta = cuenta.idcuenta", finicial.ascii(), ffinal.ascii(), finicial.ascii() );
*/		
		query= "CREATE TEMPORARY TABLE balancetemp AS SELECT cuenta.idcuenta, codigo, nivel(codigo) AS nivel, cuenta.descripcion, padre, tipocuenta ,debe, haber, tdebe, thaber,(tdebe-thaber) AS tsaldo, (debe-haber) AS saldo, adebe, ahaber, (adebe-ahaber) AS asaldo, ejdebe, ejhaber, (ejdebe-ejhaber) AS ejsaldo FROM cuenta";
		query += " LEFT JOIN (SELECT idcuenta, sum(debe) AS tdebe, sum(haber) AS thaber FROM apunte WHERE fecha >= '"+finicial+"' AND fecha<= '"+ffinal+"' GROUP BY idcuenta) AS t1 ON t1.idcuenta = cuenta.idcuenta";
		query += " LEFT JOIN (SELECT idcuenta, sum(debe) AS adebe, sum(haber) AS ahaber FROM apunte WHERE fecha < '"+finicial+"' GROUP BY idcuenta) AS t2 ON t2.idcuenta = cuenta.idcuenta";
		query += " LEFT JOIN (SELECT idcuenta, sum(debe) AS ejdebe, sum(haber) AS ejhaber FROM apunte WHERE EXTRACT (YEAR FROM fecha) = '"+ejercicio+"' GROUP BY idcuenta) AS t3 ON t3.idcuenta = cuenta.idcuenta";
		
		fprintf(stderr,"%s\n",query.ascii());
      conexionbase->ejecuta(query);
      query.sprintf("UPDATE balancetemp SET padre=0 WHERE padre ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf("DELETE FROM balancetemp WHERE debe=0 AND haber =0");
      conexionbase->ejecuta(query);

      // Vamos a implementar el tema del c�digo
      if (cinicial != "") {
         query.sprintf("DELETE FROM balancetemp WHERE codigo < '%s'",cinicial.ascii());
         conexionbase->ejecuta(query);
      }// end if
      if (cfinal != "") {
         query.sprintf("DELETE FROM balancetemp WHERE codigo > '%s'",cfinal.ascii());
         conexionbase->ejecuta(query);
      }// end if      

      // Para evitar problemas con los nulls hacemos algunos updates
      query.sprintf("UPDATE balancetemp SET tsaldo=0 WHERE tsaldo ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf("UPDATE balancetemp SET tdebe=0 WHERE tdebe ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf("UPDATE balancetemp SET thaber=0 WHERE thaber ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf("UPDATE balancetemp SET asaldo=0 WHERE asaldo ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf("UPDATE balancetemp SET ejsaldo=0 WHERE ejsaldo ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf("UPDATE balancetemp SET ejdebe=0 WHERE ejdebe ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf("UPDATE balancetemp SET ejhaber=0 WHERE ejhaber ISNULL");
      conexionbase->ejecuta(query);
      query.sprintf( "SELECT idcuenta FROM balancetemp ORDER BY padre DESC");
      cursorapt = conexionbase->cargacursor(query,"Balance1view");
      while (!cursorapt->eof())  {
         query.sprintf("SELECT * FROM balancetemp WHERE idcuenta=%s",cursorapt->valor("idcuenta").ascii());
         cursor2 *mycur = conexionbase->cargacursor(query,"cursorrefresco");
         if (!mycur->eof()) {
            query.sprintf("UPDATE balancetemp SET tsaldo = tsaldo + (%2.2f), tdebe = tdebe + (%2.2f), thaber = thaber +(%2.2f), asaldo= asaldo+(%2.2f), ejdebe = ejdebe + (%2.2f), ejhaber = ejhaber +(%2.2f), ejsaldo = ejsaldo + (%2.2f) WHERE idcuenta = %d",atof(mycur->valor("tsaldo").ascii()), atof(mycur->valor("tdebe").ascii()), atof(mycur->valor("thaber").ascii()),atof(mycur->valor("asaldo").ascii()),atof(mycur->valor("ejdebe").ascii()), atof(mycur->valor("ejhaber").ascii()), 
	    atof(mycur->valor("ejsaldo").ascii()),  atoi(mycur->valor("padre").ascii()));
            conexionbase->ejecuta(query);
         }// end if
         delete mycur;
         cursorapt->siguienteregistro();
      }// end while
      delete cursorapt;

      conexionbase->commit();
      conexionbase->begin();
      
      
      // Borramos todo lo que no es de este nivel
      query.sprintf("DELETE FROM balancetemp where nivel(codigo)>%s",combonivel->text(combonivel->currentItem()).ascii());
      conexionbase->ejecuta(query);
      

      //Borramos todo lo que tiene un hijo en el balance
      query.sprintf("DELETE FROM balancetemp WHERE idcuenta IN (SELECT padre FROM balancetemp)");
      conexionbase->ejecuta(query);
      query.sprintf("SELECT * FROM balancetemp WHERE debe <> 0  OR haber <> 0 ORDER BY codigo");
      cursorapt = conexionbase->cargacursor(query,"mycursor");
      
      // Calculamos cuantos registros van a crearse y dimensionamos la tabla.
      num1 = cursorapt->numregistros();
      listado->setNumRows(0);
      listado->setNumRows(num1);
      j=0;
      while (!cursorapt->eof()) {
         // Acumulamos los totales para al final poder escribirlos
         tsaldoant += atof(cursorapt->valor("asaldo").ascii());
         tsaldo += atof(cursorapt->valor("tsaldo").ascii());
         tdebe += atof(cursorapt->valor("tdebe").ascii());
         thaber += atof(cursorapt->valor("thaber").ascii());
      
         // Hacemos la insercion de los campos en la tabla.
         listado->setText(j,CUENTA,cursorapt->valor("codigo"));
         listado->setText(j,DENOMINACION,cursorapt->valor("descripcion"));
         listado->setText(j,SALDO_ANT,QString::number(atof(cursorapt->valor("asaldo").ascii()),'f',2));
         listado->setText(j,DEBE,QString::number(atof(cursorapt->valor("tdebe").ascii()),'f',2));
         listado->setText(j,HABER,QString::number(atof(cursorapt->valor("thaber").ascii()),'f',2));
         listado->setText(j,SALDO,QString::number(atof(cursorapt->valor("tsaldo").ascii()),'f',2));
         listado->setText(j, DEBEEJ,QString::number(atof(cursorapt->valor("ejdebe").ascii()),'f',2));
         listado->setText(j, HABEREJ,QString::number(atof(cursorapt->valor("ejhaber").ascii()),'f',2));
         listado->setText(j, SALDOEJ,QString::number(atof(cursorapt->valor("ejsaldo").ascii()),'f',2));


         // Ponemos los iconos para que la cosa parezca mas guay.
         if (cursorapt->valor("tipocuenta") == "1")
            listado->setPixmap(j,CUENTA, QPixmap(cactivo));
         else if (cursorapt->valor("tipocuenta") == "2")
            listado->setPixmap(j,CUENTA, QPixmap(cpasivo));
         else if (cursorapt->valor("tipocuenta") == "3")
            listado->setPixmap(j,CUENTA, QPixmap(cneto));
         else if (cursorapt->valor("tipocuenta") == "4")
            listado->setPixmap(j,CUENTA, QPixmap(cingresos));
         else if (cursorapt->valor("tipocuenta") == "5")
            listado->setPixmap(j,CUENTA, QPixmap(cgastos));      

         // Calculamos la siguiente cuenta registro y finalizamos el bucle
         cursorapt->siguienteregistro();
         j++;
      }// end while

      // Vaciamos el cursor de la base de datos.
      delete cursorapt;

      query.sprintf("DROP TABLE balancetemp");
      conexionbase->ejecuta(query);
      conexionbase->commit();
      
      
      // Hacemos la actualizacion de los saldos totales
      totalsaldoant->setText(QString::number(tsaldoant,'f',2));
      totaldebe->setText(QString::number(tdebe,'f',2));
      totalhaber->setText(QString::number(thaber,'f',2));
      totalsaldo->setText(QString::number(tsaldo,'f',2));
}// end presentar


void balanceview::accept() {
  presentar();
}// end accept


void balanceview::return_fechafinal() {
  fechafinal1->setText(normalizafecha(fechafinal1->text()).toString("dd/MM/yyyy"));
  accept();  
}// end return_fechafinal


void balanceview::return_fechainicial() {
  fechainicial1->setText(normalizafecha(fechainicial1->text()).toString("dd/MM/yyyy"));
}// end return_fechainicial


void balanceview::return_codigoinicial() {
   QString cad = codigoinicial->text();
   if (cad != "") {
      cad = extiendecodigo(cad,numdigitos);
      conexionbase->begin();
      cursor2 *cursorcta = conexionbase->cargacuenta(0,cad );
      conexionbase->commit();
      int num = cursorcta->numregistros();
      if (num >0) {
         codigoinicial->setText(cursorcta->valor(1));
         codigofinal->selectAll();
         // Simulamos la pulsacion del boton recargar.
         accept();
      } else {
        codigoinicial->selectAll();
        codigoinicial->setFocus();
      }// end if
      delete cursorcta;
   }// end if
}// end return_codigoinicial


void balanceview::return_codigofinal() {
   QString cad = codigofinal->text();
   if (cad != "") {
      cad = extiendecodigo(cad,numdigitos);
      conexionbase->begin();
      cursor2 *cursorcta = conexionbase->cargacuenta(0, cad );
      conexionbase->commit();
      int num = cursorcta->numregistros();
      if (num >0) {
         codigofinal->setText(cursorcta->valor(1));
      } else {
        codigofinal->selectAll();
        codigofinal->setFocus();
      }// end if
      delete cursorcta;
   }// end if
}// end return_codigofinal


void balanceview::boton_buscacuentainicial() {
   listcuentasview1 *listcuentas = new listcuentasview1(empresaactual);
   listcuentas->modo=1;
   listcuentas->inicializa();
   listcuentas->exec();
   codigoinicial->setText(listcuentas->codcuenta);
   delete listcuentas;
}// end boton_buscacuentainicial


void balanceview::boton_buscacuentafinal() {
   listcuentasview1 *listcuentas = new listcuentasview1(empresaactual);
   listcuentas->modo=1;
   listcuentas->inicializa();
   listcuentas->exec();
   codigofinal->setText(listcuentas->codcuenta);
   delete listcuentas;
}// end boton_buscacuentafinal


void balanceview::contextmenu(int row, int col, const QPoint &poin) {
   QPopupMenu *popup;
   int opcion;
   QString query   ;
   popup = new QPopupMenu;
        popup->insertItem(tr("Ver Extracto (Este dia)"),111);
        popup->insertItem(tr("Ver Extracto (Este mes)"),113);
        popup->insertItem(tr("Ver Extracto (Este a�o)"),114);
        popup->insertSeparator();
        popup->insertItem(tr("Ver Diario (Este dia)"),101);
        popup->insertItem(tr("Ver Diario (Este mes)"),103);
        popup->insertItem(tr("Ver Diario (Este a�o)"),104);
        
        // Si estamos sobre la columna del numero de cuenta a�adiremos opciones al menu.
        if (col == CUENTA) {
        		popup->insertItem(tr("Editar Cuenta"), 105);
        }// end if
   		opcion = popup->exec(poin);
		  switch(opcion) {
		  		case 101:
					boton_diario1(0);
				break;
				case 103:
					boton_diario1(1);
				break;
				case 104:
					boton_diario1(2);
				break;
				case 111:
					boton_extracto1(0);
				break;
				case 113:
					boton_extracto1(1);
				break;
				case 114:
					boton_extracto1(2);
		  }// end switch
   delete popup;
   
   // Para quitar el warning que se produce al compilar.
   row=0;
}// end contextmenu

void balanceview::nivelactivated (int nivel) {
   presentar();
   // Para evitar el warning al compilar
   nivel =0;
}// end nivelactivated1


void balanceview::boton_imprimir() {
   BalancePrintView * balan = new BalancePrintView(empresaactual,0,0);
	balan->inicializa(conexionbase);
	balan->inicializa1(codigoinicial->text(), codigofinal->text(), fechainicial1->text(), fechafinal1->text(), FALSE);
   balan->exec();
}// end boton_imprimir.


void balanceview::codigo_textChanged(const QString &texto) {
    QLineEdit *codigo = (QLineEdit *) sender();
    if (texto == "+") {
        // Hacemos aparecer la ventana de cuentas
        listcuentasview1 *listcuentas = new listcuentasview1(empresaactual);
        listcuentas->modo=1;
        listcuentas->inicializa();
        listcuentas->exec();
        codigo->setText(listcuentas->codcuenta);
        delete listcuentas;
    }// end if
}// end codigo_textChanged


// Cuando se ha pulsado una tecla sobre la fecha del extracto
// Se evalua si la pulsaci�n es un c�digo de control o es un digitos
// Para la introducci�n de fechas.
void balanceview::fecha_textChanged(const QString &texto) {
	QLineEdit *fecha = (QLineEdit *) sender();
    if (texto=="+") {
        QList<QDate> a;
        fecha->setText("");
        calendario *cal = new calendario(0,0);
        cal->exec();
        a = cal->dn->selectedDates();
        fecha->setText(a.first()->toString("dd/MM/yyyy"));
        delete cal;
    }// end if
    if (texto=="*")
        fecha->setText(QDate::currentDate().toString("dd/MM/yyyy") );
}// end fecha_textChanged

void balanceview::boton_fechainicial() {
   fechainicial1->setText("+");
   fechainicial1->selectAll();
   fechainicial1->setFocus();
}// end boton_fechainicial

// This function represents the slot tat executes wen the finaldate button in the balance is clicked.
void balanceview::boton_fechafinal() {
   fechafinal1->setText("+");
   fechafinal1->selectAll();
   fechafinal1->setFocus();
}// end boton_fechainicial


