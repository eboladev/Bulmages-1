--
-- PostgreSQL database dump
--

INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (1, 'CodCuenta', 'xxxxyyy');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (2, 'Amortizacion', 'Amortizacion');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (3, 'Cobro', 'Cobro');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (4, 'CIF', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (5, 'TipoIva', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (6, 'NombreVia', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (7, 'NumeroVia', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (8, 'Escalera', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (9, 'Piso', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (10, 'Puerta', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (11, 'CodPostal', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (12, 'Municipio', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (13, 'Provincia', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (14, 'Pais', '--');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (15, 'Tipo', 'BulmaCont');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (16, 'Ejercicio', '2004');
INSERT INTO configuracion (idconfiguracion, nombre, valor) VALUES (17, 'NombreEmpresa', 'Sin Definir');
