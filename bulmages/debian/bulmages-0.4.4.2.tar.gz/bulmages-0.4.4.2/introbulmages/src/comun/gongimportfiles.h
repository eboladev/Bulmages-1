#include <qfile.h>

int Contaplus2Fugit(QFile &fugitfile, QFile &subcuentas, QFile &asientos);

