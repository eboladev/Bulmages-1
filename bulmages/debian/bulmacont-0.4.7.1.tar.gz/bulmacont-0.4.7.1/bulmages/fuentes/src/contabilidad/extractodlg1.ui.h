/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/


void extractodlg1::accept()
{

}


void extractodlg1::boton_anterior()
{

}


void extractodlg1::boton_asiento()
{

}


void extractodlg1::boton_buscacuentafinal()
{

}


void extractodlg1::boton_buscacuentainicial()
{

}


void extractodlg1::boton_diario()
{

}


void extractodlg1::boton_fin()
{

}


void extractodlg1::boton_guardar()
{

}


void extractodlg1::boton_imprimir()
{

}


void extractodlg1::boton_inicio()
{

}


void extractodlg1::boton_siguiente()
{

}


void extractodlg1::return_fechafinal()
{

}


void extractodlg1::return_codigofinal()
{

}


void extractodlg1::return_codigoinicial()
{

}


void extractodlg1::return_fechainicial()
{

}


void extractodlg1::boton_casacion()
{

}


void extractodlg1::boton_guardarpunteo()
{

}


void extractodlg1::boton_cargarpunteos()
{

}


void extractodlg1::codigo_textChanged( const QString & )
{

}


void extractodlg1::fecha_textChanged( const QString & )
{

}


void extractodlg1::boton_fechainicial()
{

}


void extractodlg1::boton_fechafinal()
{

}


void extractodlg1::boton_borrapunteo()
{

}
