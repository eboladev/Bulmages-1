<!DOCTYPE TS><TS>
<context>
    <name>BModContabilidad</name>
    <message>
        <source>Cerrar...</source>
        <translation type="obsolete">Tancar...</translation>
    </message>
    <message>
        <source>Realmente deseas Salir?</source>
        <translation type="obsolete">Realment desitgeu Sortir?</translation>
    </message>
</context>
<context>
    <name>BalancePrintDlg</name>
    <message>
        <source>Datos Listado</source>
        <translation>Dades del Llistat</translation>
    </message>
    <message>
        <source>Centro de Coste</source>
        <translation type="obsolete">Centre de Cost</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation type="obsolete">Canal</translation>
    </message>
    <message>
        <source>Nivel de Cuentas</source>
        <translation>Nivell de Contes</translation>
    </message>
    <message>
        <source>Incluir niveles superiores.</source>
        <translation>Incloure nivells superiors.</translation>
    </message>
    <message>
        <source>Incluir resultados parciales</source>
        <translation>Incloure resultats parcials</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation>Data Final</translation>
    </message>
    <message encoding="UTF-8">
        <source>Código Inicial
</source>
        <translation>Codi Inicial
</translation>
    </message>
    <message encoding="UTF-8">
        <source>Código Final</source>
        <translation>Codi Final</translation>
    </message>
    <message>
        <source>buttonGroup1</source>
        <translation type="obsolete">botoGrup1</translation>
    </message>
    <message>
        <source>Texto Plano</source>
        <translation>Text Pla</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation>Imprimir</translation>
    </message>
    <message encoding="UTF-8">
        <source>Impresión del Balance</source>
        <translation type="obsolete">Impressió del Balanç</translation>
    </message>
    <message encoding="UTF-8">
        <source>Impresión del Balance de Sumas y Saldos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Formato</source>
        <translation type="unfinished">Format</translation>
    </message>
    <message>
        <source>Propietario</source>
        <translation type="unfinished">Propietari</translation>
    </message>
</context>
<context>
    <name>BalancePrintView</name>
    <message>
        <source>Balance</source>
        <comment>Informe: </comment>
        <translation type="unfinished">Balanç</translation>
    </message>
</context>
<context>
    <name>BbloqFecha</name>
    <message>
        <source>Diciembre </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noviembre </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Octubre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Septiembre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Agosto    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Julio     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Junio     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mayo      </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abril     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Marzo     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Febrero   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enero     </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bulmages01</name>
    <message>
        <source>Bulmages </source>
        <translation type="obsolete">BulmaGés</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Tallar</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Tallar</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>Cuts the selected section and puts it to the clipboard</source>
        <translation>Talla la selecció i la copia al portapapers</translation>
    </message>
    <message>
        <source>Cut

Cuts the selected section and puts it to the clipboard</source>
        <translation>Tallar

Talla la selecció i la copia al portapapers</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <source>Copies the selected section to the clipboard</source>
        <translation>Copia la selecció al portapapers</translation>
    </message>
    <message>
        <source>Copy

Copies the selected section to the clipboard</source>
        <translation>Copiar

Copia la selecció al portapapers</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Desfés</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Desfés</translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <source>Reverts the last editing action</source>
        <translation>Desfà la darrera acció</translation>
    </message>
    <message>
        <source>Undo

Reverts the last editing action</source>
        <translation>Desfés

Desfà la darrera acció</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Enganxa</translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <source>Pastes the clipboard contents to actual position</source>
        <translation>Enganxa el contingut del portapapers a la posició actual</translation>
    </message>
    <message>
        <source>Paste

Pastes the clipboard contents to actual position</source>
        <translation>Enganxar

Enganxa el contingut del portapapers a la posició actual</translation>
    </message>
    <message>
        <source>Toolbar</source>
        <translation>Barra d&apos;eines</translation>
    </message>
    <message>
        <source>Tool&amp;bar</source>
        <translation>&amp;Barra d&apos;eines</translation>
    </message>
    <message>
        <source>Enables/disables the toolbar</source>
        <translation>Habilita/deshabilita la barra d&apos;eines</translation>
    </message>
    <message>
        <source>Toolbar

Enables/disables the toolbar</source>
        <translation>Barra d&apos;eines

Habilita/deshabilita la barra d&apos;eines</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Barra d&apos;estat</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation>&amp;Barra d&apos;estat</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation>Habilita/Desabilita la barra d&apos;estat</translation>
    </message>
    <message>
        <source>Statusbar

Enables/disables the statusbar</source>
        <translation>Barra d&apos;estat

Habilita/Desabilita la barra d&apos;estat</translation>
    </message>
    <message>
        <source>FullScreen</source>
        <translation>Pantalla Completa</translation>
    </message>
    <message>
        <source>&amp;FullScreen</source>
        <translation>&amp;Pantalla Completa</translation>
    </message>
    <message>
        <source>Enables/disables the full screen</source>
        <translation>Habilita/Desabilita la modalitat de pantalla completa</translation>
    </message>
    <message>
        <source>FullScreen

Enables/disables the full screen mode</source>
        <translation>Pantalla completa

Habilita/desabilita la modalitat de pantalla completa</translation>
    </message>
    <message>
        <source>Corrector</source>
        <translation>Corrector</translation>
    </message>
    <message>
        <source>&amp;Corrector</source>
        <translation>&amp;Corrector</translation>
    </message>
    <message>
        <source>Muestra/Oculta el corrector</source>
        <translation>Mostrar/Ocultar el corrector</translation>
    </message>
    <message>
        <source>Corrector

Muestra/oculta el corrector</source>
        <translation>Corrector

Mostrar/Ocultar el corrector</translation>
    </message>
    <message>
        <source>New Window</source>
        <translation>Nova Finestra</translation>
    </message>
    <message>
        <source>&amp;New Window</source>
        <translation>&amp;Nova Finestra</translation>
    </message>
    <message>
        <source>Opens a new view for the current document</source>
        <translation>Nova Finestra Obre una nova vista per al document actual</translation>
    </message>
    <message>
        <source>New Window

Opens a new view for the current document</source>
        <translation>Nova finestra

Obre una nova vista per al document actual</translation>
    </message>
    <message>
        <source>Cascade</source>
        <translation>Cascada</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Cascada</translation>
    </message>
    <message>
        <source>Cascades all windows</source>
        <translation>Cascada de totes les finestres</translation>
    </message>
    <message>
        <source>Cascade

Cascades all windows</source>
        <translation>Cascada

Cascada de totes les finestres</translation>
    </message>
    <message>
        <source>Tile</source>
        <translation>Ordena</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Ordena</translation>
    </message>
    <message>
        <source>Tiles all windows</source>
        <translation>Ordena totes les finestres</translation>
    </message>
    <message>
        <source>Tile

Tiles all windows</source>
        <translation>Ordena

Ordena totes les finestres</translation>
    </message>
    <message>
        <source>Acerca de </source>
        <translation>Sobre la aplicació</translation>
    </message>
    <message>
        <source>&amp;Acerca de ...</source>
        <translation>&amp;Sobre la aplicació...</translation>
    </message>
    <message>
        <source>Sobre la aplicacion</source>
        <translation>Sobre la aplicació</translation>
    </message>
    <message>
        <source>Acerca de ...

Informacion sobre los autores de la aplicacion</source>
        <translation>Sobre la aplicació ..... Informació sobre els autors de l&apos;aplicació</translation>
    </message>
    <message>
        <source>Plan Contable</source>
        <translation>Pla de Comptes</translation>
    </message>
    <message>
        <source>&amp;Plan Contable</source>
        <translation>&amp;Pla de Comptes</translation>
    </message>
    <message>
        <source>Muestra el plan contable</source>
        <translation>Mostra el pla de comptes</translation>
    </message>
    <message>
        <source>Grupos Contables</source>
        <translation>Grups Contables</translation>
    </message>
    <message>
        <source>&amp;Grupos Contables</source>
        <translation>&amp;Grups Contables</translation>
    </message>
    <message>
        <source>Muestra los grupos contables</source>
        <translation>Mostra els grups contables</translation>
    </message>
    <message>
        <source>Listado de Cuentas</source>
        <translation>Llistat de Contes</translation>
    </message>
    <message>
        <source>&amp;Listado de Cuentas</source>
        <translation>&amp;Llistat de Contes</translation>
    </message>
    <message>
        <source>Muestra los listados de las cuentas</source>
        <translation>Mostra els llistats de les contes</translation>
    </message>
    <message>
        <source>Introducci&#xf3;n de Apuntes</source>
        <translation>Introducció d&apos;Apunts</translation>
    </message>
    <message>
        <source>&amp;Introducci&#xf3;n de Apuntes</source>
        <translation>&amp;Introducció d&apos;Apunts</translation>
    </message>
    <message>
        <source>Permite introducir Apuntes Contables</source>
        <translation>Permet introduïr Apunts Contables</translation>
    </message>
    <message>
        <source>Asientos Inteligentes</source>
        <translation>Assentaments Inteligents</translation>
    </message>
    <message>
        <source>&amp;Asientos Inteligentes</source>
        <translation>&amp;Assentaments Inteligents</translation>
    </message>
    <message>
        <source>Permite introducir Apuntes Contables Mediante Plantillas</source>
        <translation>Permet introduïr Apunts Contables Mitjançant Plantilles</translation>
    </message>
    <message>
        <source>Listado de Apuntes</source>
        <translation>Llistat d&apos;Apunts</translation>
    </message>
    <message>
        <source>&amp;Listado de Apuntes</source>
        <translation>&amp;Llistat d&apos;Apunts</translation>
    </message>
    <message>
        <source>Listar Apuntes Contables</source>
        <translation>Llistar Apunts Contables</translation>
    </message>
    <message>
        <source>Propiedades Empresa</source>
        <translation>Propietats de l&apos;Empresa</translation>
    </message>
    <message>
        <source>&amp;Propiedades Empresa</source>
        <translation>&amp;Propietats de l&apos;Empresa</translation>
    </message>
    <message>
        <source>Propiedades de la Empresa</source>
        <translation>Propietats de la Empresa</translation>
    </message>
    <message>
        <source>Copia Seguridad Empresa</source>
        <translation type="obsolete">Copia de seguretat de la Empresa</translation>
    </message>
    <message>
        <source>&amp;Guardar Empresa</source>
        <translation type="obsolete">&amp;Desar Empresa</translation>
    </message>
    <message>
        <source>Hacer Copia de Seguridad de la Empresa Actual</source>
        <translation type="obsolete">Fer copia de Seguretat de la Empresa Actual</translation>
    </message>
    <message>
        <source>Restaurar Empresa</source>
        <translation type="obsolete">Restaurar Empresa</translation>
    </message>
    <message>
        <source>&amp;Cargar Empresa</source>
        <translation type="obsolete">&amp;Carregar Empresa</translation>
    </message>
    <message>
        <source>Restaurar de Seguridad de la Empresa Actual</source>
        <translation type="obsolete">Restaurar una copia de seguretat de la empresa actual</translation>
    </message>
    <message>
        <source>Nueva Empresa</source>
        <translation type="obsolete">Nova Empresa</translation>
    </message>
    <message>
        <source>&amp;Nueva Empresa</source>
        <translation type="obsolete">&amp;Nova Empresa</translation>
    </message>
    <message>
        <source>Crear una Empresal</source>
        <translation type="obsolete">Crear una Empresa</translation>
    </message>
    <message>
        <source>Crear una empresa nueva</source>
        <translation type="obsolete">Crear una empresa nova</translation>
    </message>
    <message>
        <source>Asiento de Cierre</source>
        <translation>Assentaments de Tancament</translation>
    </message>
    <message>
        <source>Asiento de &amp;Cierre</source>
        <translation>Assentaments de &amp;Tancament</translation>
    </message>
    <message>
        <source>Crear el asiento de cierre</source>
        <translation>Crear un assentament de tancament</translation>
    </message>
    <message>
        <source>Asiento de Regularizaci&#xf3;n</source>
        <translation>Assentament de Regularització</translation>
    </message>
    <message>
        <source>Asiento de &amp;Regularizaci&#xf3;n</source>
        <translation>Assentament de &amp;Regularització</translation>
    </message>
    <message>
        <source>Regularizar Empresa</source>
        <translation>Regularitzar empresa</translation>
    </message>
    <message>
        <source>Asiento de Apertura</source>
        <translation>Assentament d&apos;Apertura</translation>
    </message>
    <message>
        <source>Asiento de &amp;Apertura</source>
        <translation>Assentament d&apos;&amp;Apertura</translation>
    </message>
    <message>
        <source>Abrir el asiento de apertura</source>
        <translation>Obrir l&apos;assentament d&apos;apertura</translation>
    </message>
    <message>
        <source>Borrar Empresa</source>
        <translation type="obsolete">Borrar Empresa</translation>
    </message>
    <message>
        <source>&amp;Borrar Empresa</source>
        <translation type="obsolete">&amp;Borrar Emrpesa</translation>
    </message>
    <message>
        <source>Borrar una Empresal</source>
        <translation type="obsolete">Borrar una Emrpesa</translation>
    </message>
    <message>
        <source>Borrar una empresa</source>
        <translation type="obsolete">Borrar una Empresa</translation>
    </message>
    <message>
        <source>Cambiar Empresa</source>
        <translation type="obsolete">Canviar Empresa</translation>
    </message>
    <message>
        <source>&amp;Cambiar Empresa</source>
        <translation type="obsolete">&amp;Canviar Empresa</translation>
    </message>
    <message>
        <source>Cambiar de Empresa o de ejercicio</source>
        <translation type="obsolete">Canviar d&apos;Empresa o de ejercici</translation>
    </message>
    <message>
        <source>Cambiar de empresa</source>
        <translation type="obsolete">Canviar d&apos;empresa</translation>
    </message>
    <message>
        <source>Libro Mayor</source>
        <translation>Llibre Major</translation>
    </message>
    <message>
        <source>&amp;Libro Mayor</source>
        <translation>&amp;Llibre Major</translation>
    </message>
    <message>
        <source>Ver el libro Mayor</source>
        <translation>Veure el llibre Major</translation>
    </message>
    <message>
        <source>Libro Diario</source>
        <translation>Llibre Diari</translation>
    </message>
    <message>
        <source>&amp;Libro Diario</source>
        <translation>&amp;Llibre Diari</translation>
    </message>
    <message>
        <source>Ver el libro Diario</source>
        <translation>Veure el llibre Diari</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Balanç</translation>
    </message>
    <message>
        <source>&amp;Balance</source>
        <translation>&amp;Balanç</translation>
    </message>
    <message>
        <source>Ver balance</source>
        <translation>Veure el Balanç</translation>
    </message>
    <message>
        <source>Balance Jerarquico</source>
        <translation>Balanç Jeràrquic</translation>
    </message>
    <message>
        <source>&amp;Balance Jerarquico</source>
        <translation>&amp;Balanç Jeràrquic</translation>
    </message>
    <message>
        <source>Ver balance Jerarquico</source>
        <translation>Veure balanç Jeràrquic</translation>
    </message>
    <message>
        <source>Ver balance jerarquico</source>
        <translation>Veure balanç jeràrquic</translation>
    </message>
    <message>
        <source>Perdidas y ganancias av</source>
        <translation type="obsolete">Pèrdues i guanys abreujat</translation>
    </message>
    <message>
        <source>&amp;Perdidas y ganancias av</source>
        <translation type="obsolete">&amp;Pèrdues i guanys abreujat</translation>
    </message>
    <message>
        <source>Ver cuenta de perdidas y ganancias</source>
        <translation type="obsolete">Veure conta de pèrdues i guanys</translation>
    </message>
    <message>
        <source>Balance abreviado</source>
        <translation type="obsolete">Balanç Abreujat</translation>
    </message>
    <message>
        <source>&amp;Balance Abreviado</source>
        <translation type="obsolete">&amp;Balanç Abreujat</translation>
    </message>
    <message>
        <source>Ver Balance de situacion abreviado</source>
        <translation type="obsolete">Veure Balanç de situació abreujat</translation>
    </message>
    <message>
        <source>Registro de IVA</source>
        <translation>Registre d&apos;IVA</translation>
    </message>
    <message>
        <source>&amp;Registro de IVA</source>
        <translation>&amp;Registre d&apos;IVA</translation>
    </message>
    <message>
        <source>Ver Libro Registro de IVA</source>
        <translation>Veure el llibre d&apos;IVA</translation>
    </message>
    <message>
        <source>Centros de Coste</source>
        <translation>Centres de Cost</translation>
    </message>
    <message>
        <source>&amp;Centros de Coste</source>
        <translation>&amp;Centres de Cost</translation>
    </message>
    <message>
        <source>Administracion de Centros de Coste</source>
        <translation>Administracó de Centres de Cost</translation>
    </message>
    <message>
        <source>Canales</source>
        <translation>Canals</translation>
    </message>
    <message>
        <source>C&amp;anales</source>
        <translation>C&amp;anals</translation>
    </message>
    <message>
        <source>Administracion de Canales</source>
        <translation>Administració de Canals</translation>
    </message>
    <message>
        <source>Asientos</source>
        <translation>Assentaments</translation>
    </message>
    <message>
        <source>&amp;Asientos</source>
        <translation>&amp;Assentaments</translation>
    </message>
    <message>
        <source>Introduccion de asientos</source>
        <translation>Introducció d&apos;assentaments</translation>
    </message>
    <message>
        <source>Introduccion de ASientos</source>
        <translation>Introducció d&apos;Assentaments</translation>
    </message>
    <message>
        <source>Siguiente</source>
        <translation>Següent</translation>
    </message>
    <message>
        <source>&amp;Siguiente</source>
        <translation>&amp;Següent</translation>
    </message>
    <message>
        <source>Anterior</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <source>&amp;Anterior</source>
        <translation>&amp;Anterior</translation>
    </message>
    <message>
        <source>Ultimo</source>
        <translation>Darrer</translation>
    </message>
    <message>
        <source>&amp;Ultimo</source>
        <translation>&amp;Darrer</translation>
    </message>
    <message>
        <source>Primero</source>
        <translation>Primer</translation>
    </message>
    <message>
        <source>&amp;Primero</source>
        <translation>&amp;Primer</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Desar</translation>
    </message>
    <message>
        <source>&amp;Guardar</source>
        <translation>&amp;Desar</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>&amp;Imprimir</source>
        <translation>&amp;Imprimir</translation>
    </message>
    <message>
        <source>Recargar</source>
        <translation>Recarregar</translation>
    </message>
    <message>
        <source>&amp;Recargar</source>
        <translation>&amp;Recarregar</translation>
    </message>
    <message>
        <source>Usuarios</source>
        <translation type="obsolete">Usuaris</translation>
    </message>
    <message>
        <source>&amp;Usuarios</source>
        <translation type="obsolete">&amp;Usuaris</translation>
    </message>
    <message>
        <source>Amortizaciones</source>
        <translation>Amortitzacions</translation>
    </message>
    <message>
        <source>&amp;Amortizaciones</source>
        <translation>&amp;Amortitzacions</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>&amp;Ayuda</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <source>Ayuda en Internet</source>
        <translation>Ajuda a Internet</translation>
    </message>
    <message>
        <source>&amp;Ayuda en Internet</source>
        <translation>&amp;Ajuda a Internet</translation>
    </message>
    <message>
        <source>Ayuda en la web del proyecto</source>
        <translation>Ajuda al web del projecte</translation>
    </message>
    <message>
        <source>Abrir Asientos</source>
        <translation>Obrir Assentaments</translation>
    </message>
    <message>
        <source>&amp;Abrir Asientos</source>
        <translation>&amp;Obrir Assentaments</translation>
    </message>
    <message>
        <source>Espacia los Asientos</source>
        <translation>Espaiar Assentaments</translation>
    </message>
    <message>
        <source>Ordenar Asientos</source>
        <translation>Comprimir Assentaments</translation>
    </message>
    <message>
        <source>&amp;Ordenar Asientos</source>
        <translation>&amp;Comprimir Assentaments</translation>
    </message>
    <message>
        <source>Reorganiza los Asientos</source>
        <translation>Reorganitzar Assentaments</translation>
    </message>
    <message>
        <source>Seguimiento de Cuentas</source>
        <translation>Seguiment de contes</translation>
    </message>
    <message>
        <source>&amp;Seguimiento de Cuentas</source>
        <translation>&amp;Seguiment de Contes</translation>
    </message>
    <message>
        <source>Balance Gr&#xe1;fico</source>
        <translation>Balanç gràfic</translation>
    </message>
    <message>
        <source>&amp;Balance Gr&#xe1;fico</source>
        <translation>&amp;Balanç gràfic</translation>
    </message>
    <message>
        <source>Filtro</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <source>&amp;Filtro</source>
        <translation>&amp;Filtre</translation>
    </message>
    <message>
        <source>Masas Patrimoniales</source>
        <translation>Masses Patrimonials</translation>
    </message>
    <message>
        <source>&amp;Masas Patrimoniales</source>
        <translation>&amp;Masses Patrimonials</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Balanços</translation>
    </message>
    <message>
        <source>&amp;Balances</source>
        <translation>&amp;Balanços</translation>
    </message>
    <message>
        <source>Nuevo Ejercicio</source>
        <translation type="obsolete">Nou Exercici</translation>
    </message>
    <message>
        <source>&amp;Nuevo Ejercicio</source>
        <translation type="obsolete">&amp;Nou Exercici</translation>
    </message>
    <message>
        <source>Sustituir Cuentas</source>
        <translation>Substituïr contes</translation>
    </message>
    <message>
        <source>&amp;Sustituir Cuentas</source>
        <translation>&amp;Substituïr Contes</translation>
    </message>
    <message>
        <source>Que es ??</source>
        <translation>Que és ??</translation>
    </message>
    <message>
        <source>&amp;Empresa</source>
        <translation>&amp;Empresa</translation>
    </message>
    <message>
        <source>&amp;Asiento</source>
        <translation>&amp;Assentament</translation>
    </message>
    <message>
        <source>&amp;Listados</source>
        <translation>&amp;Llistats</translation>
    </message>
    <message>
        <source>&amp;Estadistica</source>
        <translation>&amp;Estadística</translation>
    </message>
    <message>
        <source>&amp;Ventana</source>
        <translation>&amp;Finestra</translation>
    </message>
    <message>
        <source>&amp;Herramientas</source>
        <translation>&amp;Estris de fer feina</translation>
    </message>
    <message>
        <source>&amp;Ver</source>
        <translation>&amp;Veure</translation>
    </message>
    <message>
        <source>Listo.</source>
        <translation>Enllestit.</translation>
    </message>
    <message>
        <source>Reverting last action...</source>
        <translation>Desfent la darrera acció...</translation>
    </message>
    <message>
        <source>Ready.</source>
        <translation>A punt.</translation>
    </message>
    <message>
        <source>Cutting selection...</source>
        <translation>Tallant la selecció...</translation>
    </message>
    <message>
        <source>Copying selection to clipboard...</source>
        <translation>Copiant la selecció al portapapers...</translation>
    </message>
    <message>
        <source>Inserting clipboard contents...</source>
        <translation>Inserint el contingut del portapapers...</translation>
    </message>
    <message>
        <source>Toggle toolbar...</source>
        <translation>Mostrar/ Ocultar la barra d&apos;eines...</translation>
    </message>
    <message>
        <source>Toggle statusbar...</source>
        <translation>Mostrar/Ocultar la barra d&apos;estat...</translation>
    </message>
    <message>
        <source>Toggle full screen mode...</source>
        <translation>Mostrar/Ocultar en mode pantalla completa...</translation>
    </message>
    <message>
        <source>Ver Corrector...</source>
        <translation>Veure Corrector ....</translation>
    </message>
    <message>
        <source>Plan de Cuentas</source>
        <translation>Pla de contes</translation>
    </message>
    <message>
        <source>Introducci&#xf3;n de Borrador</source>
        <translation>Introducció de Borrador</translation>
    </message>
    <message>
        <source>Guardar Empresa</source>
        <translation type="obsolete">Desar Empresa</translation>
    </message>
    <message>
        <source>Cargar Empresa</source>
        <translation type="obsolete">Carregar Empresa</translation>
    </message>
    <message>
        <source>Gesti&#xf3;n de Usuarios</source>
        <translation type="obsolete">Gestió d&apos;Usuaris</translation>
    </message>
    <message>
        <source>BulmaG&#xe9;s </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modelo 347 no oficial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Modelo 347</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lista en pantalla los saldos acumulados superirores a ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bloquear Fechas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Bloquear Fechas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Canal por Defecto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Canal por Defecto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Centro de Coste por Defecto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Centro de Coste por Defecto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recalcular Saldos Iniciales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recalcular Saldos Iniciales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archivo Documental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Archivo Documental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cobros y Pagos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cobros y Pagos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bulmages01App</name>
    <message>
        <source>Bulmages </source>
        <translation type="obsolete">BulmaGés</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Tallar</translation>
    </message>
    <message>
        <source>Cuts the selected section and puts it to the clipboard</source>
        <translation type="obsolete">Talla la selecció i la copia al portapapers</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="obsolete">&amp;Copiar</translation>
    </message>
    <message>
        <source>Copies the selected section to the clipboard</source>
        <translation type="obsolete">Copia la selecció al portapapers</translation>
    </message>
    <message>
        <source>Toolbar</source>
        <translation type="obsolete">Barra d&apos;eines</translation>
    </message>
    <message>
        <source>Enables/disables the toolbar</source>
        <translation type="obsolete">Habilita/deshabilita la barra d&apos;eines</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation type="obsolete">Barra d&apos;estat</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation type="obsolete">&amp;Barra d&apos;estat</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation type="obsolete">Habilita/Desabilita la barra d&apos;estat</translation>
    </message>
    <message>
        <source>Statusbar

Enables/disables the statusbar</source>
        <translation type="obsolete">Barra d&apos;estat

Habilita/Desabilita la barra d&apos;estat</translation>
    </message>
    <message>
        <source>FullScreen</source>
        <translation type="obsolete">Pantalla Completa</translation>
    </message>
    <message>
        <source>&amp;FullScreen</source>
        <translation type="obsolete">&amp;Pantalla Completa</translation>
    </message>
    <message>
        <source>Enables/disables the full screen</source>
        <translation type="obsolete">Habilita/Desabilita la modalitat de pantalla completa</translation>
    </message>
    <message>
        <source>FullScreen

Enables/disables the full screen mode</source>
        <translation type="obsolete">Pantalla completa

Habilita/desabilita la modalitat de pantalla completa</translation>
    </message>
    <message>
        <source>New Window</source>
        <translation type="obsolete">Nova Finestra</translation>
    </message>
    <message>
        <source>&amp;New Window</source>
        <translation type="obsolete">&amp;Nova Finestra</translation>
    </message>
    <message>
        <source>Acerca de </source>
        <translation type="obsolete">Sobre la aplicació</translation>
    </message>
    <message>
        <source>&amp;Acerca de ...</source>
        <translation type="obsolete">&amp;Sobre la aplicació ...</translation>
    </message>
    <message>
        <source>Sobre la aplicacion</source>
        <translation type="obsolete">Sobre la aplicació</translation>
    </message>
    <message>
        <source>Acerca de ...

Informacion sobre los autores de la aplicacion</source>
        <translation type="obsolete">Sobre la aplicació ...

Informació sobre els autors de l&apos;aplicació</translation>
    </message>
    <message>
        <source>Plan Contable</source>
        <translation type="obsolete">Pla de Contes</translation>
    </message>
    <message>
        <source>&amp;Plan Contable</source>
        <translation type="obsolete">&amp;Pla de Contes</translation>
    </message>
    <message>
        <source>Muestra el plan contable</source>
        <translation type="obsolete">Mostra el pla de contes</translation>
    </message>
    <message>
        <source>Grupos Contables</source>
        <translation type="obsolete">Grups Contables</translation>
    </message>
    <message>
        <source>&amp;Grupos Contables</source>
        <translation type="obsolete">&amp;Grups Contables</translation>
    </message>
    <message>
        <source>Muestra los grupos contables</source>
        <translation type="obsolete">Mostra els grups contables</translation>
    </message>
    <message>
        <source>Listado de Cuentas</source>
        <translation type="obsolete">Llistat de Contes</translation>
    </message>
    <message>
        <source>&amp;Listado de Cuentas</source>
        <translation type="obsolete">&amp;Llistat de Contes</translation>
    </message>
    <message>
        <source>Muestra los listados de las cuentas</source>
        <translation type="obsolete">Mostra els llistats de les contes</translation>
    </message>
    <message>
        <source>Introducci&#xf3;n de Apuntes</source>
        <translation type="obsolete">Introducció d&apos;Apunts</translation>
    </message>
    <message>
        <source>&amp;Introducci&#xf3;n de Apuntes</source>
        <translation type="obsolete">&amp;Introducció d&apos;Apunts</translation>
    </message>
    <message>
        <source>Permite introducir Apuntes Contables</source>
        <translation type="obsolete">Permet introduïr Apunts Contables</translation>
    </message>
    <message>
        <source>Asientos Inteligentes</source>
        <translation type="obsolete">Assentaments Inteligents</translation>
    </message>
    <message>
        <source>&amp;Asientos Inteligentes</source>
        <translation type="obsolete">&amp;Assentaments Inteligents</translation>
    </message>
    <message>
        <source>Permite introducir Apuntes Contables Mediante Plantillas</source>
        <translation type="obsolete">Permet introduïr Apunts Contables Mitjançant Plantilles</translation>
    </message>
    <message>
        <source>Listado de Apuntes</source>
        <translation type="obsolete">Llistat d&apos;Apunts</translation>
    </message>
    <message>
        <source>&amp;Listado de Apuntes</source>
        <translation type="obsolete">&amp;Llistat d&apos;Apunts</translation>
    </message>
    <message>
        <source>Listar Apuntes Contables</source>
        <translation type="obsolete">Llistar Apunts Contables</translation>
    </message>
    <message>
        <source>Propiedades Empresa</source>
        <translation type="obsolete">Propietats de l&apos;Empresa</translation>
    </message>
    <message>
        <source>&amp;Propiedades Empresa</source>
        <translation type="obsolete">&amp;Propietats de l&apos;Empresa</translation>
    </message>
    <message>
        <source>Propiedades de la Empresa</source>
        <translation type="obsolete">Propietats de la Empresa</translation>
    </message>
    <message>
        <source>Copia Seguridad Empresa</source>
        <translation type="obsolete">Còpia de seguretat Empresa</translation>
    </message>
    <message>
        <source>&amp;Guardar Empresa</source>
        <translation type="obsolete">&amp;Desar Empresa</translation>
    </message>
    <message>
        <source>Hacer Copia de Seguridad de la Empresa Actual</source>
        <translation type="obsolete">Fer una còpia de Seguretat de la Empresa Actual</translation>
    </message>
    <message>
        <source>Restaurar Empresa</source>
        <translation type="obsolete">Restaurar Empresa</translation>
    </message>
    <message>
        <source>&amp;Cargar Empresa</source>
        <translation type="obsolete">&amp;Restaurar Empresa</translation>
    </message>
    <message>
        <source>Restaurar de Seguridad de la Empresa Actual</source>
        <translation type="obsolete">Restaurar una còpia de Seguretat de la Empresa Actual</translation>
    </message>
    <message>
        <source>Nueva Empresa</source>
        <translation type="obsolete">Nova Empresa</translation>
    </message>
    <message>
        <source>&amp;Nueva Empresa</source>
        <translation type="obsolete">&amp;Nova Empresa</translation>
    </message>
    <message>
        <source>Crear una Empresal</source>
        <translation type="obsolete">Crear una Empresa</translation>
    </message>
    <message>
        <source>Crear una empresa nueva</source>
        <translation type="obsolete">Crear una empresa nova</translation>
    </message>
    <message>
        <source>Asiento de Cierre</source>
        <translation type="obsolete">Assentament de Tancament</translation>
    </message>
    <message>
        <source>Asiento de &amp;Cierre</source>
        <translation type="obsolete">Assentament de &amp;Tancament</translation>
    </message>
    <message>
        <source>Crear el asiento de cierre</source>
        <translation type="obsolete">Crear un assentament de tancament</translation>
    </message>
    <message>
        <source>Asiento de Regularizaci&#xf3;n</source>
        <translation type="obsolete">Assentament de Regularització</translation>
    </message>
    <message>
        <source>Asiento de &amp;Regularizaci&#xf3;n</source>
        <translation type="obsolete">Assentament de &amp;Regularització</translation>
    </message>
    <message>
        <source>Regularizar Empresa</source>
        <translation type="obsolete">Regularitzar empresa</translation>
    </message>
    <message>
        <source>Asiento de Apertura</source>
        <translation type="obsolete">Assentament d&apos;Apertura</translation>
    </message>
    <message>
        <source>Asiento de &amp;Apertura</source>
        <translation type="obsolete">Assentament d&apos;&amp;Apertura</translation>
    </message>
    <message>
        <source>Abrir el asiento de apertura</source>
        <translation type="obsolete">Obrir l&apos;assentament d&apos;apertura</translation>
    </message>
    <message>
        <source>Borrar Empresa</source>
        <translation type="obsolete">Borrar Empresa</translation>
    </message>
    <message>
        <source>&amp;Borrar Empresa</source>
        <translation type="obsolete">&amp;Borrar Emrpesa</translation>
    </message>
    <message>
        <source>Borrar una Empresal</source>
        <translation type="obsolete">Borrar una emrpesa</translation>
    </message>
    <message>
        <source>Borrar una empresa</source>
        <translation type="obsolete">Borrar una empresa</translation>
    </message>
    <message>
        <source>Cambiar Empresa</source>
        <translation type="obsolete">Canviar Empresa</translation>
    </message>
    <message>
        <source>&amp;Cambiar Empresa</source>
        <translation type="obsolete">&amp;Canviar Empresa</translation>
    </message>
    <message>
        <source>Cambiar de Empresa o de ejercicio</source>
        <translation type="obsolete">Canviar d&apos;Empresa o d&apos;exercici</translation>
    </message>
    <message>
        <source>Cambiar de empresa</source>
        <translation type="obsolete">Canviar d&apos;empresa</translation>
    </message>
    <message>
        <source>Libro Mayor</source>
        <translation type="obsolete">Llibre Major</translation>
    </message>
    <message>
        <source>&amp;Libro Mayor</source>
        <translation type="obsolete">&amp;Llibre Major</translation>
    </message>
    <message>
        <source>Ver el libro Mayor</source>
        <translation type="obsolete">Veure el llibre Major</translation>
    </message>
    <message>
        <source>Libro Diario</source>
        <translation type="obsolete">Llibre Diari</translation>
    </message>
    <message>
        <source>&amp;Libro Diario</source>
        <translation type="obsolete">&amp;Llibre Diari</translation>
    </message>
    <message>
        <source>Ver el libro Diario</source>
        <translation type="obsolete">Veure el llibre diari</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="obsolete">Balanç</translation>
    </message>
    <message>
        <source>&amp;Balance</source>
        <translation type="obsolete">&amp;Balanç</translation>
    </message>
    <message>
        <source>Ver balance</source>
        <translation type="obsolete">Veure el Balanç</translation>
    </message>
    <message>
        <source>Balance Jerarquico</source>
        <translation type="obsolete">Balanç Jeràrquic</translation>
    </message>
    <message>
        <source>&amp;Balance Jerarquico</source>
        <translation type="obsolete">&amp;Balanç Jeràrquic</translation>
    </message>
    <message>
        <source>Ver balance Jerarquico</source>
        <translation type="obsolete">Veure balanç Jeràrquic</translation>
    </message>
    <message>
        <source>Ver balance jerarquico</source>
        <translation type="obsolete">Veure balanç jeràrquic</translation>
    </message>
    <message>
        <source>Perdidas y ganancias av</source>
        <translation type="obsolete">Pèrdues i guanys abreujat</translation>
    </message>
    <message>
        <source>&amp;Perdidas y ganancias av</source>
        <translation type="obsolete">&amp;Pèrdues i guanys abreujat</translation>
    </message>
    <message>
        <source>Ver cuenta de perdidas y ganancias</source>
        <translation type="obsolete">Veure conta de pèrdues i guanys</translation>
    </message>
    <message>
        <source>Balance abreviado</source>
        <translation type="obsolete">Balanç Abreviat</translation>
    </message>
    <message>
        <source>&amp;Balance Abreviado</source>
        <translation type="obsolete">&amp;Balanç Abreviat</translation>
    </message>
    <message>
        <source>Ver Balance de situacion abreviado</source>
        <translation type="obsolete">Veure Balanç de situació abreujat</translation>
    </message>
    <message>
        <source>Centros de Coste</source>
        <translation type="obsolete">Centres de Cost</translation>
    </message>
    <message>
        <source>&amp;Centros de Coste</source>
        <translation type="obsolete">&amp;Centres de Cost</translation>
    </message>
    <message>
        <source>Administracion de Centros de Coste</source>
        <translation type="obsolete">Administracó de Centres de Cost</translation>
    </message>
    <message>
        <source>Canales</source>
        <translation type="obsolete">Canals</translation>
    </message>
    <message>
        <source>C&amp;anales</source>
        <translation type="obsolete">C&amp;anals</translation>
    </message>
    <message>
        <source>Administracion de Canales</source>
        <translation type="obsolete">Administració de Canals</translation>
    </message>
    <message>
        <source>Asientos</source>
        <translation type="obsolete">Assentaments</translation>
    </message>
    <message>
        <source>&amp;Asientos</source>
        <translation type="obsolete">&amp;Assentaments</translation>
    </message>
    <message>
        <source>Introduccion de asientos</source>
        <translation type="obsolete">Introducció d&apos;assentaments</translation>
    </message>
    <message>
        <source>Introduccion de ASientos</source>
        <translation type="obsolete">Introducció d&apos;Assentaments</translation>
    </message>
    <message>
        <source>Siguiente</source>
        <translation type="obsolete">Següent</translation>
    </message>
    <message>
        <source>&amp;Siguiente</source>
        <translation type="obsolete">&amp;Següent</translation>
    </message>
    <message>
        <source>Anterior</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message>
        <source>&amp;Anterior</source>
        <translation type="obsolete">&amp;Anterior</translation>
    </message>
    <message>
        <source>Ultimo</source>
        <translation type="obsolete">Darrer</translation>
    </message>
    <message>
        <source>&amp;Ultimo</source>
        <translation type="obsolete">&amp;Darrer</translation>
    </message>
    <message>
        <source>Primero</source>
        <translation type="obsolete">Primer</translation>
    </message>
    <message>
        <source>&amp;Primero</source>
        <translation type="obsolete">&amp;Primer</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation type="obsolete">Desar</translation>
    </message>
    <message>
        <source>&amp;Guardar</source>
        <translation type="obsolete">&amp;Desar</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation type="obsolete">Imprimir</translation>
    </message>
    <message>
        <source>&amp;Imprimir</source>
        <translation type="obsolete">&amp;Imprimir</translation>
    </message>
    <message>
        <source>Recargar</source>
        <translation type="obsolete">Recarregar</translation>
    </message>
    <message>
        <source>&amp;Recargar</source>
        <translation type="obsolete">&amp;Recarregar</translation>
    </message>
    <message>
        <source>Usuarios</source>
        <translation type="obsolete">Usuaris</translation>
    </message>
    <message>
        <source>&amp;Usuarios</source>
        <translation type="obsolete">&amp;Usuaris</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation type="obsolete">Ajuda</translation>
    </message>
    <message>
        <source>&amp;Ayuda</source>
        <translation type="obsolete">&amp;Ajuda</translation>
    </message>
    <message>
        <source>Ayuda en Internet</source>
        <translation type="obsolete">Ajuda a Internet</translation>
    </message>
    <message>
        <source>&amp;Ayuda en Internet</source>
        <translation type="obsolete">&amp;Ajuda a Internet</translation>
    </message>
    <message>
        <source>Ayuda en la web del proyecto</source>
        <translation type="obsolete">Ajuda al web del projecte</translation>
    </message>
    <message>
        <source>Abrir Asientos</source>
        <translation type="obsolete">Obrir Assentaments</translation>
    </message>
    <message>
        <source>&amp;Abrir Asientos</source>
        <translation type="obsolete">&amp;Obrir Assentaments</translation>
    </message>
    <message>
        <source>Espacia los Asientos</source>
        <translation type="obsolete">Espaiar Assentaments</translation>
    </message>
    <message>
        <source>Ordenar Asientos</source>
        <translation type="obsolete">Comprimir Assentaments</translation>
    </message>
    <message>
        <source>&amp;Ordenar Asientos</source>
        <translation type="obsolete">&amp;Comprimir Assentaments</translation>
    </message>
    <message>
        <source>Reorganiza los Asientos</source>
        <translation type="obsolete">Reorganitzar Assentaments</translation>
    </message>
    <message>
        <source>Seguimiento de Cuentas</source>
        <translation type="obsolete">Seguiment de Contes</translation>
    </message>
    <message>
        <source>&amp;Seguimiento de Cuentas</source>
        <translation type="obsolete">&amp;Seguiment de Contes</translation>
    </message>
    <message>
        <source>Balance Gr&#xe1;fico</source>
        <translation type="obsolete">Balanç gràfic</translation>
    </message>
    <message>
        <source>&amp;Balance Gr&#xe1;fico</source>
        <translation type="obsolete">&amp;Balanç gràfic</translation>
    </message>
    <message>
        <source>Filtro</source>
        <translation type="obsolete">Filtre</translation>
    </message>
    <message>
        <source>&amp;Filtro</source>
        <translation type="obsolete">&amp;Filtre</translation>
    </message>
    <message>
        <source>Masas Patrimoniales</source>
        <translation type="obsolete">Masses Patrimonials</translation>
    </message>
    <message>
        <source>&amp;Masas Patrimoniales</source>
        <translation type="obsolete">&amp;Masses Patrimonials</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation type="obsolete">Balanços</translation>
    </message>
    <message>
        <source>&amp;Balances</source>
        <translation type="obsolete">&amp;Balanços</translation>
    </message>
    <message>
        <source>Nuevo Ejercicio</source>
        <translation type="obsolete">Nou Ejercici</translation>
    </message>
    <message>
        <source>&amp;Nuevo Ejercicio</source>
        <translation type="obsolete">&amp;Nou Ejercici</translation>
    </message>
    <message>
        <source>&amp;Listados</source>
        <translation type="obsolete">&amp;Llistats</translation>
    </message>
    <message>
        <source>&amp;Estadistica</source>
        <translation type="obsolete">&amp;Estadística</translation>
    </message>
    <message>
        <source>&amp;Ventana</source>
        <translation type="obsolete">&amp;Finestra</translation>
    </message>
    <message>
        <source>&amp;Herramientas</source>
        <translation type="obsolete">&amp;Estris de fer feina</translation>
    </message>
    <message>
        <source>&amp;Ver</source>
        <translation type="obsolete">&amp;Veure</translation>
    </message>
    <message>
        <source>Listo.</source>
        <translation type="obsolete">Enllestit.</translation>
    </message>
    <message>
        <source>Quit...</source>
        <translation type="obsolete">Sortir...</translation>
    </message>
    <message>
        <source>Do your really want to quit?</source>
        <translation type="obsolete">Realment vols sortir del programa ?</translation>
    </message>
    <message>
        <source>Reverting last action...</source>
        <translation type="obsolete">Desfent la darrera acció...</translation>
    </message>
    <message>
        <source>Ready.</source>
        <translation type="obsolete">A punt.</translation>
    </message>
    <message>
        <source>Cutting selection...</source>
        <translation type="obsolete">Tallant la selecció...</translation>
    </message>
    <message>
        <source>Copying selection to clipboard...</source>
        <translation type="obsolete">Copiant la selecció al portapapers...</translation>
    </message>
    <message>
        <source>Inserting clipboard contents...</source>
        <translation type="obsolete">Inserint el contingut del portapapers...</translation>
    </message>
    <message>
        <source>Toggle toolbar...</source>
        <translation type="obsolete">Mostrar/ Ocultar la barra d&apos;eines...</translation>
    </message>
    <message>
        <source>Toggle statusbar...</source>
        <translation type="obsolete">Mostrar/Ocultar la barra d&apos;estat...</translation>
    </message>
    <message>
        <source>Toggle full screen mode...</source>
        <translation type="obsolete">Mostrar/Ocultar en mode pantalla completa...</translation>
    </message>
    <message>
        <source>Plan de Cuentas</source>
        <translation type="obsolete">Pla de Contes</translation>
    </message>
    <message>
        <source>Introducci&#xf3;n de Borrador</source>
        <translation type="obsolete">Introducció de Borrador</translation>
    </message>
    <message>
        <source>Guardar Empresa</source>
        <translation type="obsolete">Desar Empresa</translation>
    </message>
    <message>
        <source>Cargar Empresa</source>
        <translation type="obsolete">Carregar Empresa</translation>
    </message>
    <message>
        <source>Gesti&#xf3;n de Usuarios</source>
        <translation type="obsolete">Gestió d&apos;Usuaris</translation>
    </message>
    <message>
        <source>Registro de IVA</source>
        <translation type="obsolete">Registre d&apos;IVA</translation>
    </message>
    <message>
        <source>&amp;Registro de IVA</source>
        <translation type="obsolete">&amp;Registre d&apos;IVA</translation>
    </message>
    <message>
        <source>Ver Libro Registro de IVA</source>
        <translation type="obsolete">Veure el llibre d&apos;IVA</translation>
    </message>
    <message>
        <source>Muestra/Oculta el corrector</source>
        <translation type="obsolete">Mostrar/Ocultar el corrector</translation>
    </message>
    <message>
        <source>Corrector

Muestra/oculta el corrector</source>
        <translation type="obsolete">Corrector

Mostrar/Ocultar el corrector</translation>
    </message>
    <message>
        <source>Amortizaciones</source>
        <translation type="obsolete">Amortitzacions</translation>
    </message>
    <message>
        <source>&amp;Amortizaciones</source>
        <translation type="obsolete">&amp;Amortitzacions</translation>
    </message>
    <message>
        <source>Sustituir Cuentas</source>
        <translation type="obsolete">Substituïr contes</translation>
    </message>
    <message>
        <source>&amp;Sustituir Cuentas</source>
        <translation type="obsolete">&amp;Substituïr Contes</translation>
    </message>
    <message>
        <source>Ver Corrector...</source>
        <translation type="obsolete">Veure Corrector ....</translation>
    </message>
</context>
<context>
    <name>DiarioPrintDlg</name>
    <message encoding="UTF-8">
        <source>Impresión del Diario</source>
        <translation>Impresió del Diari</translation>
    </message>
    <message>
        <source>Datos Listado</source>
        <translation>Dades del Llistat</translation>
    </message>
    <message>
        <source>Centro de Coste</source>
        <translation type="obsolete">Centre de Cost</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation type="obsolete">Canal</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation>Data Final</translation>
    </message>
    <message>
        <source>Documento</source>
        <translation>Document</translation>
    </message>
    <message>
        <source>Texto Plano</source>
        <translation>Text Pla</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Propietario</source>
        <translation>Propietari</translation>
    </message>
    <message>
        <source>Formato Listado</source>
        <translation>Format del Llistat</translation>
    </message>
    <message>
        <source>Formato Aprendizaje</source>
        <translation>Format d&apos;Aprenentatje</translation>
    </message>
    <message>
        <source>Formato Normal</source>
        <translation>Format Normal</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation>Imprimir</translation>
    </message>
</context>
<context>
    <name>DiarioPrintView</name>
    <message>
        <source>Libro Diario</source>
        <comment>Informe: </comment>
        <translation type="unfinished">Llibre Diari</translation>
    </message>
</context>
<context>
    <name>ExtractoPrintDlg</name>
    <message encoding="UTF-8">
        <source>Impresión del Extracto</source>
        <translation>Impresió de l&apos;Extracte</translation>
    </message>
    <message>
        <source>Datos Listado</source>
        <translation>Dades del Llistat</translation>
    </message>
    <message>
        <source>Centro de Coste</source>
        <translation type="obsolete">Centre de Cost</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation type="obsolete">Canal</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation>Data Final</translation>
    </message>
    <message encoding="UTF-8">
        <source>Código Inicial
</source>
        <translation>Codi Inicial
</translation>
    </message>
    <message encoding="UTF-8">
        <source>Código Final</source>
        <translation>Codi Final</translation>
    </message>
    <message>
        <source>Formato</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Texto Plano</source>
        <translation>Text Pla</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Propietario</source>
        <translation type="unfinished">Propietari</translation>
    </message>
</context>
<context>
    <name>ExtractoPrintView</name>
    <message>
        <source>Extracto de Cuentas</source>
        <comment>Informe: </comment>
        <translation type="unfinished">Extracte de contes</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Formulario 300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aviso: El n&#xfa;mero de cuenta bancario introducido
no se corresponde con un CCC correcto.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generar de todas formas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lo siento, no encuentro el formulario original en pdf.
Prueba a descargarlo desde www.aeat.es y gu&#xe1;rdalo en
/usr/share/bulmages/formularios/ o en
~/.bulmages/formularios/.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished">Acceptar</translation>
    </message>
    <message>
        <source>Creando formulario..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QmcDateNav</name>
    <message>
        <source>SEPTEMBER</source>
        <translation>SETEMBRE</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Diumenge</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation>Dilluns</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Dimarts</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Dimecres</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Dijous</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation>Divendres</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Dissapte</translation>
    </message>
    <message>
        <source>January</source>
        <translation>Gener</translation>
    </message>
    <message>
        <source>February</source>
        <translation>Febrer</translation>
    </message>
    <message>
        <source>March</source>
        <translation>Març</translation>
    </message>
    <message>
        <source>April</source>
        <translation>Abril</translation>
    </message>
    <message>
        <source>May</source>
        <translation>Maig</translation>
    </message>
    <message>
        <source>June</source>
        <translation>Juny</translation>
    </message>
    <message>
        <source>July</source>
        <translation>Juliol</translation>
    </message>
    <message>
        <source>August</source>
        <translation>Agost</translation>
    </message>
    <message>
        <source>September</source>
        <translation>Setembre</translation>
    </message>
    <message>
        <source>October</source>
        <translation>Octubre</translation>
    </message>
    <message>
        <source>November</source>
        <translation>Novembre</translation>
    </message>
    <message>
        <source>December</source>
        <translation>Decembre</translation>
    </message>
</context>
<context>
    <name>Splash</name>
    <message>
        <source>Comprobando nivel de combustible</source>
        <translation>Carregant el Solitari en segon pla</translation>
    </message>
    <message>
        <source>Calibrando los lasers del lector de CD</source>
        <translation>Calibrant els lasers del lector de CD</translation>
    </message>
    <message>
        <source>Comprobando la disquetera y la Memoria Fisica</source>
        <translation>Esborrant l&apos;SPAM</translation>
    </message>
    <message>
        <source>Induciendo energ&#xed;a quantica, entre su RAM y su ROM</source>
        <translation>Recalentant la CPU</translation>
    </message>
    <message>
        <source>Peque&#xf1;os golpecitos de reajuste del HD</source>
        <translation>Entrant a l&apos;IRC</translation>
    </message>
    <message>
        <source>Probando la Velocidad el Ventilador de la CPU y su Frecuencia</source>
        <translation>Reformatant les particions VFAT i NTFS a EXT2</translation>
    </message>
    <message>
        <source>Haciendo PING contra el servidor de la MetaBase</source>
        <translation>Entrant al Jabber, per veure als amics</translation>
    </message>
    <message>
        <source>Dejando tiempo libre al sistema</source>
        <translation>Eliminant altres programes de Contabilitat</translation>
    </message>
    <message>
        <source>Sincronizando fases Alfa Beta</source>
        <translation>Enjegant la WebCam</translation>
    </message>
    <message>
        <source>Flusheando Datos con vidas inteligentes superiores</source>
        <translation>Transmetent tots els Fons Bancaris a BulmaGés</translation>
    </message>
    <message>
        <source>Permutando las tablas de partici&#xf3;n del sistema operativo</source>
        <translation>Publicant a la clau d&apos;accés a la llista de correu BulmaGés</translation>
    </message>
    <message>
        <source>BulmaG&#xe9;s</source>
        <translation>BulmaGés</translation>
    </message>
    <message>
        <source>v 0.3.7</source>
        <translation type="obsolete">v0.3.7</translation>
    </message>
    <message>
        <source>BULMAGES</source>
        <translation type="obsolete">BULMAGÉS</translation>
    </message>
    <message>
        <source>v 0.4.3</source>
        <translation type="unfinished">v0.4.3</translation>
    </message>
    <message>
        <source>BULMAG&#xc9;S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Violando a Segmento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crackeando BulmaG&#xe9;s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIAlbaVenta</name>
    <message>
        <source>Abaran de Venta</source>
        <translation type="obsolete">Albarà de Venta</translation>
    </message>
    <message>
        <source>Albaranes del Cliente</source>
        <translation type="obsolete">Albarans del Client</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation type="obsolete">Imprimir</translation>
    </message>
    <message>
        <source>Contabilizar</source>
        <translation type="obsolete">Contabilitzar</translation>
    </message>
    <message>
        <source>Nuevo</source>
        <translation type="obsolete">Nou</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="obsolete">Borrar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Tancar</translation>
    </message>
    <message>
        <source>Totales </source>
        <translation type="obsolete">Totals</translation>
    </message>
    <message>
        <source>Recargo Finan.</source>
        <translation type="obsolete">Recàrrec Finan.</translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="obsolete">Total</translation>
    </message>
    <message>
        <source>% Dto. P.P.</source>
        <translation type="obsolete">% Dte. P.P.</translation>
    </message>
    <message>
        <source>Portes</source>
        <translation type="obsolete">Ports</translation>
    </message>
    <message encoding="UTF-8">
        <source>Total Albarán (€)</source>
        <translation type="obsolete">Total Albarà (€)</translation>
    </message>
    <message>
        <source>Base IVA</source>
        <translation type="obsolete">Base IVA</translation>
    </message>
    <message>
        <source>% IVA</source>
        <translation type="obsolete">% IVA</translation>
    </message>
    <message>
        <source>Imp. IVA</source>
        <translation type="obsolete">Imp. IVA</translation>
    </message>
    <message>
        <source>pushButton27</source>
        <translation type="obsolete">premBotó27</translation>
    </message>
    <message>
        <source>Opciones</source>
        <translation type="obsolete">Opcions</translation>
    </message>
    <message>
        <source>Lineas Albaran</source>
        <translation type="obsolete">Línies de l&apos;Albarà</translation>
    </message>
    <message>
        <source>Articulo</source>
        <translation type="obsolete">Article</translation>
    </message>
    <message encoding="UTF-8">
        <source>Descripción</source>
        <translation type="obsolete">Descripció</translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation type="obsolete">Unitats</translation>
    </message>
    <message>
        <source>Precio</source>
        <translation type="obsolete">Preu</translation>
    </message>
    <message>
        <source>Descuento</source>
        <translation type="obsolete">Descompte</translation>
    </message>
    <message>
        <source>Importe</source>
        <translation type="obsolete">Import</translation>
    </message>
    <message>
        <source>Buscar Articulo</source>
        <translation type="obsolete">Cercar Article</translation>
    </message>
    <message>
        <source>Insertar Linea</source>
        <translation type="obsolete">Inserir Línia</translation>
    </message>
    <message>
        <source>Albaran</source>
        <translation type="obsolete">Albarà</translation>
    </message>
    <message>
        <source>Factura</source>
        <translation type="obsolete">Factura</translation>
    </message>
    <message>
        <source>Cliente</source>
        <translation type="obsolete">Client</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="obsolete">Data</translation>
    </message>
    <message>
        <source>Orden</source>
        <translation type="obsolete">Ordre</translation>
    </message>
    <message>
        <source>Mantenimiento Articulo</source>
        <translation type="obsolete">Manteniment de l&apos;Article</translation>
    </message>
    <message>
        <source>Borrar Linea</source>
        <translation type="obsolete">Esborrar Línia</translation>
    </message>
    <message>
        <source>Primero</source>
        <translation type="obsolete">Primer</translation>
    </message>
    <message>
        <source>Posterior</source>
        <translation type="obsolete">Posterior</translation>
    </message>
    <message encoding="UTF-8">
        <source>Último</source>
        <translation type="obsolete">Darrer</translation>
    </message>
    <message>
        <source>Anterior</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message encoding="UTF-8">
        <source>ALBARÁN</source>
        <translation type="obsolete">ALBARÀ</translation>
    </message>
    <message>
        <source>Cabecera Albaran Venta</source>
        <translation type="obsolete">Capçalera de l&apos;Albara de Venta</translation>
    </message>
    <message>
        <source>Buscar Cliente</source>
        <translation type="obsolete">Cercar Client</translation>
    </message>
    <message>
        <source>Almacen:</source>
        <translation type="obsolete">Magatzem:</translation>
    </message>
    <message>
        <source>Fecha:</source>
        <translation type="obsolete">Data:</translation>
    </message>
    <message>
        <source>Mantenimiento Clientes</source>
        <translation type="obsolete">Manteniment de Clients</translation>
    </message>
    <message>
        <source>Factura:</source>
        <translation type="obsolete">Factura:</translation>
    </message>
    <message>
        <source>Numero:</source>
        <translation type="obsolete">Nombre:</translation>
    </message>
    <message>
        <source>Agente:</source>
        <translation type="obsolete">Agent:</translation>
    </message>
    <message>
        <source>A</source>
        <translation type="obsolete">A</translation>
    </message>
    <message>
        <source>B</source>
        <translation type="obsolete">B</translation>
    </message>
    <message>
        <source>C</source>
        <translation type="obsolete">C</translation>
    </message>
    <message encoding="UTF-8">
        <source>Serie Albarán</source>
        <translation type="obsolete">Serie d&apos;Albarà</translation>
    </message>
    <message>
        <source>Forma Pago:</source>
        <translation type="obsolete">Forma de Pagament:</translation>
    </message>
    <message>
        <source>Cliente:</source>
        <translation type="obsolete">Client:</translation>
    </message>
    <message encoding="UTF-8">
        <source>Dirección:</source>
        <translation type="obsolete">Adreça:</translation>
    </message>
    <message encoding="UTF-8">
        <source>Población:</source>
        <translation type="obsolete">Població:</translation>
    </message>
    <message>
        <source>Provincia:</source>
        <translation type="obsolete">Província:</translation>
    </message>
    <message>
        <source>NIF/CIF:</source>
        <translation type="obsolete">NIF/CIF:</translation>
    </message>
    <message>
        <source>Cod. Postal:</source>
        <translation type="obsolete">Dist. Postal:</translation>
    </message>
    <message encoding="UTF-8">
        <source>Observaciones Albarán</source>
        <translation type="obsolete">Observacions de l&apos;Albarà</translation>
    </message>
</context>
<context>
    <name>UIPediVenta</name>
    <message>
        <source>Pedidos de Venta</source>
        <translation type="obsolete">Comandes de Venta</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Tancar</translation>
    </message>
    <message>
        <source>Pedidos del Cliente</source>
        <translation type="obsolete">Comandes del Client</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation type="obsolete">Imprimir</translation>
    </message>
    <message>
        <source>Traspasar</source>
        <translation type="obsolete">Transpassar</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="obsolete">Borrar</translation>
    </message>
    <message>
        <source>Nuevo</source>
        <translation type="obsolete">Nou</translation>
    </message>
    <message>
        <source>Totales </source>
        <translation type="obsolete">Totals</translation>
    </message>
    <message>
        <source>Recargo Finan.</source>
        <translation type="obsolete">Recàrrec Finan.</translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="obsolete">Total</translation>
    </message>
    <message>
        <source>% Dto. P.P.</source>
        <translation type="obsolete">% Dte. P.P.</translation>
    </message>
    <message>
        <source>Portes</source>
        <translation type="obsolete">Ports</translation>
    </message>
    <message>
        <source>Base IVA</source>
        <translation type="obsolete">Base IVA</translation>
    </message>
    <message>
        <source>% IVA</source>
        <translation type="obsolete">% IVA</translation>
    </message>
    <message>
        <source>Imp. IVA</source>
        <translation type="obsolete">Imp. IVA</translation>
    </message>
    <message>
        <source>pushButton27</source>
        <translation type="obsolete">premBotó27</translation>
    </message>
    <message>
        <source>Opciones</source>
        <translation type="obsolete">Opcions</translation>
    </message>
    <message encoding="UTF-8">
        <source>Total Pedido (€)</source>
        <translation type="obsolete">Total Comanda  (€)</translation>
    </message>
    <message>
        <source>Cabecera Pedido Venta</source>
        <translation type="obsolete">Capçalera de la Comanda de Venta</translation>
    </message>
    <message encoding="UTF-8">
        <source>Dirección:</source>
        <translation type="obsolete">Adreça:</translation>
    </message>
    <message encoding="UTF-8">
        <source>Población:</source>
        <translation type="obsolete">Població:</translation>
    </message>
    <message>
        <source>Cliente:</source>
        <translation type="obsolete">Client:</translation>
    </message>
    <message>
        <source>Numero:</source>
        <translation type="obsolete">Nombre:</translation>
    </message>
    <message>
        <source>Mantenimiento Clientes</source>
        <translation type="obsolete">Manteniment de Clients</translation>
    </message>
    <message>
        <source>Buscar Cliente</source>
        <translation type="obsolete">Cercar Client</translation>
    </message>
    <message>
        <source>Lineas Pedido</source>
        <translation type="obsolete">Línies de la Comanda</translation>
    </message>
    <message>
        <source>Buscar Articulo</source>
        <translation type="obsolete">Cercar Article</translation>
    </message>
    <message>
        <source>Insertar Linea</source>
        <translation type="obsolete">Inserir Línia</translation>
    </message>
    <message>
        <source>Mantenimiento Articulo</source>
        <translation type="obsolete">Manteniment de l&apos;Article</translation>
    </message>
    <message>
        <source>Borrar Linea</source>
        <translation type="obsolete">Esborrar Línia</translation>
    </message>
    <message>
        <source>Primero</source>
        <translation type="obsolete">Primer</translation>
    </message>
    <message>
        <source>Posterior</source>
        <translation type="obsolete">Posterior</translation>
    </message>
    <message encoding="UTF-8">
        <source>Último</source>
        <translation type="obsolete">Darrer</translation>
    </message>
    <message>
        <source>Anterior</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message>
        <source>Pedido</source>
        <translation type="obsolete">Comanda</translation>
    </message>
    <message>
        <source>Cliente</source>
        <translation type="obsolete">Client</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="obsolete">Data</translation>
    </message>
    <message>
        <source>Orden</source>
        <translation type="obsolete">Ordre</translation>
    </message>
    <message>
        <source>Articulo</source>
        <translation type="obsolete">Article</translation>
    </message>
    <message encoding="UTF-8">
        <source>Descripción</source>
        <translation type="obsolete">Descripció</translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation type="obsolete">Unitats</translation>
    </message>
    <message>
        <source>Precio</source>
        <translation type="obsolete">Preu</translation>
    </message>
    <message>
        <source>Descuento</source>
        <translation type="obsolete">Descompte</translation>
    </message>
    <message>
        <source>Importe</source>
        <translation type="obsolete">Import</translation>
    </message>
    <message>
        <source>Uds. Servidas</source>
        <translation type="obsolete">Uni. Servides</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>10</source>
        <translation type="obsolete">10</translation>
    </message>
</context>
<context>
    <name>UIalmacen</name>
    <message>
        <source>Modulo Almacen</source>
        <translation type="obsolete">Mòdul del Magatzem</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation type="obsolete">Menu</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Eines</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="obsolete">Acció</translation>
    </message>
</context>
<context>
    <name>UIbloqFecha</name>
    <message>
        <source>Bloquear Fechas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished">Acceptar</translation>
    </message>
    <message>
        <source>Ejercicio</source>
        <translation type="unfinished">Exercici</translation>
    </message>
    <message>
        <source>Estado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIcompras</name>
    <message>
        <source>Modulo Compras</source>
        <translation type="obsolete">Mòdul de Compres</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation type="obsolete">Menu</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Eines</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="obsolete">Acció</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>UIconfiguracion</name>
    <message encoding="UTF-8">
        <source>Configuración</source>
        <translation type="obsolete">Configuració</translation>
    </message>
</context>
<context>
    <name>UImodelo347</name>
    <message>
        <source>Saldos Acumulados Superiores a ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importe</source>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation type="unfinished">Desar</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation type="unfinished">Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation type="unfinished">Data Final</translation>
    </message>
    <message>
        <source>Ventas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta</source>
        <translation type="unfinished">Conta</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished">CIF</translation>
    </message>
    <message>
        <source>Compras</source>
        <translation type="unfinished">Compres</translation>
    </message>
    <message>
        <source>Recargar datos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UInominas</name>
    <message>
        <source>Modulo Nominas</source>
        <translation type="obsolete">Mòdul de Nomines</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation type="obsolete">Menu</translation>
    </message>
    <message>
        <source>Toolbar</source>
        <translation type="obsolete">Barra d&apos;eines</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="obsolete">Acció</translation>
    </message>
</context>
<context>
    <name>UIproduccion</name>
    <message>
        <source>Modulo Produccion</source>
        <translation type="obsolete">Mòdul de Producció</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation type="obsolete">Menu</translation>
    </message>
    <message>
        <source>Toolbar</source>
        <translation type="obsolete">Barra d&apos;eines</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="obsolete">Acció</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>UIselector</name>
    <message>
        <source>Bulmages</source>
        <translation type="obsolete">BulmaGés</translation>
    </message>
    <message>
        <source>Empresa:</source>
        <translation>Empresa:</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Sortir</translation>
    </message>
    <message>
        <source>Seleccionar Empresa</source>
        <translation>Seleccionar Empresa</translation>
    </message>
    <message>
        <source>Contabilidad</source>
        <translation>Contabilitat</translation>
    </message>
    <message>
        <source>Stock Almacen</source>
        <translation>Stock del Magatzem</translation>
    </message>
    <message>
        <source>Nominas</source>
        <translation>Nomines</translation>
    </message>
    <message encoding="UTF-8">
        <source>Configuración</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <source>Gestion Compras</source>
        <translation>Gestió de Compres</translation>
    </message>
    <message encoding="UTF-8">
        <source>Producción</source>
        <translation>Producció</translation>
    </message>
    <message>
        <source>Gestion Ventas</source>
        <translation>Gestió de Ventes</translation>
    </message>
    <message encoding="UTF-8">
        <source>BulmaGès</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIventas</name>
    <message>
        <source>Modulo Ventas</source>
        <translation type="obsolete">Mòdul de Ventes</translation>
    </message>
    <message>
        <source>&amp;Archivos</source>
        <translation type="obsolete">&amp;Fitxers</translation>
    </message>
    <message>
        <source>&amp;Ventas</source>
        <translation type="obsolete">&amp;Ventes</translation>
    </message>
    <message>
        <source>&amp;Facturacion</source>
        <translation type="obsolete">&amp;Facturació</translation>
    </message>
    <message>
        <source>&amp;Listados</source>
        <translation type="obsolete">&amp;Llistats</translation>
    </message>
    <message>
        <source>&amp;Control</source>
        <translation type="obsolete">&amp;Control</translation>
    </message>
    <message>
        <source>&amp;Herramientas</source>
        <translation type="obsolete">&amp;Estris de fer feina</translation>
    </message>
    <message>
        <source>Modulos BulmaGes</source>
        <translation type="obsolete">Mòduls BulmaGés</translation>
    </message>
    <message>
        <source>A&amp;yuda</source>
        <translation type="obsolete">A&amp;juda</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Eines</translation>
    </message>
    <message>
        <source>Clientes</source>
        <translation type="obsolete">Clients</translation>
    </message>
    <message>
        <source>Ctrl+Shift+C</source>
        <translation type="obsolete">Ctrl+Shift+C</translation>
    </message>
    <message>
        <source>Articulos</source>
        <translation type="obsolete">Articles</translation>
    </message>
    <message>
        <source>Ctrl+Shift+A</source>
        <translation type="obsolete">Ctrl+Shift+A</translation>
    </message>
    <message>
        <source>Presupuestos</source>
        <translation type="obsolete">Presuposts</translation>
    </message>
    <message>
        <source>Pedidos</source>
        <translation type="obsolete">Comandes</translation>
    </message>
    <message>
        <source>Albaranes</source>
        <translation type="obsolete">Albarans</translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation type="obsolete">Ctrl+A</translation>
    </message>
    <message>
        <source>Series de Documentos</source>
        <translation type="obsolete">Sèries de Documents</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Tancar</translation>
    </message>
    <message>
        <source>Facturacion Automatica</source>
        <translation type="obsolete">Facturació Automàtica</translation>
    </message>
    <message>
        <source>Ver Factura...</source>
        <translation type="obsolete">Veure Factura...</translation>
    </message>
    <message>
        <source>Listado de Pedidos</source>
        <translation type="obsolete">Llistat de Comandes</translation>
    </message>
    <message>
        <source>Pendientes de Traspasar</source>
        <translation type="obsolete">Pendens de Transpassar</translation>
    </message>
    <message>
        <source>Listado de Albaranes</source>
        <translation type="obsolete">Llistat d&apos;Albarans</translation>
    </message>
    <message>
        <source>Pendientes de Entregar</source>
        <translation type="obsolete">Pendents d&apos;Entregar</translation>
    </message>
    <message>
        <source>Listado de Facturas</source>
        <translation type="obsolete">Llistat de Factures</translation>
    </message>
    <message>
        <source>Listado de Tarifas</source>
        <translation type="obsolete">Llistat de Tarifes</translation>
    </message>
    <message>
        <source>Listado de Ofertas</source>
        <translation type="obsolete">Llistat d&apos;Ofertes</translation>
    </message>
    <message>
        <source>Garantias</source>
        <translation type="obsolete">Garanties</translation>
    </message>
    <message>
        <source>Contratos Mantenimiento</source>
        <translation type="obsolete">Contractes de Manteniment</translation>
    </message>
    <message>
        <source>Selector</source>
        <translation type="obsolete">Selector</translation>
    </message>
    <message>
        <source>Acerca de...</source>
        <translation type="obsolete">Sobre la aplicació...</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation type="obsolete">Ajuda</translation>
    </message>
    <message>
        <source>Calculadora</source>
        <translation type="obsolete">Calculadora</translation>
    </message>
    <message>
        <source>Agenda</source>
        <translation type="obsolete">Agenda</translation>
    </message>
    <message>
        <source>Contabilidad</source>
        <translation type="obsolete">Contabilitat</translation>
    </message>
    <message>
        <source>Compras</source>
        <translation type="obsolete">Compres</translation>
    </message>
    <message encoding="UTF-8">
        <source>Configuración</source>
        <translation type="obsolete">Configuració</translation>
    </message>
    <message encoding="UTF-8">
        <source>Producción</source>
        <translation type="obsolete">Producció</translation>
    </message>
</context>
<context>
    <name>UIvisorEmpresas</name>
    <message>
        <source>Seleciona Empresa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished">Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <source>Ejercicio</source>
        <translation type="unfinished">Exercici</translation>
    </message>
    <message>
        <source>DBname</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>aboutdlg</name>
    <message>
        <source>Acerca de Bulmages</source>
        <translation>Sobre BulmaGés</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Crèdits</translation>
    </message>
    <message encoding="UTF-8">
        <source>Versión 0.3.5</source>
        <translation type="obsolete">Versió 0.3.5</translation>
    </message>
    <message>
        <source>&lt;p align=&quot;center&quot;&gt;&lt;b&gt;Contabilidad para Linux&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;&lt;b&gt;Contabilitat per a Linux&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Autores</source>
        <translation>Autors</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:-1pt;font-family:helvetica&quot; bgcolor=&quot;#FFFFFF&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot;margin-top:18px&quot;&gt;&lt;span style=&quot;font-weight:600&quot;&gt;Bulmages&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot;&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Programación&lt;/span&gt; &lt;br /&gt;Tomeu Borrás &lt;a href=&quot;mailto:tborras@conetxia.com&quot;&gt;tborras@conetxia.com&lt;/a&gt; &lt;br /&gt;
Antoni Mirabete &lt;a href=&quot;mailto:amirabet@biada.org&quot;&gt;amirabet@biada.org&lt;/a&gt; &lt;br /&gt;

Josep B. &lt;a href=&quot;mailto:josep@burcion.com&quot;&gt;josep@burcion.com&lt;/a&gt; &lt;br /&gt;

Oscar serna &lt;a href=&quot;mailto:oserna@regamallorca.com&quot;&gt;oserna@regamallorca.com&lt;/a&gt; &lt;br /&gt;Celso Gonzalez &lt;a href=&quot;mailto:mitago@ono.com&quot;&gt;mitago@ono.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Depuracion y manuales&lt;/span&gt; &lt;br /&gt;Cristina Marco &lt;a href=&quot;cmarco@conetxia.com&quot;&gt;cmarco@conetxia.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;WebMaster&lt;/span&gt;&lt;br&gt;Cristina Marco &lt;a href=&quot;cmarco@conetxia.com&quot;&gt;cmarco@conetxia.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Lista de Correo&lt;/span&gt;&lt;br /&gt;Tomeu Borrás &lt;a href=&quot;tborras@conetxia.com&quot;&gt;tborras@conetxia.com&lt;/a&gt;&lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Asesoramiento&lt;/span&gt; &lt;br /&gt;Antoni Aloy &lt;a href=&quot;mailto:aloy@ctv.es&quot;&gt;aloy@ctv.es&lt;/a&gt;&lt;br /&gt;Mª Dolores Hernandez &lt;a href=&quot;mailto:mdhernandez@conetxia.com&quot;&gt;mdhernandez@conetxia.comt&lt;/a&gt;  &lt;br /&gt;Fco. Javier M. C. &lt;a href=&quot;mailto:fcojavmc@todo-redes.com&quot;&gt;fcojavmc@todo-redes.com&lt;/a&gt;&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:-1pt;font-family:helvetica&quot; bgcolor=&quot;#FFFFFF&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot;margin-top:18px&quot;&gt;&lt;span style=&quot;font-weight:600&quot;&gt;BulmaGés&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot;&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Programació&lt;/span&gt; &lt;br /&gt;Tomeu Borrás &lt;a href=&quot;mailto:tborras@conetxia.com&quot;&gt;tborras@conetxia.com&lt;/a&gt; &lt;br /&gt;
Antoni Mirabete &lt;a href=&quot;mailto:amirabet@biada.org&quot;&gt;amirabet@biada.org&lt;/a&gt; &lt;br /&gt;

Josep B. &lt;a href=&quot;mailto:josep@burcion.com&quot;&gt;josep@burcion.com&lt;/a&gt; &lt;br /&gt;

Oscar serna &lt;a href=&quot;mailto:oserna@regamallorca.com&quot;&gt;oserna@regamallorca.com&lt;/a&gt; &lt;br /&gt;Celso Gonzalez &lt;a href=&quot;mailto:mitago@ono.com&quot;&gt;mitago@ono.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Depuració i manuals&lt;/span&gt; &lt;br /&gt;Cristina Marco &lt;a href=&quot;cmarco@conetxia.com&quot;&gt;cmarco@conetxia.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;WebMaster&lt;/span&gt;&lt;br&gt;Cristina Marco &lt;a href=&quot;cmarco@conetxia.com&quot;&gt;cmarco@conetxia.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Llista de Correu&lt;/span&gt;&lt;br /&gt;Tomeu Borrás &lt;a href=&quot;tborras@conetxia.com&quot;&gt;tborras@conetxia.com&lt;/a&gt;&lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Traducció&lt;/span&gt;&lt;br /&gt;Antoni Villalonga &lt;a href=&quot;webmaster@friki.org&quot;&gt;webmaster@friki.org&lt;/a&gt;&lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Assessorament&lt;/span&gt; &lt;br /&gt;Antoni Aloy &lt;a href=&quot;mailto:aloy@ctv.es&quot;&gt;aloy@ctv.es&lt;/a&gt;&lt;br /&gt;Mª Dolores Hernandez &lt;a href=&quot;mailto:mdhernandez@conetxia.com&quot;&gt;mdhernandez@conetxia.comt&lt;/a&gt;  &lt;br /&gt;Fco. Javier M. C. &lt;a href=&quot;mailto:fcojavmc@todo-redes.com&quot;&gt;fcojavmc@todo-redes.com&lt;/a&gt;&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>Soporte</source>
        <translation>Suport</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:-1pt;font-family:helvetica&quot; bgcolor=&quot;#FFFFFF&quot;&gt;
&lt;p style=&quot;margin-top:14px&quot;&gt;&lt;span style=&quot;font-weight:600&quot;&gt;Entidades que dan soporte al programa:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot;&gt;
&lt;br /&gt;&lt;img src=/usr/share/bulmages/logopeq.png &gt;&lt;br /&gt;&lt;a href=&quot;http://www.conetxia.com&quot;&gt;http://www.conetxia.com&lt;/a&gt; &lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;br /&gt;&lt;br /&gt;&lt;img src=/usr/share/bulmages/bulma_small.jpg width=300 &gt;&lt;br /&gt;&lt;a href=&quot;http://bulmalug.net&quot;&gt;http://bulmalug.net&lt;/a&gt;&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:-1pt;font-family:helvetica&quot; bgcolor=&quot;#FFFFFF&quot;&gt;
&lt;p style=&quot;margin-top:14px&quot;&gt;&lt;span style=&quot;font-weight:600&quot;&gt;Entitats que donen suport al programa:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot;&gt;
&lt;br /&gt;&lt;img src=/usr/share/bulmages/logopeq.png &gt;&lt;br /&gt;&lt;a href=&quot;http://www.conetxia.com&quot;&gt;http://www.conetxia.com&lt;/a&gt; &lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;br /&gt;&lt;br /&gt;&lt;img src=/usr/share/bulmages/bulma_small.jpg width=300 &gt;&lt;br /&gt;&lt;a href=&quot;http://bulma.net&quot;&gt;http://bulma.net&lt;/a&gt;&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Licencia</source>
        <translation>Llicència</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;PRE&gt;
Este programa está distribuido bajo los términos de GPL v2.

<byte value="x9"/><byte value="x9"/>    GNU GENERAL PUBLIC LICENSE
<byte value="x9"/><byte value="x9"/>       Version 2, June 1991

 Copyright (C) 1989, 1991 Free Software Foundation, Inc.
                          675 Mass Ave, Cambridge, MA 02139, USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

<byte value="x9"/><byte value="x9"/><byte value="x9"/>    Preamble

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation&apos;s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author&apos;s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors&apos; reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone&apos;s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.
 
<byte value="x9"/><byte value="x9"/>    GNU GENERAL PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The &quot;Program&quot;, below,
refers to any such program or work, and a &quot;work based on the Program&quot;
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term &quot;modification&quot;.)  Each licensee is addressed as &quot;you&quot;.

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program&apos;s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)
 
These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.
 
  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients&apos; exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.
 
  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and &quot;any
later version&quot;, you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

<byte value="x9"/><byte value="x9"/><byte value="x9"/>    NO WARRANTY

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM &quot;AS IS&quot; WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

<byte value="x9"/><byte value="x9"/>     END OF TERMS AND CONDITIONS


<byte value="x9"/>    How to Apply These Terms to Your New Programs

  If you develop a new program, and you want it to be of the greatest
possible use to the public, the best way to achieve this is to make it
free software which everyone can redistribute and change under these terms.

  To do so, attach the following notices to the program.  It is safest
to attach them to the start of each source file to most effectively
convey the exclusion of warranty; and each file should have at least
the &quot;copyright&quot; line and a pointer to where the full notice is found.

    &lt;one line to give the program&apos;s name and a brief idea of what it does.&gt;
    Copyright (C) 19yy  &lt;name of author&gt;

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


Also add information on how to contact you by electronic and paper mail.

If the program is interactive, make it output a short notice like this
when it starts in an interactive mode:

    Gnomovision version 69, Copyright (C) 19yy name of author
    Gnomovision comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.
    This is free software, and you are welcome to redistribute it
    under certain conditions; type `show c&apos; for details.

The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate
parts of the General Public License.  Of course, the commands you use may
be called something other than `show w&apos; and `show c&apos;; they could even be
mouse-clicks or menu items--whatever suits your program.

You should also get your employer (if you work as a programmer) or your
school, if any, to sign a &quot;copyright disclaimer&quot; for the program, if
necessary.  Here is a sample; alter the names:

  Yoyodyne, Inc., hereby disclaims all copyright interest in the program
  `Gnomovision&apos; (which makes passes at compilers) written by James Hacker.

  &lt;signature of Ty Coon&gt;, 1 April 1989
  Ty Coon, President of Vice

This General Public License does not permit incorporating your program into
proprietary programs.  If your program is a subroutine library, you may
consider it more useful to permit linking proprietary applications with the
library.  If this is what you want to do, use the GNU Library General
Public License instead of this License.
&lt;/PRE&gt;</source>
        <translation>&lt;PRE&gt;
Aquest programa està distribuit baix els termes de GPL v2.

<byte value="x9"/><byte value="x9"/>    GNU GENERAL PUBLIC LICENSE
<byte value="x9"/><byte value="x9"/>       Version 2, June 1991

 Copyright (C) 1989, 1991 Free Software Foundation, Inc.
                          675 Mass Ave, Cambridge, MA 02139, USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

<byte value="x9"/><byte value="x9"/><byte value="x9"/>    Preamble

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation&apos;s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author&apos;s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors&apos; reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone&apos;s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.
 
<byte value="x9"/><byte value="x9"/>    GNU GENERAL PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The &quot;Program&quot;, below,
refers to any such program or work, and a &quot;work based on the Program&quot;
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term &quot;modification&quot;.)  Each licensee is addressed as &quot;you&quot;.

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program&apos;s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)
 
These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.
 
  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients&apos; exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.
 
  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and &quot;any
later version&quot;, you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

<byte value="x9"/><byte value="x9"/><byte value="x9"/>    NO WARRANTY

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM &quot;AS IS&quot; WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

<byte value="x9"/><byte value="x9"/>     END OF TERMS AND CONDITIONS


<byte value="x9"/>    How to Apply These Terms to Your New Programs

  If you develop a new program, and you want it to be of the greatest
possible use to the public, the best way to achieve this is to make it
free software which everyone can redistribute and change under these terms.

  To do so, attach the following notices to the program.  It is safest
to attach them to the start of each source file to most effectively
convey the exclusion of warranty; and each file should have at least
the &quot;copyright&quot; line and a pointer to where the full notice is found.

    &lt;one line to give the program&apos;s name and a brief idea of what it does.&gt;
    Copyright (C) 19yy  &lt;name of author&gt;

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


Also add information on how to contact you by electronic and paper mail.

If the program is interactive, make it output a short notice like this
when it starts in an interactive mode:

    Gnomovision version 69, Copyright (C) 19yy name of author
    Gnomovision comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.
    This is free software, and you are welcome to redistribute it
    under certain conditions; type `show c&apos; for details.

The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate
parts of the General Public License.  Of course, the commands you use may
be called something other than `show w&apos; and `show c&apos;; they could even be
mouse-clicks or menu items--whatever suits your program.

You should also get your employer (if you work as a programmer) or your
school, if any, to sign a &quot;copyright disclaimer&quot; for the program, if
necessary.  Here is a sample; alter the names:

  Yoyodyne, Inc., hereby disclaims all copyright interest in the program
  `Gnomovision&apos; (which makes passes at compilers) written by James Hacker.

  &lt;signature of Ty Coon&gt;, 1 April 1989
  Ty Coon, President of Vice

This General Public License does not permit incorporating your program into
proprietary programs.  If your program is a subroutine library, you may
consider it more useful to permit linking proprietary applications with the
library.  If this is what you want to do, use the GNU Library General
Public License instead of this License.
&lt;/PRE&gt;</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Versió 0.3.7</translation>
    </message>
    <message encoding="UTF-8">
        <source>Versión 0.4.3</source>
        <translation type="unfinished">Versió 0.4.3</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:-1pt;font-family:helvetica&quot; bgcolor=&quot;#FFFFFF&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot;margin-top:18px&quot;&gt;&lt;span style=&quot;font-weight:600&quot;&gt;BulmaGés&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot;&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Programación&lt;/span&gt; &lt;br /&gt;Tomeu Borrás &lt;a href=&quot;mailto:tborras@conetxia.com&quot;&gt;tborras@conetxia.com&lt;/a&gt; &lt;br /&gt;
Antoni Mirabete &lt;a href=&quot;mailto:amirabet@biada.org&quot;&gt;amirabet@biada.org&lt;/a&gt; &lt;br /&gt;

Josep Burción &lt;a href=&quot;mailto:josep@burcion.com&quot;&gt;josep@burcion.com&lt;/a&gt; &lt;br /&gt;

Oscar serna &lt;a href=&quot;mailto:oserna@regamallorca.com&quot;&gt;oserna@regamallorca.com&lt;/a&gt; &lt;br /&gt;Celso Gonzalez &lt;a href=&quot;mailto:mitago@ono.com&quot;&gt;mitago@ono.com&lt;/a&gt; &lt;br /&gt;

Jean René Mèrou &lt;br /&gt;
 Fco. Javier M.C. &lt;br /&gt;
 Victor G. Marimón &lt;br /&gt;
 Beatriu Romero &lt;br /&gt;
 Ramón Navarro &lt;br /&gt;

 &lt;br /&gt;
&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Depuracion y manuales&lt;/span&gt; &lt;br /&gt;Cristina Marco &lt;a href=&quot;cmarco@conetxia.com&quot;&gt;cmarco@conetxia.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;WebMaster&lt;/span&gt;&lt;br&gt;Cristina Marco &lt;a href=&quot;cmarco@conetxia.com&quot;&gt;cmarco@conetxia.com&lt;/a&gt; &lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Lista de Correo&lt;/span&gt;&lt;br /&gt;Tomeu Borrás &lt;a href=&quot;tborras@conetxia.com&quot;&gt;tborras@conetxia.com&lt;/a&gt;&lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-weight:600;text-decoration:underline&quot;&gt;Asesoramiento&lt;/span&gt; &lt;br /&gt;Antoni Aloy &lt;a href=&quot;mailto:aloy@ctv.es&quot;&gt;aloy@ctv.es&lt;/a&gt;&lt;br /&gt;Mª Dolores Hernandez &lt;a href=&quot;mailto:mdhernandez@conetxia.com&quot;&gt;mdhernandez@conetxia.comt&lt;/a&gt;  &lt;br /&gt;Fco. Javier M. C. &lt;a href=&quot;mailto:fcojavmc@todo-redes.com&quot;&gt;fcojavmc@todo-redes.com&lt;/a&gt;&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:-1pt;font-family:helvetica&quot; bgcolor=&quot;#FFFFFF&quot;&gt;
&lt;p style=&quot;margin-top:14px&quot;&gt;&lt;span style=&quot;font-weight:600&quot;&gt;Entidades que dan soporte al programa:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot;&gt;
&lt;img src=/usr/share/bulmages/logopeq.png &gt;&lt;br /&gt;&lt;a href=&quot;http://www.conetxia.com&quot;&gt;http://www.conetxia.com&lt;/a&gt; &lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;br /&gt;&lt;br /&gt;&lt;img src=/usr/share/bulmages/bulma_small.jpg width=300 &gt;&lt;br /&gt;&lt;a href=&quot;http://bulma.net&quot;&gt;http://bulma.net&lt;/a&gt;&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>abreempresadlg</name>
    <message>
        <source>Abrir Empresa</source>
        <translation>Obrir Emrpesa</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message encoding="UTF-8">
        <source>Año</source>
        <translation>Any</translation>
    </message>
    <message>
        <source>Archivo</source>
        <translation>Fitxer</translation>
    </message>
    <message encoding="UTF-8">
        <source>Identificación</source>
        <translation>Identificació</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Usuari</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Clau</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Abrir Empresa</source>
        <comment>Sirve para seleccionar la empresa con la que se quiere trabajar</comment>
        <translation type="unfinished">Obrir Emrpesa</translation>
    </message>
</context>
<context>
    <name>actualizacionesdlg</name>
    <message>
        <source>Actualizaciones</source>
        <translation>Actualitzacions</translation>
    </message>
    <message>
        <source>http://www.conetxia.com</source>
        <translation>http://www.conetxia.com</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
</context>
<context>
    <name>adocumental</name>
    <message>
        <source>COL_IDADOCUMENTAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDASIENTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_DESCRIPCIONADOCUMENTAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FECHAINTADOCUMENTAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FECHAASADOCUMENTAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_ARCHIVOADOCUMENTAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_ORDENASIENTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Punteos (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Agregar Documento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elige el nombre de archivo</source>
        <translation type="unfinished">Elegeixi el nom del fitxer</translation>
    </message>
</context>
<context>
    <name>adocumentalbase</name>
    <message>
        <source>Archivo Documental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iadocumental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>archivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>idasiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished">Comentaris</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished">Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ainteligentesdlg</name>
    <message>
        <source>Asientos Inteligentes</source>
        <translation>Assentaments Inteligents</translation>
    </message>
    <message>
        <source>Apuntes</source>
        <translation>Apunts</translation>
    </message>
    <message>
        <source>Registro IVA</source>
        <translation type="obsolete">Registre IVA</translation>
    </message>
    <message encoding="UTF-8">
        <source>Aplicación Automática</source>
        <translation>Aplicació Automàtica</translation>
    </message>
    <message>
        <source>Usar Aplicacion Automatica del Asiento</source>
        <translation>Usar Amplicació Automàtica de l&apos;Asiento</translation>
    </message>
    <message>
        <source>Periodicidad</source>
        <translation>Periodicitat</translation>
    </message>
    <message encoding="UTF-8">
        <source>Normas de Aplicación</source>
        <translation>Normes de l&apos;Aplicació</translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation>Comentaris</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Exportar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ainteligentesview</name>
    <message>
        <source>IDBINTELIGENTE</source>
        <translation>IDBINTELIGENT</translation>
    </message>
    <message>
        <source>IDAINTELIGENTE</source>
        <translation>IDAINTELIGENT</translation>
    </message>
    <message>
        <source>IDDIARIO</source>
        <translation>IDDIARI</translation>
    </message>
    <message>
        <source>FECHA</source>
        <translation>DATA</translation>
    </message>
    <message>
        <source>CONCEPTOCONTABLE</source>
        <translation>CONCEPTECONTABLE</translation>
    </message>
    <message>
        <source>CODCUENTA</source>
        <translation>CODCOMPTE</translation>
    </message>
    <message>
        <source>DESCRIPCION</source>
        <translation>DESCRIPCIÓ</translation>
    </message>
    <message>
        <source>DEBE</source>
        <translation>DEBE</translation>
    </message>
    <message>
        <source>HABER</source>
        <translation>HABER</translation>
    </message>
    <message>
        <source>CONTRAPARTIDA</source>
        <translation>CONTRAPARTIDA</translation>
    </message>
    <message>
        <source>COMENTARIO</source>
        <translation>COMENTARI</translation>
    </message>
    <message>
        <source>CANAL</source>
        <translation>CANAL</translation>
    </message>
    <message>
        <source>MARCACONCILIACION</source>
        <translation>MARCACONCILIACIÓ</translation>
    </message>
    <message>
        <source>IDC_COSTE</source>
        <translation>IDC_COST</translation>
    </message>
    <message>
        <source>CENTRO COSTE</source>
        <translation>CENTRE COST</translation>
    </message>
    <message>
        <source>COL_IDIVAINTELIGENTE</source>
        <translation type="obsolete">COL_IDIVAINTELIGENT</translation>
    </message>
    <message>
        <source>COL_IDAINTELIGENTEIVA</source>
        <translation type="obsolete">COL_IDAINTELIGENTIVA</translation>
    </message>
    <message>
        <source>COL_IDBINTELIGENTEIVA</source>
        <translation type="obsolete">COL_IDBINTELIGENTIVA</translation>
    </message>
    <message>
        <source>BASE IMP.</source>
        <translation type="obsolete">BASE IMP.</translation>
    </message>
    <message>
        <source>IVA</source>
        <translation type="obsolete">IVA</translation>
    </message>
    <message>
        <source>NUM. FACTURA</source>
        <translation type="obsolete">NUM. FACTURA</translation>
    </message>
    <message>
        <source>Col. Borrador</source>
        <translation type="obsolete">Col. Borrador</translation>
    </message>
    <message>
        <source>Registro</source>
        <translation type="obsolete">Registre</translation>
    </message>
    <message>
        <source>Regularizacion</source>
        <translation type="obsolete">Regularització</translation>
    </message>
    <message>
        <source>Plan 349</source>
        <translation type="obsolete">Pla 349</translation>
    </message>
    <message>
        <source>Num. Orden</source>
        <translation type="obsolete">Num. Ordre</translation>
    </message>
    <message>
        <source>CIF Empresa</source>
        <translation type="obsolete">CIF Empresa</translation>
    </message>
    <message>
        <source>Nuevo Asiento Inteligente</source>
        <translation>Nou Assentament Inteligent</translation>
    </message>
    <message>
        <source>AInteligente (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guardar Asiento Inteligente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elige el nombre de archivo</source>
        <translation type="unfinished">Elegeixi el nom del fitxer</translation>
    </message>
    <message>
        <source>Asientos Inteligentes (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cargar Asientos Inteligentes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>amortizaciondlg</name>
    <message>
        <source>Amortizacion</source>
        <translation>Amortització</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message encoding="UTF-8">
        <source>Amortización</source>
        <translation>Amortització</translation>
    </message>
    <message>
        <source>Cuotas</source>
        <translation>Quotes</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Cantidad</source>
        <translation>Quantitat</translation>
    </message>
    <message encoding="UTF-8">
        <source>Nº Asiento</source>
        <translation>Num. Assentament</translation>
    </message>
    <message>
        <source>Ejercicio</source>
        <translation>Exercici</translation>
    </message>
    <message>
        <source>Amortizado</source>
        <translation>Amortitzat</translation>
    </message>
    <message>
        <source>Pendiente</source>
        <translation>Pendent</translation>
    </message>
    <message encoding="UTF-8">
        <source>Núm. Cuotas</source>
        <translation>Num. Quotes</translation>
    </message>
    <message>
        <source>Periodicidad</source>
        <translation>Periodicitat</translation>
    </message>
    <message>
        <source>Anual</source>
        <translation>Anual</translation>
    </message>
    <message>
        <source>Semestral</source>
        <translation>Semestral</translation>
    </message>
    <message>
        <source>Trimestral</source>
        <translation>Trimestral</translation>
    </message>
    <message>
        <source>Mensual</source>
        <translation>Mensual</translation>
    </message>
    <message>
        <source>Valor de Compra</source>
        <translation>Valor de la Compra</translation>
    </message>
    <message>
        <source>Fecha de Compra</source>
        <translation>Data de la Compra</translation>
    </message>
    <message encoding="UTF-8">
        <source>Fecha 1ª Cuota</source>
        <translation>Data de la 1a Quota</translation>
    </message>
    <message>
        <source>Cuenta de Activo</source>
        <translation>Conta d&apos;Actiu</translation>
    </message>
    <message encoding="UTF-8">
        <source>Cuenta de Amortización</source>
        <translation>Conta d&apos;Amortització</translation>
    </message>
    <message encoding="UTF-8">
        <source>Método</source>
        <translation>Mètode</translation>
    </message>
    <message>
        <source>Incremental</source>
        <translation>Incremental</translation>
    </message>
    <message>
        <source>Lineal</source>
        <translation>Lineal</translation>
    </message>
    <message>
        <source>Decremental</source>
        <translation>Decremental</translation>
    </message>
    <message>
        <source>Porcentual</source>
        <translation>Percentual</translation>
    </message>
    <message>
        <source>Datos Proveedor</source>
        <translation>Dades del Proveedor</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>IdLinAmortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Num. Asiento</source>
        <translation type="unfinished">Num. Assentament</translation>
    </message>
    <message>
        <source>Calcular</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Agrupación</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>amortizacionesdlg</name>
    <message>
        <source>Listado de Amortizaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar Amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Borrar Amortización</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>amortizacionesview</name>
    <message>
        <source>CODIGO</source>
        <translation type="unfinished">CODI</translation>
    </message>
    <message>
        <source>Nombre Bien Amortizado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>amortizacionview</name>
    <message>
        <source>Error...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ocurri&#xf3; un error con la Base de Datos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished">Acceptar</translation>
    </message>
    <message>
        <source>Anual</source>
        <translation type="unfinished">Anual</translation>
    </message>
    <message>
        <source>Mensual</source>
        <translation type="unfinished">Mensual</translation>
    </message>
    <message>
        <source>Semestral</source>
        <translation type="unfinished">Semestral</translation>
    </message>
    <message>
        <source>Trimestral</source>
        <translation type="unfinished">Trimestral</translation>
    </message>
    <message>
        <source>Generar Asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ver Asiento</source>
        <translation type="unfinished">Veure Assentament</translation>
    </message>
    <message>
        <source>Desvincular Asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar Asiento</source>
        <translation type="unfinished">Borrar Assentament</translation>
    </message>
    <message>
        <source>Insertar Cuota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar Cuota</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>aplinteligentesdlg</name>
    <message>
        <source>Aplicar Asiento Inteligente</source>
        <translation>Aplicar Assentament Inteligent</translation>
    </message>
    <message>
        <source>Datos Asiento</source>
        <translation>Dades de l&apos;Assentament</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Plantilla</source>
        <translation>Plantilla</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Fecha Asiento</source>
        <translation>Data de l&apos;Assentament</translation>
    </message>
</context>
<context>
    <name>asientodlg</name>
    <message>
        <source>Edicion de Asientos</source>
        <translation>Edició de Assentaments</translation>
    </message>
    <message>
        <source>Descripcion</source>
        <translation>Descripció</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Numero</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Apertura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Regularización</source>
        <translation type="unfinished">Regularització</translation>
    </message>
    <message>
        <source>Cierre</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>asientosdlg</name>
    <message>
        <source>Asientos</source>
        <translation>Assentaments</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
</context>
<context>
    <name>asientosview</name>
    <message>
        <source>Num.</source>
        <translation>Num.</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Debe</source>
        <translation>Deba</translation>
    </message>
    <message>
        <source>Haber</source>
        <translation>Haber</translation>
    </message>
    <message>
        <source>Cerrado</source>
        <translation>Tancat</translation>
    </message>
    <message>
        <source>Orden</source>
        <translation>Ordre</translation>
    </message>
    <message>
        <source>Si</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
</context>
<context>
    <name>asientoview</name>
</context>
<context>
    <name>balance1dlg</name>
    <message>
        <source>Balance de Cuentas</source>
        <translation>Balanç de Contes</translation>
    </message>
    <message>
        <source>Totales:</source>
        <translation>Totals:</translation>
    </message>
    <message>
        <source>Cuenta inicial</source>
        <translation>Conta inicial</translation>
    </message>
    <message>
        <source>Cuenta final</source>
        <translation>Conta final</translation>
    </message>
    <message>
        <source>C. Coste</source>
        <translation>C. Cost</translation>
    </message>
    <message>
        <source>Nivel </source>
        <translation>Nivell</translation>
    </message>
    <message>
        <source>Fecha inicial</source>
        <translation>Data inicial</translation>
    </message>
    <message>
        <source>Fecha final</source>
        <translation>Data Final</translation>
    </message>
</context>
<context>
    <name>balance1view</name>
    <message>
        <source>Ver Diario (Este dia)</source>
        <translation>Veure el Diari (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Diario (Este mes)</source>
        <translation>Veure el Diari (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Diario (Este a&#xf1;o)</source>
        <translation>Veure el Diari (Aquest any)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este dia)</source>
        <translation>Veure Extracte (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este mes)</source>
        <translation>Veure Extracte (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este a&#xf1;o)</source>
        <translation>Veure Extracte (Aquest any)</translation>
    </message>
</context>
<context>
    <name>balancedlg</name>
    <message>
        <source>Balance de Cuentas</source>
        <translation>Balanç de Contes</translation>
    </message>
    <message>
        <source>Totales:</source>
        <translation>Totals:</translation>
    </message>
    <message>
        <source>Cuenta inicial</source>
        <translation>Conta inicial</translation>
    </message>
    <message>
        <source>Cuenta final</source>
        <translation>Conta final</translation>
    </message>
    <message>
        <source>C. Coste</source>
        <translation>C. Cost</translation>
    </message>
    <message>
        <source>Nivel</source>
        <translation>Nivell</translation>
    </message>
    <message>
        <source>Fecha inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha final</source>
        <translation>Data Final</translation>
    </message>
</context>
<context>
    <name>balancesdlg</name>
    <message>
        <source>Listado de Balances</source>
        <translation>Llistat de Balanços</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Exportar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>balancesprintdlg</name>
    <message encoding="UTF-8">
        <source>Impresión de Balances</source>
        <translation>Impressió de Balanços</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation>Data Final</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Balanç</translation>
    </message>
    <message>
        <source>Formato</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>texto plano</source>
        <translation>text pla</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
</context>
<context>
    <name>balancesview</name>
    <message>
        <source>CODIGO</source>
        <translation>CODI</translation>
    </message>
    <message>
        <source>Nombre Balance</source>
        <translation>Nom del Balanç</translation>
    </message>
    <message>
        <source>Balances (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guardar Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elige el nombre de archivo</source>
        <translation type="unfinished">Elegeixi el nom del fitxer</translation>
    </message>
    <message>
        <source>Asientos Inteligentes (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cargar Asientos Inteligentes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>balanceview</name>
    <message>
        <source>Cuenta</source>
        <translation>Conta</translation>
    </message>
    <message>
        <source>Denominacion</source>
        <translation>Denominació</translation>
    </message>
    <message>
        <source>Saldo Ant.</source>
        <translation>Saldo Ant.</translation>
    </message>
    <message>
        <source>Debe Periodo</source>
        <translation>Debe Periode</translation>
    </message>
    <message>
        <source>Haber Periodo</source>
        <translation>Haber Periode</translation>
    </message>
    <message>
        <source>Saldo Periodo</source>
        <translation>Saldo Periode</translation>
    </message>
    <message>
        <source>Debe Ejercicio</source>
        <translation>Debe Exercici</translation>
    </message>
    <message>
        <source>Haber Ejercicio</source>
        <translation>Haber Exercici</translation>
    </message>
    <message>
        <source>Saldo Ejercicio</source>
        <translation>Saldo Exercici</translation>
    </message>
    <message>
        <source>Ver Extracto (Este dia)</source>
        <translation>Veure Extracte (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este mes)</source>
        <translation>Veure Extracte (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este a&#xf1;o)</source>
        <translation>Veure Extracte (Aquest any)</translation>
    </message>
    <message>
        <source>Ver Diario (Este dia)</source>
        <translation>Veure el Diari (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Diario (Este mes)</source>
        <translation>Veure el Diari (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Diario (Este a&#xf1;o)</source>
        <translation>Veure el Diari (Aquest any)</translation>
    </message>
    <message>
        <source>Editar Cuenta</source>
        <translation>Editar Conta</translation>
    </message>
</context>
<context>
    <name>calendario</name>
    <message>
        <source>General</source>
        <translation type="obsolete">General</translation>
    </message>
    <message>
        <source>Non-working Days</source>
        <translation type="obsolete">Dies no laborables</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation type="obsolete">Dilluns</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation type="obsolete">Dimarts</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation type="obsolete">Dimecres</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation type="obsolete">Dijous</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation type="obsolete">Divendres</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation type="obsolete">Dissabte</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation type="obsolete">Diumenge</translation>
    </message>
</context>
<context>
    <name>cambiactadlg</name>
    <message>
        <source>Cambiar Cuenta</source>
        <translation>Canviar conta</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Asiento Inicial</source>
        <translation>Assentament Inicial</translation>
    </message>
    <message>
        <source>Asiento Final</source>
        <translation>Assentament Final</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation>Data Final</translation>
    </message>
    <message>
        <source>Cuenta Origen</source>
        <translation>Conta Origen</translation>
    </message>
    <message>
        <source>Cuenta Destino</source>
        <translation>Conta Destí</translation>
    </message>
</context>
<context>
    <name>canaldlg</name>
    <message>
        <source>Canales</source>
        <translation>Canals</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation>Canal</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Sortir</translation>
    </message>
    <message encoding="UTF-8">
        <source>Información del canal</source>
        <translation>Informació del canal</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Descripcion</source>
        <translation>Descripció</translation>
    </message>
</context>
<context>
    <name>ccostedlg</name>
    <message>
        <source>Centros de Coste</source>
        <translation>Centres de Cost</translation>
    </message>
    <message>
        <source>Centro de coste</source>
        <translation type="obsolete">Centre de Cost</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Sortir</translation>
    </message>
    <message>
        <source>Contenido del Centro de Coste</source>
        <translation>Contingut del Centre de Cost</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Descripcion</source>
        <translation>Descripció</translation>
    </message>
</context>
<context>
    <name>cobropagodlg</name>
    <message encoding="UTF-8">
        <source>Gestión de Cobros y Pagos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generar Asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta</source>
        <translation type="unfinished">Conta</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation type="unfinished">Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation type="unfinished">Data Final</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished">Acceptar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cobropagoview</name>
    <message>
        <source>COL_IDPREVCOBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Prevista</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Efectiva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IDCUENTA</source>
        <translation type="unfinished">IDCONTA</translation>
    </message>
    <message>
        <source>Cuenta Bancaria</source>
        <translation type="unfinished">Compte Bancari</translation>
    </message>
    <message>
        <source>Nombre Cuenta Bancaria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDASIENTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asiento</source>
        <translation type="unfinished">Assentament</translation>
    </message>
    <message>
        <source>Cantidad Prevista</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cantidad Efectiva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDREGISTROIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta Cliente/Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Documento</source>
        <translation type="unfinished">Document</translation>
    </message>
    <message>
        <source>COL_CODIGOCTAREGISTROIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_ENTREGISTROIVA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>compbalancedlg</name>
    <message encoding="UTF-8">
        <source>Composición de Balance</source>
        <translation>Composició del Balanç</translation>
    </message>
    <message>
        <source>Titulo Balance</source>
        <translation>Títol del Balanç</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Concepto</source>
        <translation>Concepte</translation>
    </message>
    <message>
        <source>Agregar al Balance</source>
        <translation>Afegir al Balanç</translation>
    </message>
    <message encoding="UTF-8">
        <source>Modificar Línea Actual</source>
        <translation>Modificar la Línia Actual</translation>
    </message>
    <message>
        <source>Eliminar Linea</source>
        <translation>Eliminar la Linia</translation>
    </message>
    <message>
        <source>Editar Masa</source>
        <translation>Editar la Massa</translation>
    </message>
</context>
<context>
    <name>compbalanceview</name>
    <message>
        <source>identificador</source>
        <translation>identificador</translation>
    </message>
    <message>
        <source>concepto</source>
        <translation>concepte</translation>
    </message>
    <message>
        <source>nmasa</source>
        <translation>nmassa</translation>
    </message>
    <message>
        <source>orden</source>
        <translation>ordre</translation>
    </message>
    <message>
        <source>tabulacion</source>
        <translation>tabulació</translation>
    </message>
    <message>
        <source>saldo</source>
        <translation>saldo</translation>
    </message>
</context>
<context>
    <name>correctorwdt</name>
    <message>
        <source>Corrector</source>
        <translation>Corrector</translation>
    </message>
</context>
<context>
    <name>cuentadlg</name>
    <message>
        <source>Cuenta</source>
        <translation>Conta</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Datos Contables</source>
        <translation>Dades Contables</translation>
    </message>
    <message>
        <source>Datos de Cuenta</source>
        <translation>Dades de Conta</translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation>Còdi</translation>
    </message>
    <message>
        <source>Cuenta Padre</source>
        <translation>Conta Pare</translation>
    </message>
    <message>
        <source>Grupo</source>
        <translation>Grup</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Tipo de Cuenta</source>
        <translation>Tipus de Conta</translation>
    </message>
    <message>
        <source>Ingreso</source>
        <translation>Ingrés</translation>
    </message>
    <message>
        <source>Activo</source>
        <translation>Actiu</translation>
    </message>
    <message>
        <source>Neto</source>
        <translation>Net</translation>
    </message>
    <message>
        <source>Pasivo</source>
        <translation>Passiu</translation>
    </message>
    <message>
        <source>Gasto</source>
        <translation>Despesa</translation>
    </message>
    <message>
        <source>Sin Tipo</source>
        <translation>Sense Tipus</translation>
    </message>
    <message>
        <source>Saldos</source>
        <translation>Saldos</translation>
    </message>
    <message>
        <source>Debe</source>
        <translation>Debe</translation>
    </message>
    <message>
        <source>Haber</source>
        <translation>Haber</translation>
    </message>
    <message>
        <source>Opciones de Cuenta</source>
        <translation>Opcions de Conta</translation>
    </message>
    <message>
        <source>nodebe</source>
        <translation>nodebe</translation>
    </message>
    <message>
        <source>bloqueada</source>
        <translation>bloquejada</translation>
    </message>
    <message encoding="UTF-8">
        <source>Regularización</source>
        <translation>Regularització</translation>
    </message>
    <message>
        <source>nohaber</source>
        <translation>nohaber</translation>
    </message>
    <message>
        <source>Imputacion</source>
        <translation>Imputació</translation>
    </message>
    <message>
        <source>Otros Datos</source>
        <translation>Altres Dades</translation>
    </message>
    <message>
        <source>Direccion</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <source>CIF</source>
        <translation>CIF</translation>
    </message>
    <message encoding="UTF-8">
        <source>Teléfono</source>
        <translation>Telèfon</translation>
    </message>
    <message encoding="UTF-8">
        <source>Correo Electrónico</source>
        <translation>Correu Electrònic</translation>
    </message>
    <message>
        <source>Cuenta Bancaria</source>
        <translation>Compte Bancari</translation>
    </message>
    <message encoding="UTF-8">
        <source>Página Web</source>
        <translation>Pàgina Web</translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation>Comentaris</translation>
    </message>
</context>
<context>
    <name>diariodlg1</name>
    <message>
        <source>Diario</source>
        <translation>Diari</translation>
    </message>
    <message>
        <source>Totales:</source>
        <translation>Totals:</translation>
    </message>
    <message>
        <source>Fecha inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha final</source>
        <translation>Data Final</translation>
    </message>
</context>
<context>
    <name>diarioview1</name>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>N.Asiento.</source>
        <translation>Num. Assentament.</translation>
    </message>
    <message>
        <source>Cuenta</source>
        <translation>Conta</translation>
    </message>
    <message>
        <source>Denominaci&#xf3;n</source>
        <translation>Denominació</translation>
    </message>
    <message>
        <source>Debe</source>
        <translation>Debe</translation>
    </message>
    <message>
        <source>Haber</source>
        <translation>Haber</translation>
    </message>
    <message>
        <source>Concepto</source>
        <translation>Concepte</translation>
    </message>
    <message>
        <source>C. Coste</source>
        <translation>C. Cost</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation>Canal</translation>
    </message>
    <message>
        <source>Contrapartida</source>
        <translation>Contrapartida</translation>
    </message>
    <message>
        <source>Asiento</source>
        <translation>Assentament</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>duplicaasientodlg</name>
    <message>
        <source>Duplicar Asientos</source>
        <translation>Duplicar Assentaments</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Destino</source>
        <translation>Destí</translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;p align=&quot;right&quot;&gt;Fecha con la que quedará el asiento&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;right&quot;&gt;Data amb la que quedarà l&apos;assentament&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Tratamiento de la fecha</source>
        <translation>Tratament de la data</translation>
    </message>
    <message>
        <source>Mantener distacia entre Fechas</source>
        <translation>Mantenir distància entre Dates</translation>
    </message>
    <message>
        <source>Todos con la misma Fecha</source>
        <translation>Tots amb la mateixa Data</translation>
    </message>
    <message>
        <source>Origen</source>
        <translation>Origen</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Asiento Inicial</source>
        <translation>Assentament Inicial</translation>
    </message>
    <message>
        <source>Asiento Final</source>
        <translation>Assentament Final</translation>
    </message>
</context>
<context>
    <name>empresa</name>
    <message>
        <source>Empresas (*.pgdump)</source>
        <translation type="obsolete">Empreses (*.pgdump)</translation>
    </message>
    <message>
        <source>Cargar Empresa</source>
        <translation type="obsolete">Carregar Empresa</translation>
    </message>
    <message>
        <source>Borrar Asiento</source>
        <translation type="obsolete">Borrar Assentament</translation>
    </message>
    <message>
        <source>Se procedera a borrar el asiento.</source>
        <translation type="obsolete">Es procedirà a borrar l&apos;assentament .</translation>
    </message>
</context>
<context>
    <name>emrpesa</name>
    <message>
        <source>Elige el fichero a cargar.</source>
        <translation type="obsolete">Elegeixi el fitxer a carregar.</translation>
    </message>
</context>
<context>
    <name>estadisticasdlg</name>
    <message encoding="UTF-8">
        <source>Balance Gráfico</source>
        <translation>Balanç gràfic</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
</context>
<context>
    <name>extractodlg1</name>
    <message>
        <source>Extracto de Cuentas</source>
        <translation>Extracte de contes</translation>
    </message>
    <message>
        <source>Cuenta</source>
        <translation>Conta</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Saldos Iniciales</source>
        <translation>Saldos Inicials</translation>
    </message>
    <message>
        <source>Cuenta inicial</source>
        <translation>Conta inicial</translation>
    </message>
    <message>
        <source>Cuenta final</source>
        <translation>Conta final</translation>
    </message>
    <message>
        <source>Fecha inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha final</source>
        <translation>Data final</translation>
    </message>
    <message>
        <source>Totales:</source>
        <translation>Totals:</translation>
    </message>
</context>
<context>
    <name>extractoview1</name>
    <message>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>N.Asiento.</source>
        <translation>Num. Assentament.</translation>
    </message>
    <message>
        <source>Concepto</source>
        <translation>Concepte</translation>
    </message>
    <message>
        <source>Debe</source>
        <translation>Debe</translation>
    </message>
    <message>
        <source>Haber</source>
        <translation>Haber</translation>
    </message>
    <message>
        <source>Saldo</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>C. Coste</source>
        <translation>C. Cost</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation>Canal</translation>
    </message>
    <message>
        <source>Contrapartida</source>
        <translation>Contrapartida</translation>
    </message>
    <message>
        <source>Orden Asiento</source>
        <translation>Ordre Assentament</translation>
    </message>
    <message>
        <source>Diarios (*.txt)</source>
        <translation>Diaris (*.txt)</translation>
    </message>
    <message>
        <source>Guardar Libro Diario</source>
        <translation>Desar el Llibre diari</translation>
    </message>
    <message>
        <source>Elige el nombre de archivo</source>
        <translation>Elegeixi el nom del fitxer</translation>
    </message>
    <message>
        <source>Ver Asiento</source>
        <translation>Veure Assentament</translation>
    </message>
    <message>
        <source>Ver Diario (Este dia)</source>
        <translation>Veure el Diari (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Diario (Este mes)</source>
        <translation>Veure el Diari (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Diario (Este a&#xf1;o)</source>
        <translation>Veure el Diari (Aquest any)</translation>
    </message>
    <message>
        <source>Ver Balance (Este dia)</source>
        <translation>Veure Balanç (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Balance (Este mes)</source>
        <translation>Veure Balanç (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Balance (Este a&#xf1;o)</source>
        <translation>Veure Balanç (Aquest any)</translation>
    </message>
    <message>
        <source>Punteos (*.pto)</source>
        <translation>Puntejos (*.pto)</translation>
    </message>
    <message>
        <source>Guardar Punteo</source>
        <translation>Desar el Punteig</translation>
    </message>
    <message>
        <source>Cargar Punteo</source>
        <translation>Carregar el Punteig</translation>
    </message>
    <message>
        <source>Borrar Punteo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>filtrarasientosdlg</name>
    <message>
        <source>Filtrar Asientos</source>
        <translation>Filtrar Assentaments</translation>
    </message>
    <message>
        <source>Asientos cuyo nombre se parezca a</source>
        <translation>Assentaments llur nom s&apos;assembli a</translation>
    </message>
    <message>
        <source>Asientos con saldo</source>
        <translation>Assentaments amb saldo</translation>
    </message>
    <message>
        <source>Asientos con  apuntes con cantidad igual a</source>
        <translation>Assentaments amb apunts amb quantitat igual a</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Buidar</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Ejercicio</source>
        <translation type="unfinished">Exercici</translation>
    </message>
</context>
<context>
    <name>filtrardiariodlg</name>
    <message>
        <source>Filtrado de Extractos</source>
        <translation type="obsolete">Filtrat d&apos;Extractes</translation>
    </message>
    <message>
        <source>Apuntes con saldo superior a</source>
        <translation>Apunts amb saldo superior a</translation>
    </message>
    <message>
        <source>Centro de Coste</source>
        <translation type="obsolete">Centre de Cost</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation type="obsolete">Canal</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Buidar</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Apuntes con saldo inferior a</source>
        <translation>Apunts amb saldo inferior a</translation>
    </message>
    <message>
        <source>Apuntes con contrapartida:</source>
        <translation>Apunts amb contrapartida:</translation>
    </message>
    <message>
        <source>Filtrado de Diario</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>filtrarextractosdlg</name>
    <message>
        <source>Filtrado de Extractos</source>
        <translation>Filtrat d&apos;Extractes</translation>
    </message>
    <message>
        <source>Apuntes con saldo superior a</source>
        <translation>Apunts amb saldo superior a</translation>
    </message>
    <message>
        <source>Punteo</source>
        <translation>Punteig</translation>
    </message>
    <message>
        <source>Apuntes Puteados</source>
        <translation type="obsolete">Apunts Puntejats</translation>
    </message>
    <message>
        <source>Todos</source>
        <translation>Tots</translation>
    </message>
    <message>
        <source>Apuntes No Puteados</source>
        <translation type="obsolete">Apunts No Puntejats</translation>
    </message>
    <message>
        <source>Centro de Coste</source>
        <translation type="obsolete">Centre de Cost</translation>
    </message>
    <message>
        <source>Canal</source>
        <translation type="obsolete">Canal</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Buidar</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Apuntes con saldo inferior a</source>
        <translation>Apunts amb saldo inferior a</translation>
    </message>
    <message>
        <source>Apuntes con contrapartida:</source>
        <translation>Apunts amb contrapartida:</translation>
    </message>
    <message>
        <source>Apuntes Punteados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apuntes No Punteados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>intapunts3dlg</name>
    <message>
        <source>Apuntes Contables</source>
        <translation>Apunts Contables</translation>
    </message>
    <message>
        <source>Totales</source>
        <translation>Totals</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Num. Asiento</source>
        <translation>Num. Assentament</translation>
    </message>
    <message>
        <source>Descuadre</source>
        <translation>Desencaixament</translation>
    </message>
    <message>
        <source>Abrir Asiento</source>
        <translation>Obrir Assentament</translation>
    </message>
    <message>
        <source>Cerrar Asiento</source>
        <translation>Tancar Assentament</translation>
    </message>
    <message>
        <source>Nuevo Asiento</source>
        <translation>Nou Assentament</translation>
    </message>
    <message>
        <source>Editar Atributos</source>
        <translation>Editar Atributs</translation>
    </message>
    <message>
        <source>Asientos Inteligentes</source>
        <translation>Assentaments Inteligents</translation>
    </message>
    <message>
        <source>Abrir ...</source>
        <translation type="obsolete">Obrir ...</translation>
    </message>
    <message>
        <source>Borrar Asiento</source>
        <translation>Borrar Assentament</translation>
    </message>
    <message>
        <source>Registro de IVA</source>
        <translation>Registre d&apos;IVA</translation>
    </message>
    <message>
        <source>Duplicar Asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cargar Asiento</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>intapunts3view</name>
    <message>
        <source>FECHA</source>
        <translation>DATA</translation>
    </message>
    <message>
        <source>SUBCUENTA</source>
        <translation>SUBCONTA</translation>
    </message>
    <message>
        <source>CONCEPTO</source>
        <translation>CONCEPTE</translation>
    </message>
    <message>
        <source>DEBE</source>
        <translation>DEBE</translation>
    </message>
    <message>
        <source>HABER</source>
        <translation>HABER</translation>
    </message>
    <message>
        <source>NOMBRE CUENTA</source>
        <translation>NOM CONTA</translation>
    </message>
    <message>
        <source>CONTRAPARTIDA</source>
        <translation>CONTRAPARTIDA</translation>
    </message>
    <message>
        <source>TIPO IVA</source>
        <translation>TIPUS IVA</translation>
    </message>
    <message>
        <source>IVA</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>CCOSTE</source>
        <translation>C. COST</translation>
    </message>
    <message>
        <source>CANAL</source>
        <translation>CANAL</translation>
    </message>
    <message>
        <source>IDCCOSTE</source>
        <translation>IDCOST</translation>
    </message>
    <message>
        <source>IDCANAL</source>
        <translation>IDCANAL</translation>
    </message>
    <message>
        <source>IDCUENTA</source>
        <translation>IDCONTA</translation>
    </message>
    <message>
        <source>Asiento de Regularizacion</source>
        <translation>Assentament de Regularització</translation>
    </message>
    <message>
        <source>Igual que la anterior (*)</source>
        <translation>Igual que la anterior (*)</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>&amp;Seleccionar Canal</source>
        <translation>&amp;Seleccionar el Canal</translation>
    </message>
    <message>
        <source>&amp;Seleccionar Centro de Coste</source>
        <translation>&amp;Seleccionar el Centre de Cost</translation>
    </message>
    <message>
        <source>Seleccionar Valor (+)</source>
        <translation>Seleccionar Valor (+)</translation>
    </message>
    <message>
        <source>Introducir Descuadre (+)</source>
        <translation>Introduïr el Desencaixament (+)</translation>
    </message>
    <message>
        <source>Duplicar Apunte</source>
        <translation>Duplicar Apunts</translation>
    </message>
    <message>
        <source>Borrar Apunte</source>
        <translation>Borrar Apunt</translation>
    </message>
    <message>
        <source>Subir (Ctrl Arriba)</source>
        <translation>Pujar (Ctrl Amunt)</translation>
    </message>
    <message>
        <source>Bajar (Ctrl Abajo)</source>
        <translation>Baixar (Ctrl Avall)</translation>
    </message>
    <message>
        <source>Ver Diario (Este dia)</source>
        <translation>Veure el Diari (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Diario (Este mes)</source>
        <translation>Veure el Diari (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Diario (Este a&#xf1;o)</source>
        <translation>Veure el Diari (Aquest any)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este dia)</source>
        <translation>Veure Extracte (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este mes)</source>
        <translation>Veure Extracte (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Extracto (Este a&#xf1;o)</source>
        <translation>Veure Extracte (Aquest any)</translation>
    </message>
    <message>
        <source>Ver Balance (Este dia)</source>
        <translation>Veure Balanç (Aquest dia)</translation>
    </message>
    <message>
        <source>Ver Balance (Este mes)</source>
        <translation>Veure Balanç (Aquest mes)</translation>
    </message>
    <message>
        <source>Ver Balance (Este a&#xf1;o)</source>
        <translation>Veure Balanç (Aquest any)</translation>
    </message>
    <message>
        <source>Editar Cuenta</source>
        <translation>Editar Conta</translation>
    </message>
    <message>
        <source>No existe cuenta</source>
        <translation>No existeix la conta</translation>
    </message>
    <message>
        <source>No existe una cuenta con el codigo proporcionado, desea crear una?.</source>
        <translation>No existeix cap conta amb el codi proporcionat, desitja crear-ne una?.</translation>
    </message>
    <message>
        <source>Asiento vacio</source>
        <translation type="obsolete">Assentament buit</translation>
    </message>
    <message>
        <source>El asiento esta vacio, se procedera a borrarlo !</source>
        <translation type="obsolete">L&apos;assentament està buit, es procedirà a borrar-lo !</translation>
    </message>
    <message>
        <source>PRIVILEGIOS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No tiene suficientes privilegios para realizar esta acci&#xf3;n.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Substituir Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asiento de Apertura</source>
        <translation type="unfinished">Assentament d&apos;Apertura</translation>
    </message>
    <message>
        <source>No se ha podido encontrar el ejercicio anterior.
<byte value="xd"/> El Asiento de Apertura tendr&#xe1; que ser entrado manualmente.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asiento de Regularizaci&#xf3;n</source>
        <translation type="unfinished">Assentament de Regularització</translation>
    </message>
</context>
<context>
    <name>ivadlg</name>
    <message>
        <source>Iva</source>
        <translation type="obsolete">Iva</translation>
    </message>
    <message>
        <source>Datos Factura</source>
        <translation>Dades de la Factura</translation>
    </message>
    <message>
        <source>Num. Factura</source>
        <translation>Num. Factura</translation>
    </message>
    <message>
        <source>Base Imponible</source>
        <translation type="obsolete">Base Imponible</translation>
    </message>
    <message>
        <source>%IVA</source>
        <translation type="obsolete">%IVA</translation>
    </message>
    <message>
        <source>Num. Orden</source>
        <translation>Num. Ordre</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Datos Empresa</source>
        <translation>Dades de la Empresa</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Cuenta Empresa</source>
        <translation type="obsolete">Conta de la Empresa</translation>
    </message>
    <message>
        <source>CIF / NIF</source>
        <translation>CIF / NIF</translation>
    </message>
    <message>
        <source>Cuenta de IVA</source>
        <translation type="obsolete">Conta d&apos;IVA</translation>
    </message>
    <message>
        <source>Importe IVA</source>
        <translation type="obsolete">Import d&apos;IVA</translation>
    </message>
    <message>
        <source>Asiento:</source>
        <translation>Assentament:</translation>
    </message>
    <message>
        <source>Registro de Facturas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta Cliente / Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IVA</source>
        <translation type="unfinished">IVA</translation>
    </message>
    <message>
        <source>% IVA</source>
        <translation type="unfinished">% IVA</translation>
    </message>
    <message>
        <source>BASE IMPONIBLE</source>
        <translation type="unfinished">BASE IMPONIBLE</translation>
    </message>
    <message>
        <source>TOTAL IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rectifica A:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Base Imponible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cobros / Pagos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished">Comentaris</translation>
    </message>
</context>
<context>
    <name>ivaview</name>
    <message>
        <source>COL_IVA_IDIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IVA_IDTIPOIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta</source>
        <translation type="unfinished">Conta</translation>
    </message>
    <message>
        <source>Total IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IVA_IDREGISTROIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IVA_PORCENTAJETIPOIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IDPREVCOBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FPREVISTAPREVCOBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FCOBROPREVCOBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IDCUENTA</source>
        <translation type="unfinished">IDCONTA</translation>
    </message>
    <message>
        <source>CODCUENTA</source>
        <translation type="unfinished">CODCOMPTE</translation>
    </message>
    <message>
        <source>NOMCUENTA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CANTIDADPREVISTAPREVCOBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CANTIDADPREVCOBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IDREGISTROIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOCPREVCOBRO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No existe cuenta</source>
        <translation type="unfinished">No existeix la conta</translation>
    </message>
    <message>
        <source>No existe una cuenta con el codigo proporcionado, desea crear una?.</source>
        <translation type="unfinished">No existeix cap conta amb el codi proporcionat, desitja crear-ne una?.</translation>
    </message>
    <message>
        <source>COBRO/PAGO</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>listcuentasdlg1</name>
    <message>
        <source>Plan de Cuentas</source>
        <translation>Pla de Contes</translation>
    </message>
    <message encoding="UTF-8">
        <source>Plà de comptes</source>
        <comment>Manteniment del plà de comptes</comment>
        <translation>Pla de contes</translation>
    </message>
    <message encoding="UTF-8">
        <source>Código :</source>
        <translation>Codi:</translation>
    </message>
    <message encoding="UTF-8">
        <source>Descripción</source>
        <translation>Descripció</translation>
    </message>
    <message>
        <source>Plan Contable</source>
        <translation>Pla Contable</translation>
    </message>
    <message>
        <source>Subcuentas</source>
        <translation>Subcontes</translation>
    </message>
    <message>
        <source>&amp;Salir</source>
        <translation>&amp;Sortir</translation>
    </message>
</context>
<context>
    <name>listcuentasview1</name>
    <message>
        <source>CODIGO</source>
        <translation>CODI</translation>
    </message>
    <message>
        <source>NOMBRE</source>
        <translation>NOM</translation>
    </message>
</context>
<context>
    <name>listivadlg</name>
    <message>
        <source>Listados de IVA</source>
        <translation>Llistats d&apos;IVA</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation>Data Final</translation>
    </message>
    <message>
        <source>Soportado</source>
        <translation>Suportat</translation>
    </message>
    <message>
        <source>Repercutido</source>
        <translation>Repercutit</translation>
    </message>
    <message>
        <source>Resumen</source>
        <translation>Resum</translation>
    </message>
    <message>
        <source>Iva Repercutido</source>
        <translation>Iva Repercutit</translation>
    </message>
    <message>
        <source>Total Iva</source>
        <translation type="obsolete">Total d&apos;Iva</translation>
    </message>
    <message>
        <source>Iva 16%</source>
        <translation type="obsolete">Iva 16%</translation>
    </message>
    <message>
        <source>Iva 7%</source>
        <translation type="obsolete">Iva 7%</translation>
    </message>
    <message>
        <source>Iva 4%</source>
        <translation type="obsolete">Iva 4%</translation>
    </message>
    <message>
        <source>Exento</source>
        <translation type="obsolete">Exent</translation>
    </message>
    <message>
        <source>IVA</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Total</source>
        <translation>Total</translation>
    </message>
    <message>
        <source>IVA Soportado</source>
        <translation>IVA Suportat</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
</context>
<context>
    <name>listivaview</name>
    <message>
        <source>CONTRAPARTIDA</source>
        <translation>CONTRAPARTIDA</translation>
    </message>
    <message>
        <source>DESCRIPCION</source>
        <translation>DESCRIPCIÓ</translation>
    </message>
    <message>
        <source>BASE IMPONIBLE</source>
        <translation>BASE IMPONIBLE</translation>
    </message>
    <message>
        <source>PORCENTAJE IVA</source>
        <translation>PERCENTATGE D&apos;IVA</translation>
    </message>
    <message>
        <source>TOTAL</source>
        <translation>TOTAL</translation>
    </message>
    <message>
        <source>FACTURA</source>
        <translation>FACTURA</translation>
    </message>
    <message>
        <source>CIF</source>
        <translation>CIF</translation>
    </message>
    <message>
        <source>ID BORRADOR</source>
        <translation>ID BORRADOR</translation>
    </message>
    <message>
        <source>Ver Asiento</source>
        <translation>Veure Assentament</translation>
    </message>
    <message>
        <source>Editar Registro</source>
        <translation>Editar Registre</translation>
    </message>
    <message>
        <source>Borrar Registro</source>
        <translation>Borrar Registre</translation>
    </message>
    <message>
        <source>Editar entrada de IVA</source>
        <translation>Editar entrada d&apos;IVA</translation>
    </message>
    <message>
        <source>FECHA</source>
        <translation>DATA</translation>
    </message>
    <message>
        <source>FACTURA PROVEEDOR</source>
        <translation>FACTURA DEL PROVEIDOR</translation>
    </message>
    <message>
        <source>NUM ORDEN</source>
        <translation>NUM ORDRE</translation>
    </message>
    <message>
        <source>NUM ASIENTO</source>
        <translation>NUM ASSENTAMENT</translation>
    </message>
    <message>
        <source>ID ASIENTO</source>
        <translation>ID ASSENTAMENT</translation>
    </message>
    <message>
        <source>CUENTA IVA</source>
        <translation>CONTA IVA</translation>
    </message>
    <message>
        <source>NOMBRETIPOIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IVASOPORTADO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BASESOPORTADO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exento</source>
        <translation type="unfinished">Exent</translation>
    </message>
</context>
<context>
    <name>mod300dlg</name>
    <message>
        <source>Modelo 300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Periodo a declarar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>1º trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>2º trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>3º trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>4º trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Seleccione periodo de declaración</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vista Previa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta a devolver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personalizada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>En el banco</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12</source>
        <translation type="unfinished">12</translation>
    </message>
    <message>
        <source>1234</source>
        <translation type="unfinished">1234</translation>
    </message>
    <message>
        <source>0123456789</source>
        <translation type="unfinished">0123456789</translation>
    </message>
    <message>
        <source>Generar borrador</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mpatrimonialdlg</name>
    <message>
        <source>Masa Patrimonial</source>
        <translation>Massa Patrimonial</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Cuenta</source>
        <translation>Conta</translation>
    </message>
    <message>
        <source>Agregar</source>
        <translation>Afegir</translation>
    </message>
    <message>
        <source>Quitar</source>
        <translation>Llevar</translation>
    </message>
    <message>
        <source>Suman</source>
        <translation>Sumen</translation>
    </message>
    <message>
        <source>Restan</source>
        <translation>Resten</translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation>Comentaris</translation>
    </message>
</context>
<context>
    <name>mpatrimonialesdlg</name>
    <message>
        <source>Masas Patrimoniales</source>
        <translation>Masses Patrimonials</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Nuevo</source>
        <translation>Nou</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Editar</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Balanç</translation>
    </message>
</context>
<context>
    <name>mpatrimonialesview</name>
    <message>
        <source>CODIGO</source>
        <translation>CODI</translation>
    </message>
    <message>
        <source>Masa patrimonial</source>
        <translation>Massa Patrimonial</translation>
    </message>
</context>
<context>
    <name>mpatrimonialview</name>
    <message>
        <source>identificador</source>
        <translation>identificador</translation>
    </message>
    <message>
        <source>codigo</source>
        <translation>codi</translation>
    </message>
    <message>
        <source>descripcion</source>
        <translation>descripció</translation>
    </message>
    <message>
        <source>tipo</source>
        <translation>tipus</translation>
    </message>
</context>
<context>
    <name>nuevaempresadlg</name>
    <message>
        <source>Nueva Empresa</source>
        <translation type="obsolete">Nova Empresa</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="obsolete">Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="obsolete">Anul·lar</translation>
    </message>
    <message>
        <source>Usuarios</source>
        <translation type="obsolete">Usuaris</translation>
    </message>
    <message>
        <source>Ver</source>
        <translation type="obsolete">Veure</translation>
    </message>
    <message>
        <source>Modificar</source>
        <translation type="obsolete">Modificar</translation>
    </message>
    <message>
        <source>Datos Empresa</source>
        <translation type="obsolete">Dades de la Empresa</translation>
    </message>
    <message>
        <source>Nombre de la empresa</source>
        <translation type="obsolete">Nom de la empresa</translation>
    </message>
    <message>
        <source>Archivo</source>
        <translation type="obsolete">Fitxer</translation>
    </message>
    <message>
        <source>Ejercicio</source>
        <translation type="obsolete">Exercici</translation>
    </message>
</context>
<context>
    <name>propiedadesempresa</name>
    <message>
        <source>idusuario</source>
        <translation>idusuari</translation>
    </message>
    <message>
        <source>login</source>
        <translation>usuari</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
</context>
<context>
    <name>propiedemp</name>
    <message>
        <source>Propiedades Empresa</source>
        <translation>Propietats de la Empresa</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Digitos de cuentas</source>
        <translation>Dígits de contes</translation>
    </message>
    <message encoding="UTF-8">
        <source>Modelo de Código Cuenta</source>
        <translation>Model del Codi de Conta</translation>
    </message>
    <message>
        <source>Digitos estandar</source>
        <translation>Dígits estàndar</translation>
    </message>
    <message encoding="UTF-8">
        <source>xxxx --&gt; Dígitos de plan contable.
yyyy --&gt; Dígitos de cuenta.</source>
        <translation>xxxx --&gt; Dígits del pla contable.
yyyy --&gt; Dígits de la conta.</translation>
    </message>
    <message>
        <source>No alterar cuentas con menos de</source>
        <translation>No alterar contes amb menys de</translation>
    </message>
    <message>
        <source>digitos</source>
        <translation>dígits</translation>
    </message>
    <message encoding="UTF-8">
        <source>Ampliar sólo cuentas finales</source>
        <translation>Ampliar només contes finals</translation>
    </message>
    <message>
        <source>Errores producidos</source>
        <translation>Errors produïts</translation>
    </message>
    <message>
        <source>Column 1</source>
        <translation>Columna 1</translation>
    </message>
    <message>
        <source>New Item</source>
        <translation>Nou Ítem</translation>
    </message>
    <message>
        <source>Modificar plan contable</source>
        <translation>Mostra el pla de contes</translation>
    </message>
    <message>
        <source>Propiedades Generales</source>
        <translation>Propietats Generals</translation>
    </message>
    <message>
        <source>Usuarios</source>
        <translation>Usuaris</translation>
    </message>
    <message>
        <source>Ver</source>
        <translation>Veure</translation>
    </message>
    <message>
        <source>Modificar</source>
        <translation>Modificar</translation>
    </message>
    <message>
        <source>Datos Fiscales</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Tipo de vía:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Nombre de la vía:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escalera:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Provincia:</source>
        <translation type="unfinished">Província:</translation>
    </message>
    <message>
        <source>Piso:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puerta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C.P.:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>País:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Municipio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Número:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>regivaprintdlg</name>
    <message encoding="UTF-8">
        <source>Impresión del Registro de IVA</source>
        <translation>Impresió del Registre d&apos;IVA</translation>
    </message>
    <message>
        <source>Datos Listado</source>
        <translation>Dades del Llistat</translation>
    </message>
    <message>
        <source>Incluir resultados parciales</source>
        <translation>Incloure resultats parcials</translation>
    </message>
    <message>
        <source>Fecha Inicial</source>
        <translation>Data Inicial</translation>
    </message>
    <message>
        <source>Fecha Final</source>
        <translation>Data Final</translation>
    </message>
    <message>
        <source>Formato</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Texto Plano</source>
        <translation>Text Pla</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Imprimir</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Postscript</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>resmensualdlg</name>
    <message>
        <source>Seguimiento de Cuentas</source>
        <translation>Seguiment de Contes</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Anul·lar</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Linea 1</source>
        <translation>Linea 1</translation>
    </message>
    <message>
        <source>Cuenta</source>
        <translation>Conta</translation>
    </message>
    <message>
        <source>M. Patrimonial</source>
        <translation>M. Patrimonial</translation>
    </message>
    <message>
        <source>Linea 2</source>
        <translation>Linea 2</translation>
    </message>
    <message>
        <source>Linea 3</source>
        <translation>Linea 3</translation>
    </message>
    <message>
        <source>Saldos</source>
        <translation>Saldos</translation>
    </message>
    <message>
        <source>Movimientos</source>
        <translation>Moviments</translation>
    </message>
    <message>
        <source>Contrapartidas 1</source>
        <translation>Contrapartides 1</translation>
    </message>
    <message>
        <source>Contrapartidas 2</source>
        <translation>Contrapartides 2</translation>
    </message>
    <message>
        <source>Contrapartidas 3</source>
        <translation>Contrapartides 3</translation>
    </message>
</context>
<context>
    <name>resmensualview</name>
    <message>
        <source>Progresion de saldos</source>
        <translation>Progresió de saldos</translation>
    </message>
    <message>
        <source>Movimientos menusales</source>
        <translation>Moviments mensuals</translation>
    </message>
</context>
<context>
    <name>selectcanaldlg</name>
    <message>
        <source>Selector de Canales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S. Nada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invertir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S. Todo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>selectccostedlg</name>
    <message>
        <source>Selector de Centros de Coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invertir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S. Nada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S. Todo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>usuariosdlg</name>
    <message encoding="UTF-8">
        <source>Gestión de Usuarios</source>
        <translation type="obsolete">Gestió d&apos;Usuaris</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="obsolete">Nom</translation>
    </message>
    <message>
        <source>1er. Apellido</source>
        <translation type="obsolete">1 er. Llinatge</translation>
    </message>
    <message encoding="UTF-8">
        <source>2º. Apellido</source>
        <translation type="obsolete">2º. Llinatge</translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="obsolete">Usuari</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="obsolete">Clau</translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="obsolete">Comentaris</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="obsolete">Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="obsolete">Tancar</translation>
    </message>
</context>
<context>
    <name>usuariosview</name>
    <message>
        <source>Nuevo Usuario</source>
        <translation type="obsolete">Nou Usuari</translation>
    </message>
</context>
</TS>
