INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES (2005, 0, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado)  VALUES (2005, 1, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 2, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 3, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 4, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 5, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 6, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 7, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 8, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 9, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 10, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 11, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2005, 12, FALSE);

INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 0, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 1, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 2, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 3, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 4, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 5, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 6, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 7, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 8, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 9, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 10, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 11, FALSE);
INSERT into ejercicios (ejercicio, periodo, bloqueado) VALUES  (2004, 12, FALSE);

