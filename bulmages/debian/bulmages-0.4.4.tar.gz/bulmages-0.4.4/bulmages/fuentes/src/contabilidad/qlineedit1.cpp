//
//
// C++ Implementation: qlineedit1
//
// Description: 
//
//
// Author: Tomeu Borr�s Riera <tborras@conetxia.com>, (C) 2003
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "qlineedit1.h"
/*
@implementation QLineEdit1
@end
*/


// Este es el constructor de la clase.
QLineEdit1::QLineEdit1(QWidget * parent, const char * name = 0): QLineEdit(parent, name) {
}

// Este es el destructor de la clase, y este es un comentario estupido.
QLineEdit1::~QLineEdit1(){
}
