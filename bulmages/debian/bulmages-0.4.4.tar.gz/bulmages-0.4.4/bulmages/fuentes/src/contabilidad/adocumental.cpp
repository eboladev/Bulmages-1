/***************************************************************************
                          aboutview.cpp  -  description
                             -------------------
    begin                : Fri Dec 27 2004
    copyright            : (C) 2002 by Tomeu Borr�s Riera
    email                : tborras@conetxia.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "adocumental.h"
#include "empresa.h"

#define COL_IDADOCUMENTAL 0
#define COL_IDASIENTO 1
#define COL_DESCRIPCIONADOCUMENTAL 2
#define COL_FECHAINTADOCUMENTAL 3
#define COL_FECHAASADOCUMENTAL 4
#define COL_ARCHIVOADOCUMENTAL 5
#define COL_ORDENASIENTO 6


adocumental::adocumental(empresa *emp,QWidget *parent, const char *name ) : adocumentalbase(parent,name,false,0) {
   empresaactual=emp;
   conexionbase = emp->bdempresa();
   modo =0;
   idadocumental = "";
   QString query;
   
  m_listado->setNumRows(0);
  m_listado->setNumCols(7);
  m_listado->horizontalHeader()->setLabel( COL_IDADOCUMENTAL, tr( "COL_IDADOCUMENTAL" ) );
  m_listado->horizontalHeader()->setLabel( COL_IDASIENTO, tr( "COL_IDASIENTO" ) );
  m_listado->horizontalHeader()->setLabel( COL_DESCRIPCIONADOCUMENTAL, tr( "COL_DESCRIPCIONADOCUMENTAL" ) );
  m_listado->horizontalHeader()->setLabel( COL_FECHAINTADOCUMENTAL, tr( "FECHAINTADOCUMENTAL" ) );
  m_listado->horizontalHeader()->setLabel( COL_FECHAASADOCUMENTAL, tr( "FECHAASADOCUMENTAL" ) );
  m_listado->horizontalHeader()->setLabel( COL_ARCHIVOADOCUMENTAL, tr( "COL_ARCHIVOADOCUMENTAL" ) );
  m_listado->horizontalHeader()->setLabel( COL_ORDENASIENTO, tr( "COL_ORDENASIENTO" ) );
  
  m_listado->setColumnWidth(COL_IDADOCUMENTAL,200);
  m_listado->setColumnWidth(COL_IDASIENTO,200);
  m_listado->setColumnWidth(COL_DESCRIPCIONADOCUMENTAL,100);
  m_listado->setColumnWidth(COL_FECHAINTADOCUMENTAL,50);
  m_listado->setColumnWidth(COL_FECHAASADOCUMENTAL,50);
  m_listado->setColumnWidth(COL_ARCHIVOADOCUMENTAL,150);
  m_listado->setColumnWidth(COL_ORDENASIENTO,25);

  m_listado->hideColumn(COL_IDADOCUMENTAL);
  m_listado->hideColumn(COL_IDASIENTO);
   
  query = "SELECT * FROM configuracion WHERE nombre='RutaADocumental'";
  conexionbase->begin();
  cursor2 *cursoraux2=conexionbase->cargacursor(query,"thequery");
  conexionbase->commit();
  if (!cursoraux2->eof()) {
      RutaADocumental = cursoraux2->valor("valor");
  } else {
      RutaADocumental = "/tmp";
  }// end if
   
  // Iniciamos la presentaci�n
  inicializa();
}// end adocumental

adocumental::~adocumental(){
}// end adocumental


void adocumental::inicializa() {
  QString query = "SELECT * FROM adocumental LEFT JOIN asiento ON adocumental.idasiento=asiento.idasiento ORDER BY ordenasiento";
  conexionbase->begin();
  cursor2 *cursoraux1=conexionbase->cargacursor(query,"elquery");
  conexionbase->commit();
  m_listado->setNumRows(cursoraux1->numregistros());
  int i=0;
   while (!cursoraux1->eof()) {
      m_listado->setText(i,COL_IDADOCUMENTAL, cursoraux1->valor("idadocumental"));
      m_listado->setText(i,COL_IDASIENTO, cursoraux1->valor("idasiento"));
      m_listado->setText(i,COL_DESCRIPCIONADOCUMENTAL, cursoraux1->valor("descripcionadocumental"));
      m_listado->setText(i,COL_FECHAINTADOCUMENTAL, cursoraux1->valor("fechaintadocumental"));
      m_listado->setText(i,COL_FECHAASADOCUMENTAL, cursoraux1->valor("fechaasadocumental"));
      m_listado->setText(i,COL_ARCHIVOADOCUMENTAL, cursoraux1->valor("archivoadocumental"));
      m_listado->setText(i,COL_ORDENASIENTO, cursoraux1->valor("ordenasiento"));
      
      cursoraux1->siguienteregistro ();
      i++;
   }// end while
   delete cursoraux1;
}// end inicializa

void adocumental::doubleclicked(int row, int, int, const QPoint &) {
   idadocumental = m_listado->text(row, COL_IDADOCUMENTAL);
   fprintf(stderr,"Archivo Documental: %s\n", idadocumental.ascii());
   if (modo ==0 ) { // Es el modo edicion
      QString archivo = m_listado->text(row, COL_ARCHIVOADOCUMENTAL);
      QString comando = "konqueror "+archivo+" &";
      system(comando.ascii());
   } else { // Es el modo consulta
      done(1);
   }// end if
}// end dobleclicked


void adocumental::boton_newadocumental() {
   QString fn = QFileDialog::getOpenFileName(0, tr("Punteos (*.*)"), 0,tr("Agregar Documento"),tr("Elige el nombre de archivo"));
   if (!fn.isEmpty()) {
      fprintf(stderr,"%s\n",fn.ascii());
      QString comando= "cp "+fn+" "+RutaADocumental;
      QString archivo = fn.right( fn.length()-fn.find('/',-1));
      system(comando.ascii());
      QString SQLQuery = "INSERT INTO adocumental (archivoadocumental) VALUES ('"+archivo+"')";
      conexionbase->begin();
      conexionbase->ejecuta(SQLQuery);
      conexionbase->commit();
      fprintf(stderr,"%s\n", SQLQuery.ascii());
   }// end if
   inicializa();
}// end boton_newadocumental

inline QString adocumental::getidadocumental() {
   return (idadocumental);
}// end getidadocumental


void adocumental::asociaasiento(QString idasiento) {
   fprintf(stderr,"AsociaAsiento: \n");
   fprintf(stderr,"idasiento:%s, idadocumental:%s\n", idasiento.ascii(), idadocumental.ascii());
   if ((idadocumental != "") && (idasiento != "")) {
      QString SQLQuery = "UPDATE adocumental SET idasiento= "+idasiento+" WHERE idadocumental="+idadocumental;
      fprintf(stderr,"%s\n", SQLQuery.ascii());
      conexionbase->begin();
      conexionbase->ejecuta(SQLQuery);
      conexionbase->commit();
   }// end if
   inicializa();
}// end adocumental


/******************************************************
 * Esta funci�n coge el primer archivo documental no  *
 * asociado a ning asiento y lo muestra asignando a idasiento
 * su valor */
void adocumental::presentaprimervacio() {
   int i=0;
   while (m_listado->text(i,COL_IDASIENTO) != "" && i < m_listado->numRows())
      i++;
   if (i < m_listado->numRows())
      doubleclicked(i, 0, 0, QPoint::QPoint(0,0));
}// end presentarprimervacio

void adocumental::boton_desasociar() {
   idadocumental = m_listado->text(m_listado->currentRow(), COL_IDADOCUMENTAL);
   if (idadocumental != "") {
      QString SQLQuery = "UPDATE adocumental SET idasiento= NULL WHERE idadocumental="+idadocumental;
      conexionbase->begin();
      conexionbase->ejecuta(SQLQuery);
      conexionbase->commit();
   }// end if
   inicializa();   
}// end botondesasociar
