/***************************************************************************
 *   Copyright (C) 2004 by J. M. Estopa Rey                                *
 *   pepma@telefonica.net                                                  *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef LINORDERSLIST_H
#define LINORDERSLIST_H

#include "linorderslistbase.h"
#include "postgresiface2.h"


class company;


class linorderslist : public linorderslistbase
{
 Q_OBJECT
public:
	company *companyact;
	QString idpedido;
	cursor2 *m_cursorcombo;
	cursor2 *m_cursorcombo2;
	QString  m_idprovider;
	QString m_idArticle;
   
public:
    linorderslist(company *, QWidget *parent = 0, const char *name = 0, int flag = 0);
    ~linorderslist();
    

public:
    void chargelinorders(QString);
    void chargeorder(QString);
	 void providerChanged(QString);
	 
    
private:
	int saveOrderLines();
	int saveOrder();
	int insertOrderLine(int);
	int updateOrderLine(int);
	int deleteOrderLine(int);
	
	void manageArticle(int);
	void cargarcombodivision(QString, QString);
	void cargarcomboalmacen(QString);
	void searchArticle();
	void cancelOrderLinChanges();
	void calculateImports();

public slots:
	virtual void activated(int);
	virtual void almacenactivated(int);
	virtual void accept();
	virtual void close() {delete this;};
	virtual void neworderlin();
	virtual void searchProvider();
	virtual void orderDateLostFocus();
	virtual void prevDateLostFocus();
	virtual void valueOrderLineChanged(int, int);
	virtual void removeOrderLin();
	virtual void applyPrevDate();
};

#endif
