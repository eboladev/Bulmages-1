<!DOCTYPE TS><TS>
<context>
    <name>Budget</name>
    <message>
        <source>N&#xba; L&#xed;nea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&#xf3;digo Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>% IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concepto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proporci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BudgetBase</name>
    <message>
        <source>Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Generales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Num. Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Fecha Creación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Vencimiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forma de Pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tel. Contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detalle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descuentos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total bases Imponibles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total descuentos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total impuestos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BudgetsList</name>
    <message>
        <source>COL_IDPRESUPUESTO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persona Contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tel&#xe9;fono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDUSUARI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDCLIENTE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BudgetsListBase</name>
    <message>
        <source>Listado de Presupuestos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientDelivNote</name>
    <message>
        <source>N&#xba; L&#xed;nea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Albar&#xe1;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&#xf3;digo Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>% IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concepto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proporci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientDelivNoteBase</name>
    <message encoding="UTF-8">
        <source>Albarán</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Generales</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Num. Albarán</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Fecha Creación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forma de Pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detalle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descuentos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total bases Imponibles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total descuentos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total impuestos</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Total albarán</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientDelivNotesList</name>
    <message>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDFORMA_PAGO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; No Fra.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDUSUARIO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDCLIENTE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDALBARAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forma de Pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientDelivNotesListBase</name>
    <message>
        <source>Listado de Albaranes de Clientes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientEdit</name>
    <message>
        <source>Id. Division</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Telefono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>idproveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliente (modificado)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cliente nuevo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edici&#xf3;n de clientes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qu&#xe9; peligro tienes, majete!
De momento no hago nada, pero tendr&#xed;a que borrarlo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Est&#xe1; a punto de borrar un cliente.
&#xbf;Est&#xe1; seguro de que quiere borrarlo?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El cliente ha sido modificado.
&#xbf;Quiere guardar los cambios?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientEditBase</name>
    <message>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Generales</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dirección</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CP</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Província</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Illes Balears</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcelona</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>València</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tarragona</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Múrcia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Madrid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vizcaya</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>A Coruña</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ourense</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Cantábria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guipuzcoa</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Álava</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La Rioja</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pontevedra</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Teléfono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WEB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre comercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Bancarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos eComercio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Corporación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Divisiones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pers. Contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Productos Suministrados</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Artículo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ref. Pro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contratos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vigentes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vencidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Resumen por artículos</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Número</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concepto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Inicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Vencimiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>% Consumido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consumidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pendientes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientInvoicesList</name>
    <message>
        <source>Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDFORMA_PAGO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; No Fra.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDUSUARIO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDCLIENTE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COL_IDALBARAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forma de Pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientInvoicesListBase</name>
    <message>
        <source>Listado de Albaranes de Clientes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientsList</name>
    <message>
        <source>C&#xf3;digo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre Fiscal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre Comercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF/NIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta Bancaria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domicilio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Poblaci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C.P.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tel&#xe9;fono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Correo Electr&#xf3;nico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&#xe1;gina Web</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha de Alta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha de Baja</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Observaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cod. Recargo Eq.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientsListBase</name>
    <message>
        <source>Listado de Clientes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Detalle Pedido</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Edicion de Albaranes</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Edicion de Albar&#xe1;n de Cliente</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Edicion de Articulos</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Edicion de Clientes</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Edicion de Presupuestos</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Edicion de Proveedores</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Editar/A&#xf1;adir cliente</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Listado de Albaranes</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Listado de Albaranes de Clientes</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Listado de Art&#xed;culos</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Listado de Clientes</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Listado de Pedidos</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Listado de Proveedores</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Nuevo Pedido</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Opened windows</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Presupuestos</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Seleccione Art&#xed;culo</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Seleccione cliente</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Seleccione proveedor</name>
    <message>
        <source>company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Splash</name>
    <message>
        <source>BulmaFact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>v 0.0.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BULMAG&#xc9;S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pepma sais hola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calibrando los lasers del lector de CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comprobando la disquetera y la Memoria Fisica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Induciendo energ&#xed;a quantica, entre su RAM y su ROM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peque&#xf1;os golpecitos de reajuste del HD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Probando la Velocidad el Ventilador de la CPU y su Frecuencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Haciendo PING contra el servidor de la MetaBase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Violando a Segmento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dejando tiempo libre al sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sincronizando fases Alfa Beta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flusheando Datos con vidas inteligentes superiores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permutando las tablas de partici&#xf3;n del sistema operativo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crackeando BulmaG&#xe9;s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>articleedit</name>
    <message>
        <source>Id. Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Referencia del Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beneficio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sobrecoste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Es Principal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Es de Referencia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>articleeditbase</name>
    <message encoding="UTF-8">
        <source>Artículo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Generales</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Descripción</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código de Barras</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Tipo de Artículo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compuesto Calculado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compuesto Escalado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ampliado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modelo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sobrecoste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Margen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Línea de Producción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Especificaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proveedores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ref. Pro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>articleslist</name>
    <message>
        <source>Identificador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&#xf3;digo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n Completa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&#xf3;digo de Barras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Especificaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Foto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Poster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Margen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sobrecoste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modelo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L&#xed;nea de Producci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>articleslistbase</name>
    <message encoding="UTF-8">
        <source>Listado Artículos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bulmafact</name>
    <message>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Application Example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This example demonstrates simple use of QMainWindow,
QMenuBar and QToolBar.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bulmafactbase</name>
    <message>
        <source>BulmaFact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ventas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maestro</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Artículos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toolbar_2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toolbar_3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toolbar_4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toolbar_5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listado de Proveedores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emitir Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nuevo Cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nuevo Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nueva Factura Recibida</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Caja</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bancos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cobrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pagar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Facturar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listado de clientes</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Listado de Artículos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pedidos </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listado de Pedidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listado de Albaranes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nuevo Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>new item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Facturas Recibidas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nuevo Pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Nuevo Albarán</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Facturacion Automática</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Facturación Automática</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nuevo Parte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Facturas Emitidas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entrega de Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listado de Presupuestos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>delivnoteslist</name>
    <message>
        <source>Identificador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A&#xf1;o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Compra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Albar&#xe1;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Alta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Recepci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Observaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Almac&#xe9;n</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>delivnoteslistbase</name>
    <message>
        <source>Listado Albaranes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>divisionbase</name>
    <message>
        <source>Division</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dirección</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Teléfono</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Nuestro código de cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre comercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos eComercio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Bancarios</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>linorderslist</name>
    <message>
        <source>N&#xba; L&#xed;nea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Prevista Entrega</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Albar&#xe1;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&#xf3;digo Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n Art&#xed;culo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>% IVA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>linorderslistbase</name>
    <message>
        <source>Pedido a Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>División</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dirección de recogida</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar pedido a partir de tarifas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar tarifas a partir de pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Artículo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ref.Prov</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p align=&quot;right&quot;&gt;IVA&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p align=&quot;right&quot;&gt;TOTAL&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p align=&quot;right&quot;&gt;Neto&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Número</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Almacén</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transporte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pendiente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No necesita transporte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A cargo del proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asignar transporte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asignado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seur Express</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Previsión</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>orderslist</name>
    <message>
        <source>Identificador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xfa;mero de pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A&#xf1;o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Emisi&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proveedor/Divisi&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Almac&#xe9;n</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>orderslistbase</name>
    <message>
        <source>Pedidos a Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>provedit</name>
    <message>
        <source>Id. Division</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descripci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Telefono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>idproveedor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>provedit_base</name>
    <message>
        <source>Proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Generales</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Nuestro código de cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dirección</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CP</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Província</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Illes Balears</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcelona</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>València</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tarragona</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Múrcia</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Teléfono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WEB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre comercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos Bancarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datos eComercio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Corporación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Divisiones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pers. Contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Productos Suministrados</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Artículo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ref. Pro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contratos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vigentes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vencidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Resumen por artículos</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Número</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concepto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Inicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha Vencimiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>% Consumido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consumidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pendientes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>providerslist</name>
    <message>
        <source>C&#xf3;digo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre Fiscal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre Comercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF/NIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C&#xf3;digo de cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuenta Bancaria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Observaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domicilio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Poblaci&#xf3;n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C.P.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Tel&#xe9;fono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N&#xba; Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Correo Electr&#xf3;nico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&#xe1;gina Web</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clave propia web proveedor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>providerslistbase</name>
    <message>
        <source>Listado Proveedores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Población</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
