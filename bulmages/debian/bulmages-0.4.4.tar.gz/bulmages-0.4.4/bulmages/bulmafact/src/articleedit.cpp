/***************************************************************************
 *   Copyright (C) 2004 by Alvaro de Miguel                                *
 *   alvaro_demiguel@gmail.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
 
/*
CREATE TABLE articulo (
    idarticulo serial PRIMARY KEY,
    codarticulo character varying(12),
    nomarticulo character varying(50),
    descarticulo character varying(500),
    cbarrasarticulo character varying(22),
    tipoarticulo integer,
    descuentoarticulo float,
    especificacionesarticulo character varying(2000),
    iconoarticulo oid,
    fotoarticulo oid,
    posterarticulo oid,
    margenarticulo float,
    sobrecostearticulo float,
    modeloarticulo character varying(1000),
    
    idtipo_iva integer REFERENCES tipo_iva (idtipo_iva),
    idlinea_prod integer REFERENCES linea_prod(idlinea_prod)
); 
*/ 
 
#include "articleedit.h"
#include "company.h"
#include "division.h"
#include <qlineedit.h>
#include <qmessagebox.h>
#include <qtable.h>
#include <qcombobox.h>
#include <qtextedit.h>

#define COL_SUMINISTRA_IDSUMINISTRA 0
#define COL_SUMINISTRA_IDPROVEEDOR 0
#define COL_SUMINISTRA_NOMPROVEEDOR 1
#define COL_SUMINISTRA_REFPRO 2
#define COL_SUMINISTRA_PVD 3
#define COL_SUMINISTRA_BENEFICIO 4
#define COL_SUMINISTRA_SOBRECOSTE 5
#define COL_SUMINISTRA_PRINCIPAL 6
#define COL_SUMINISTRA_REFERENT 7


articleedit::articleedit(company *comp, QWidget *parent, const char *name)
 : articleeditbase(parent, name, Qt::WDestructiveClose) {
   companyact = comp;
   idArticle = "0";
   
   
   // Arreglamos la tabla de proveedores del art�culo
   m_suministra->setNumRows( 0 );
   m_suministra->setNumCols( 0 );
   m_suministra->setSelectionMode( QTable::SingleRow );
   m_suministra->setSorting( TRUE );
   m_suministra->setSelectionMode( QTable::SingleRow );
   m_suministra->setColumnMovingEnabled( TRUE );
   m_suministra->setNumCols(8);
   m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_IDPROVEEDOR, tr( "Id. Proveedor" ) );
	m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_NOMPROVEEDOR, tr( "Nombre Proveedor" ) );
	m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_REFPRO, tr( "Referencia del Proveedor" ) );
	m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_PVD, tr( "PVD" ) );
	m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_BENEFICIO, tr( "Beneficio" ) );
	m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_SOBRECOSTE, tr( "Sobrecoste" ) );
	m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_PRINCIPAL, tr( "Es Principal" ) );
	m_suministra->horizontalHeader()->setLabel( COL_SUMINISTRA_REFERENT, tr( "Es de Referencia" ) );
   
	m_suministra->setColumnWidth(COL_SUMINISTRA_IDPROVEEDOR,100);
	m_suministra->setColumnWidth(COL_SUMINISTRA_NOMPROVEEDOR,300);
	m_suministra->setColumnWidth(COL_SUMINISTRA_REFPRO,100);
	m_suministra->setColumnWidth(COL_SUMINISTRA_PVD,100);
	m_suministra->setColumnWidth(COL_SUMINISTRA_BENEFICIO,100);
	m_suministra->setColumnWidth(COL_SUMINISTRA_SOBRECOSTE,100);
	m_suministra->setColumnWidth(COL_SUMINISTRA_PRINCIPAL,100);
	m_suministra->setColumnWidth(COL_SUMINISTRA_REFERENT,100);
	
	m_suministra->hideColumn(COL_SUMINISTRA_IDPROVEEDOR);
	m_suministra->setColumnReadOnly(COL_SUMINISTRA_NOMPROVEEDOR,true);

}// end articleedit

articleedit::~articleedit() {
	companyact->refreshArticles();
}// end ~articleedit


/************************************************************************
* Esta funci�n carga un art�culo de la base de datos y lo presenta.     *
* Si el parametro pasado no es un identificador v�lido entonces se pone *
* la ventana de edici�n en modo de inserci�n                            *
*************************************************************************/
void articleedit::chargeArticle(QString idArt) {
   idArticle = idArt;
	QString ivaType="";
   fprintf(stderr,"chargeArticle activado \n");
   if (idArticle != "0") {
      QString SQLQuery = "SELECT * FROM articulo WHERE idarticulo="+idArt;
      companyact->begin();
      cursor2 *cur= companyact->cargacursor(SQLQuery, "unquery");
      companyact->commit();
      if (!cur->eof()) {
         idArticle = idArt;
         m_articleCode->setText(cur->valor("codarticulo"));
         m_articleName->setText(cur->valor("nomarticulo"));
         m_articleDesc->setText(cur->valor("descarticulo"));
         m_barCode->setText(cur->valor("cbarrasarticulo"));
         m_articleDiscount->setText(cur->valor("descuentoarticulo"));
         m_specifications->setText(cur->valor("especificacionesarticulo"));
         m_articleMargin->setText(cur->valor("margenarticulo"));
         m_articleOverCost->setText(cur->valor("sobrecostearticulo"));
         m_articleModel->setText(cur->valor("modeloarticulo"));
			ivaType=cur->valor("idtipo_iva");
			m_comboArtType->setCurrentItem(cur->valor("tipoarticulo").toInt());
   //      m_productionLine->setText());
         
         // Suministra relation loading
         // Cargamos las relaciones art�culo - proveedor.
         QString SQLQuery1 = "SELECT * FROM suministra, proveedor WHERE suministra.idproveedor=proveedor.idproveedor and idarticulo="+idArt;
         companyact->begin();
         cursor2 *cur1 = companyact->cargacursor(SQLQuery1, "cargaSuministra");
         companyact->commit();
         m_suministra->setNumRows(cur1->numregistros());
         int i=0;
         while (!cur1->eof()) {
            m_suministra->setText(i,COL_SUMINISTRA_IDPROVEEDOR,cur1->valor("idproveedor"));
            m_suministra->setText(i,COL_SUMINISTRA_NOMPROVEEDOR,cur1->valor("nomproveedor"));
            m_suministra->setText(i,COL_SUMINISTRA_REFPRO,cur1->valor("refprosuministra"));
            m_suministra->setText(i,COL_SUMINISTRA_PVD,cur1->valor("pvdsuministra"));
            m_suministra->setText(i,COL_SUMINISTRA_BENEFICIO,cur1->valor("beneficiosuministra"));
            m_suministra->setText(i,COL_SUMINISTRA_SOBRECOSTE,cur1->valor("sobrecostesuministra"));
            m_suministra->setText(i,COL_SUMINISTRA_PRINCIPAL,cur1->valor("principalsuministra"));
            m_suministra->setText(i++,COL_SUMINISTRA_REFERENT,cur1->valor("referentsuministra"));
            cur1->siguienteregistro();
         }// end while
         delete cur1;
      } else {
         idArticle="0";
      }// end if
      delete cur;
   }
	cargarcomboiva(ivaType);
}// end chargeArticle


void articleedit::cargarcomboiva(QString idIva) {
	m_cursorcombo = NULL;
   companyact->begin();
   if (m_cursorcombo != NULL) delete m_cursorcombo;
   	m_cursorcombo = companyact->cargacursor("SELECT * FROM tipo_iva","unquery");
   	companyact->commit();
   	int i = 0;
   	int i1 = 0;   
   	while (!m_cursorcombo->eof()) {
   		i ++;
		if (idIva == m_cursorcombo->valor("idtipo_iva")) {
		   i1 = i;
		}
   		m_comboIvaType->insertItem(m_cursorcombo->valor("desctipo_iva"));
		m_cursorcombo->siguienteregistro();
   }
   if (i1 != 0 ) {
   	m_comboIvaType->setCurrentItem(i1-1);
   }
} // end cargarcomboalmacen


/************************************************************************
* Esta funci�n se ejecuta cuando se ha pulsado sobre el bot�n de nuevo  *
*************************************************************************/
void articleedit::boton_nuevo() {
	idArticle = "0";
	m_articleCode->setText("");
	m_articleName->setText("");
	m_articleDesc->setText("");
	m_barCode->setText("");
  //       m_comboIvaType ...
	m_articleDiscount->setText("");
	m_specifications->setText("");
	m_articleMargin->setText("");
	m_articleOverCost->setText("");
	m_articleModel->setText("");
	m_productionLine->setText("");
	m_comboArtType->setCurrentItem(0);
	m_comboIvaType->setCurrentItem(0);
}// end boton_nuevo

/*************************************************************************
* Esta funci�n es la respuesta a la pulsaci�n del boton de guardar       *
* Comprueba si es una inserci�n o una modificaci�n y hace los pasos      *
* pertinentes                                                            *
**************************************************************************/
void articleedit::accept() {
	QString SQLQuery;
	if (idArticle != "0") {
      SQLQuery = "UPDATE articulo SET codarticulo='"+m_articleCode->text()+"'";
      SQLQuery += " , nomarticulo='"+m_articleName->text()+"'";
      SQLQuery += " , descarticulo='"+m_articleDesc->text()+"'";
      SQLQuery += " , cbarrasarticulo='"+m_barCode->text()+"'";
      SQLQuery += " , tipoarticulo="+QString().sprintf("%d", m_comboArtType->currentItem());
      SQLQuery += " , descuentoarticulo="+m_articleDiscount->text();
      SQLQuery += " , especificacionesarticulo='"+m_specifications->text()+"'";
      SQLQuery += " , margenarticulo="+m_articleMargin->text();
      SQLQuery += " , sobrecostearticulo="+m_articleOverCost->text();
      SQLQuery += " , modeloarticulo='"+m_articleModel->text()+"'";
      SQLQuery += " , idtipo_iva="+m_cursorcombo->valor("idtipo_iva",m_comboIvaType->currentItem());
    //  SQLQuery += " , idlinea_prod='"+... ;
      SQLQuery += " WHERE idarticulo ="+idArticle;
   } else {
      QString SQLQuery = " INSERT INTO articulo (codarticulo, nomarticulo, descarticulo, cbarrasarticulo, tipoarticulo, descuentoarticulo, especificacionesarticulo, margenarticulo, sobrecostearticulo, modeloarticulo, idtipo_iva)";
      SQLQuery += " VALUES (";
      SQLQuery += " "+m_articleCode->text();
      SQLQuery += " , '"+m_articleName->text()+"'";
      SQLQuery += " , '"+m_articleDesc->text()+"'";
      SQLQuery += " , '"+m_barCode->text()+"'";
      SQLQuery += " , "+QString().sprintf("%d", m_comboArtType->currentItem());
      SQLQuery += " , "+m_articleDiscount->text();
      SQLQuery += " , '"+m_specifications->text()+"'";
      SQLQuery += " , "+m_articleMargin->text();
      SQLQuery += " , "+m_articleOverCost->text();
      SQLQuery += " , '"+m_articleModel->text()+"'";
      SQLQuery += " , "+m_cursorcombo->valor("idtipo_iva",m_comboIvaType->currentItem());
    //  SQLQuery += " , idlinea_prod='"+... ;
      SQLQuery += ")";
      companyact->begin();
      companyact->ejecuta(SQLQuery);
      companyact->commit(); 
      close(); 
   }// end if */
	companyact->begin();
	if (companyact->ejecuta(SQLQuery)==0) {
		companyact->commit();
		close();
	} else {
		companyact->rollback();
	}
}// end accept

/************************************************************************
* Esta funci�n se ejecuta cuando se ha pulsado sobre el bot�n de borrar *
*************************************************************************/
void articleedit::boton_borrar() {
   if (idArticle != "0") {
      if ( QMessageBox::Yes == QMessageBox::question(this,"Borrar Art�culo","Esta a punto de borrar un art�culo, Estos datos pueden dar problemas.",QMessageBox::Yes, QMessageBox::No)) {
         QString SQLQuery="DELETE FROM articulo WHERE idarticulo="+idArticle;
         companyact->begin();
         if (companyact->ejecuta(SQLQuery)==0) {
         	companyact->commit();
         	close();
			} else {
				companyact->rollback();
			}
      }// end if
   }// end if
}// end boton_borrar


void articleedit::articleDiscountLostFocus() {
	m_articleDiscount->setText(m_articleDiscount->text().replace(",","."));
}


void articleedit::articleMarginLostFocus() {
	m_articleMargin->setText(m_articleMargin->text().replace(",","."));
}


void articleedit::articleOverCostLostFocus() {
	m_articleOverCost->setText(m_articleOverCost->text().replace(",","."));
}
