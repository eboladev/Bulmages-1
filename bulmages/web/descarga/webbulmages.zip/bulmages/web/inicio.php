<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="estilos.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0"><CENTER>
<?php
	include ("cabecera.inc");
?>
	<table border="0" cellspacing="0" cellpadding="0" height="88%" bordercolor="#333333" width="750">
  <tr>
      <td width="164" bgcolor="#FFFFFF" valign="top" bordercolor="#003366" height="544"> 
<?php
	include("menu.inc");
?>   
<!-- -------------------------------- -->
<!-- -------------------------------- -->
      
      </td>
      <td width="652" valign="top" align="left" bgcolor="#FFFFFF" height="544"> 
         <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#000033">
		
            <tr> 
               <td bgcolor="#FFFFFF" valign="top" align="center" height="445">
                     <p><font face="Verdana, Arial, Helvetica, sans-serif"><font color="#0000FF" size="+2">Proyecto BulmaGes</font></font></p>
                  <table width="96%" border="0" cellspacing="0" cellpadding="0">
                     <tr>
                        <td>
                                    
                              <p align="justify"><font size="-1"><b>Quienes Somos</b></font></p>
                           </td>
                     </tr>
                  </table>
                     <p><BR>
                     BulmaGes es un proyecto dedicado a realizar una gesti&oacute;n empresarial integral para LINUX.</p>
                     <p>Nacio del corazon de la lista de distribuci&oacute;n de Bulma, donde se comento la necesidad de crear programas de gesti&oacute;n empresarial para Linux. Y donde se propuso la creaci&oacute;n de un grupo para desarrollar este tipo de software.</p>
                     <p>&nbsp;</p>
                     <table width="100%" border="1" cellspacing="0" cellpadding="0">
                        <tr>
                           <td bgcolor="#009933"><b>Reuni&oacute;n 18/08/2001</b></td>
                        </tr>
                        <tr>
                           <td>
                              <LI> Se estableci&oacute; el <a href="desarrollo.php">modelo inicial</a> de base de datos
                              <LI> Se propuso la base de datos PostGres como base de datos de referencia
                              <LI> Se propuso la primera codificaci&oacute;n en tecnologia Phyton/Pyro por los siguientes motivos
                              <UL><LI> Independencia de plataforma: Funcionara tanto en windows como en linux como en mac.
                              <LI> Entorno gr&aacute;fico: La aplicaci�n ser� en entorno gr�fico.
										</UL>
                              <LI> Tambien se propuso ncurses como desarrollo en modo texto.
                           </td>
                        </tr>
                     </table>
                     <p>&nbsp;</p>
                     </td>
               <td bgcolor="#FFFFFF" valign="middle" align="center" height="445"><img src="img/shim.gif" width="1" height="1"></td>
            </tr>
         </table>
    </td>
  </tr>
</table>
</CENTER>
</body>
</html>
