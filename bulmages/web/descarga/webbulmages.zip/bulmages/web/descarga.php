<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="estilos.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0"><CENTER>
<?php
	include ("cabecera.inc");
?>
	<table border="0" cellspacing="0" cellpadding="0" height="88%" bordercolor="#333333" width="750">
  <tr>
      <td width="164" bgcolor="#FFFFFF" valign="top" bordercolor="#003366" height="544"> 
<?php
	include("menu.inc");
?>   
<!-- -------------------------------- -->
<!-- -------------------------------- -->
      
      </td>
      <td width="652" valign="top" align="left" bgcolor="#FFFFFF" height="544"> 
         <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#000033">
		
            <tr> 
               <td bgcolor="#FFFFFF" valign="top" align="center" height="445">
                     <p><font face="Verdana, Arial, Helvetica, sans-serif"><font color="#0000FF" size="+2">Proyecto BulmaGes</font></font></p>
                  <table width="96%" border="0" cellspacing="0" cellpadding="0">
                     <tr>
                        <td>
                                    
                              <p align="justify"><font size="-1"><b>Descarga</b></font></p>
                           </td>
                     </tr>
                  </table>
                     <p><BR>
                     Descarga este web, hazle las modificaciones oportunas y <a href="mailto:tborras@conetxia.com">mandamelas</a> para ir completandolo. Requiere php</p>
                     <p>Pulsa <a href="descarga/webbulmages.tgz">aqui</a> para descargarlo en versi&oacute;n tgz.</p>
                     <p>Pulsa <a href="descarga/webbulmages.zip">aqui</a> para descargarlo en version zip.</p>
                     <p>&nbsp;</p>
                     <p>Proximamente estar&aacute; disponible el modelo de base de datos para PostGres</p>
                     </td>
               <td bgcolor="#FFFFFF" valign="middle" align="center" height="445"><img src="img/shim.gif" width="1" height="1"></td>
            </tr>
         </table>
    </td>
  </tr>
</table>
</CENTER>
</body>
</html>
