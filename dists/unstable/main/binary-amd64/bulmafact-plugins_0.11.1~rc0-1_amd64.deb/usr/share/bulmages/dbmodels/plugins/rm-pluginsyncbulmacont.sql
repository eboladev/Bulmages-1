--
-- Modificación de campos y funciones de la BD para la adaptacion para el plugin de Trazabilidad
--
\echo "********* INICIADO DESINSTALADOR DE ESTRUCTURA DEL PLUGIN DE SINCRONIZACION CON BULMACONT *********"

\echo ":: Establecemos los mensajes minimos a avisos y otros parametros ... "
\echo -n ":: "
SET client_min_messages TO WARNING;
SET log_min_messages TO WARNING;
-- SET log_error_verbosity TO TERSE;
BEGIN;

--
-- Estas primeras funciones cambiaran los tipos de columnas que est� como flotantes a NUMERIC.
-- Se trata de un parche que se desea aplicar para almacenar los tipos monetarios
-- ya que actualmente se encuantran almacenados como 'doubles' y es preferible
-- que se almacenen como tipo 'numeric'.
-- Todas devuelven como valor numeico el nmero de filas influenciadas por el cambio
--
-- Función auxiliar para borrar funciones limpiamente
--
create or replace function drop_if_exists_table (text) returns INTEGER AS '
DECLARE
tbl_name ALIAS FOR $1;
BEGIN
IF (select count(*) from pg_tables where tablename=$1) THEN
 EXECUTE ''DROP TABLE '' || $1;
RETURN 1;
END IF;
RETURN 0;
END;
'
language 'plpgsql';


create or replace function drop_if_exists_proc (text,text) returns INTEGER AS '
DECLARE
proc_name ALIAS FOR $1;
proc_params ALIAS FOR $2;
BEGIN
IF (select count(*) from pg_proc where proname=$1) THEN
 EXECUTE ''DROP FUNCTION '' || $1 || ''(''||$2||'') CASCADE'';
RETURN 1;
END IF;
RETURN 0;
END;
'
language 'plpgsql';


CREATE OR REPLACE FUNCTION aux() RETURNS INTEGER AS $$
DECLARE
	bs RECORD;
BEGIN
--	SELECT INTO bs valor FROM configuracion WHERE nombre='DataBaseContabilidad';
--	IF NOT FOUND THEN
--		INSERT INTO configuracion (nombre, valor) VALUES ('DataBaseContabilidad', 'bulmacont');
--	END IF;

	DELETE FROM configuracion WHERE nombre='DataBaseContabilidad';


	SELECT INTO bs viewname FROM pg_views WHERE viewname='bc_cuenta';
	IF FOUND THEN
		DROP VIEW bc_cuenta;
	END IF;
--	CREATE OR REPLACE view BC_Cuenta AS SELECT * FROM dblink( 'SELECT idgrupo, idcuenta, codigo, descripcion, tipocuenta FROM cuenta') AS t1 (idgrupo integer, idcuenta integer, codigo varchar, descripcion varchar, tipocuenta integer);


	SELECT INTO bs viewname FROM pg_views WHERE viewname ='BC_Asiento';
	IF FOUND THEN
		DROP VIEW bc_Asiento;
--	CREATE OR REPLACE VIEW BC_Asiento AS SELECT * FROM dblink( 'SELECT idasiento FROM asiento') AS t1 (idasiento integer);

		DROP VIEW BC_Borrador;
--	CREATE OR REPLACE VIEW BC_Borrador AS SELECT * FROM dblink( 'SELECT idborrador FROM borrador') AS t1 (idborrador integer);

		DROP VIEW BC_Apunte;
--	CREATE OR REPLACE VIEW BC_Apunte AS SELECT * FROM dblink( 'SELECT idapunte FROM apunte') AS t1 (idapunte integer);
        END IF;

	SELECT INTO bs * FROM pg_attribute WHERE attname='idasientofactura';
	IF FOUND THEN
--		ALTER TABLE factura ADD COLUMN idasientofactura INTEGER;
		ALTER TABLE factura DROP COLUMN idasientofactura;
	END IF;

	SELECT INTO bs * FROM pg_attribute WHERE attname='idcuentacliente';
	IF FOUND THEN
--		ALTER TABLE cliente ADD COLUMN idcuentacliente INTEGER;
		ALTER TABLE cliente DROP COLUMN idcuentacliente;
	END IF;


	SELECT INTO bs * FROM pg_attribute WHERE attname='idasientofacturap';
	IF FOUND THEN
--		ALTER TABLE facturap ADD COLUMN idasientofacturap INTEGER;
		ALTER TABLE facturap DROP COLUMN idasientofacturap;
	END IF;

	SELECT INTO bs * FROM pg_attribute WHERE attname='idcuentaproveedor';
	IF FOUND THEN
--		ALTER TABLE proveedor ADD COLUMN idcuentaproveedor INTEGER;
		ALTER TABLE proveedor DROP COLUMN idcuentaproveedor;
	END IF;

	-- Creamos el espacio para almacenar el identificador de cuenta que corresponde al banco.
	SELECT INTO bs * FROM pg_attribute WHERE attname='idcuentabanco';
	IF FOUND THEN
--		ALTER TABLE banco ADD COLUMN idcuentabanco INTEGER;
		ALTER TABLE banco DROP COLUMN idcuentabanco;
	END IF;

	-- Creamos el espacio para almacenar el identificador de cuenta que corresponde al almacen
	SELECT INTO bs * FROM pg_attribute WHERE attname='idcuentaalmacen';
	IF FOUND THEN
--		ALTER TABLE almacen ADD COLUMN idcuentaalmacen INTEGER;
		ALTER TABLE almacen DROP COLUMN idcuentaalmacen;
	END IF;

	-- Creamos el espacio para almacenar el identificador de cuenta que corresponde al cobro
	SELECT INTO bs * FROM pg_attribute WHERE attname='idasientocobro';
	IF FOUND THEN
--		ALTER TABLE cobro ADD COLUMN idasientocobro INTEGER;
		ALTER TABLE cobro DROP COLUMN idasientocobro;
	END IF;
	-- Creamos el espacio para almacenar el identificador de cuenta que corresponde al pago
	SELECT INTO bs * FROM pg_attribute WHERE attname='idasientopago';
	IF FOUND THEN
--		ALTER TABLE pago ADD COLUMN idasientopago INTEGER;
		ALTER TABLE pago DROP COLUMN idasientopago;
	END IF;

	RETURN 0;
END;
$$   LANGUAGE plpgsql;
SELECT aux();
DROP FUNCTION aux() CASCADE;
\echo "Quitamos los campos para almacenar claves foraneas en las tablas necesarias."


SELECT drop_if_exists_proc('conectabulmacont', '');
SELECT drop_if_exists_proc ('syncbulmacontpagod','');
\echo "Borrado el trigger que al borrar una factura borra su respectivo asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontpagou','');
\echo "Borrado el trigger que al modificar o insertar una factura en la facturacion mete el correspondiente asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontcobrod','');
\echo "Borrado el trigger que al borrar un cobro borra su respectivo asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontcobrou','');
\echo "Borradoo el trigger que al modificar o insertar una factura en la facturacion mete el correspondiente asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontfacturad','');
\echo "Borrado el trigger que al borrar una factura borra su respectivo asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontfacturau','');
\echo "Borrado el trigger que al modificar o insertar una factura en la facturacion mete el correspondiente asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontfacturapd','');
\echo "Borrado el Trigger que al borrar una factura de proveedor la borra de la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontfacturapu','');
\echo "Borrado el trigger que al modificar o insertar una factura  de proveedor en la facturacion mete el correspondiente asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontcliented','');
SELECT drop_if_exists_proc ('syncbulmacontclienteu','');
SELECT drop_if_exists_proc ('syncbulmacontproveedord','');
SELECT drop_if_exists_proc ('syncbulmacontproveedoru','');
SELECT drop_if_exists_proc ('syncbulmacontbancod','');
\echo "Borrado el trigger que al borrar un banco borra la respectiva cuenta en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontbancou','');
\echo "Borrado el trigger que al modificar o insertar un banco en la facturacion mete el correspondiente asiento en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontalmacend','');
\echo "Borrado el trigger que al borrar un banco borra la respectiva cuenta en la contabilidad"
SELECT drop_if_exists_proc ('syncbulmacontalmacenu','');
\echo "Borrado el trigger que al modificar o insertar un almacen en la facturacion mete el correspondiente asiento en la contabilidad"

-- Agregamos nuevos parametros de configuracion.
--
CREATE OR REPLACE FUNCTION actualizarevision() RETURNS INTEGER AS '
DECLARE
	as RECORD;
BEGIN
	DELETE FROM configuracion WHERE nombre=''DBRev-SyncBulmaCont'';
	RETURN 0;
END;
'   LANGUAGE plpgsql;
SELECT actualizarevision();
DROP FUNCTION actualizarevision() CASCADE;
\echo "Actualizada la revision de la base de datos"


DROP FUNCTION drop_if_exists_table(text) CASCADE;
DROP FUNCTION drop_if_exists_proc(text,text) CASCADE;


COMMIT;