<?php include ("inc/funciones.inc") ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!--
Este documento se encarga de la inserci�n de una nueva cuenta.
Solo de la presentaci�n, funciona en conjuncion con nuevacuenta1.php que se encarga de 
la inserci�n en la base de datos.
Se supone que se abrira en forma de popup y su mision es la de insertar una cuenta.
Se le pasan una seria de parametros GET que indican los campos que ya estan rellenados.
-->
<html>
<head>
<title>Inserci�n de Cuentas en BulmaG�s</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<FORM name="form1" method="POST" action="nuevacuetna1.php">
<INPUT TYPE="text" NAME="codigo" VALUE="">
<INPUT TYPE="text" NAME="cifent_cuenta" VALUE="">
</FORM>


</body>
</html>
