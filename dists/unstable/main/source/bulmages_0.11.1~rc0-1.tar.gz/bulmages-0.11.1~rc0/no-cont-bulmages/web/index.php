<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>
              <?php include("inc/cabecera.php") ?>
              </strong></font> </td>
          </tr>
          <tr> 
            <td><table border="0" width="97%" align="center" cellpadding="0" cellspacing="0">
<tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td>
                    <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td height="19">
						
				  <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;BulmaG&eacute;s 
                                Presentaci&oacute;n</strong></font></td>
                            </tr>
                          </table>
						
						</td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                        objetivo fundamental del proyecto BulmaG&eacute;s 
                                        es introducir el sistema operativo GNU/Linux 
                                        en el &aacute;mbito empresarial.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                        razonamiento llevado a cabo es que todo 
                                        empresa que pretenda relizar una migraci&oacute;n 
                                        seria hacia el mundo del Software Libre 
                                        empezar&aacute; dicha migraci&oacute;n 
                                        por un departamento poco comprometido, 
                                        con aplicativos aislados y independiente 
                                        del normal funcionamiento de la empresa.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                        mejor candidato que se nos ocurre es el 
                                        departamento contable, por tanto centramos 
                                        todos nuestros esfuerzos en ofrecer al 
                                        mundo empresarial, de forma gratuita, 
                                        un programa de Contabilidad que satisfaga 
                                        a los contables m&aacute;s exigentes, 
                                        que sea sencillo, r&aacute;pido y efectivo 
                                        y al mismo tiempo permita futuras integraciones 
                                        interdepartamentales.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Bajo 
                                        este marco y filosofia presentamos el 
                                        programa de contabilidad BulmaG&eacute;s</font></p>
                                      </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;BulmaG&eacute;s 
                                0.4.1</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
<TABLE border="0"><TR>
<TD><A HREF="http://bulma.net/~tborras/bges041/splash.png"><IMG SRC="http://bulma.net/~tborras/bges041/splashp.png" BORDER="0"></A></TD>
<TD><P><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
             Reci�n sacada del horno la versi&oacute;n 0.4.1 de<strong>BulmaG�s</strong>.
</P>
<P align="justify">
             Nuevas capacidades, nuevos proyectos. De esta nueva versi&oacute;n hay muchas cosas que contar. Como el proyecto BContaWeb, los inicios de BulmaFact, la integraci&oacute;n con Reports de Santiago Capel, importaci�n de datos desde Contaplus, etc
          </P></font>
</TD>


</TR></TABLE>
				    				    
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Puede 
                                        descargarla en nuestra secci&oacute;n 
                                        de <a href="descarga.php">download</a></font></p>
                                      </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
						  <br><br>
                          <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;<font color="#990000">BulmaG&eacute;s 
                                Code Parties</font></strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Los 
                                        colaboradores del proyecto organizan cada 
                                        semana una Code Party de BulmaG&eacute;s 
                                        y est&aacute;is todos invitados. Salvo 
                                        aviso, ser&aacute; cada domingo por la 
                                        tarde (sobre las 17:00 h.)</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Si 
                                        quieres m&aacute;s informaci&oacute;n 
                                        o confirmar tu asistencia escribe a la 
                                        lista de distribuci&oacute;n del proyecto. 
                                        Vamos... &iquest;a qu&eacute; esperas?</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <p align="right">&nbsp;</p></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
