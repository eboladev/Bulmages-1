<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<style type="text/css">
<!--
a {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #666666;
	text-decoration: none;
}

a:hover {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #663300;
	text-decoration: underline;
}

-->
</style>
</head>
<body bgcolor="#cdd5d8">
<table width="684" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td valign="bottom"><?php include("inc/cabecera.php") ?>
    </td>
  </tr>
  <tr> 
    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr valign="top"> 
          <td width="15%"><div align="right"><img name="home_r3_c2" src="img/cabecera/borde.gif" width="22" height="498" border="0" alt=""></div></td>
          <td width="18%"><?php include("inc/menuizq.php")?></td>
          <td><table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
              <tr>
                <td valign="top"><BR>
				<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
                    <tr> 
                      <td><div align="left"><strong><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Documentaci&oacute;n 
                          Disponible:</font></strong></div></td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr> 
                <td valign="top"><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                    <tr> 
                      <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr> 
                            <td width="3%">&nbsp;</td>
                            <td width="97%"><a href="manualindex.php" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Manual 
                              Bulmages</font> </a></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table>
                  <BR> <table width="97%" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#999999">
                    <tr> 
                      <td height="43"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                          manual del usuario de BulmaGes (a&uacute;n incompleto)</font></div></td>
                    </tr>
                  </table>
                  <table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
                    <tr> 
                      <td>&nbsp;</td>
                      <td><div align="right"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>versi&oacute;n 
                          para imprimir</strong></font></div></td>
                    </tr>
                  </table><BR>
                  <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                    <tr> 
                      <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr> 
                            <td width="3%">&nbsp;</td>
                            <td width="97%"><a href="screenshot.php" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Screenshots</font></a></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table>
                  <BR> <table width="97%" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#999999">
                    <tr> 
                      <td><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Algunos 
                          pantallazos del programa</font></div></td>
                    </tr>
                  </table>
                  <p>&nbsp;</p></td>
              </tr>
              <tr> 
                <td valign="top">&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
              </tr>
            </table></td>
          <td width="1%"><img name="home_r3_c5" src="img/cabecera/home_r3_c5.gif" width="24" height="498" border="0" alt=""></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td valign="top"><div align="right"><?php include("inc/pie.php") ?></div></td>
  </tr>
</table>
</body>
</html>
