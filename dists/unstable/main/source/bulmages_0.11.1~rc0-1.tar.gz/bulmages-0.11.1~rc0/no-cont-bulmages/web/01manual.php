<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/01cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/01menuizq.php")?>
                    </div></td>
                  <td width="66%"><table width="506" height="498" border="0" cellpadding="0" cellspacing="0">
<tr> 
                        <td height="19">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Manual 
                                de Bulmages</strong></font></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><a href="01manualindex.php" target="manual">Vesi� 
                                HTML</a><br>
                                <br>
                                <a href="descarga/manual_bulmages_0_3_1.pdf" target="manual">Versi� 
                                PDF</a></td>
                            </tr>
                          </table>
                          <p align="right"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif"></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;</font></p>
                          <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Ajudes 
                                a Desenvolupadors</strong></font></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://bulmages.bulma.net/erm/" target="_blank">Explicaci&oacute; 
                                dels diagrames de Base de Dades (DER)</a></font></td>
                            </tr>
                          </table>
                          <p align="right"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif"></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;</font></p>
                          <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr>
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Com
                                    instal&middot;lar  BulmaG&eacute;s en Linux - Mandrake
                                    10.0 (RC1) </strong></font></td>
                            </tr>
                          </table>
                          <BR>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr>
                              <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.burcion.com/bginstall.htm" target="_blank"> "How
                                    to" basat en la distribuci&oacute; Francesa
                                    Linux- Mandrake versi&oacute; en desenvolupament  (cooker)
                                    10.0 (RC1). </a></font></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/01pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
