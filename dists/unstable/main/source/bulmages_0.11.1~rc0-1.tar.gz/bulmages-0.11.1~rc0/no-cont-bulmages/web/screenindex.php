<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td width="71%"> <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td valign="top"><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tr> 
                                    <td width="3%">&nbsp;</td>
                                    <td width="97%"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">ScreenShots</font></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <div align="center"><BR>
                            <table width="90%" border="1" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                              <tr>
                                <td>
								<br>
								<table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td>
									  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="60%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/mdi.png"><img src="img/splash/mdi.gif" width="86" height="72" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Esta 
                                                imagen presenta el entorno de 
                                                trabajo. Muestra la introducci�n 
                                                de apuntes, el libro diario, el 
                                                extracto y algunos balances. </font></div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" cellspacing="0" cellpadding="3">
                                          <tr> 
                                            <td width="72%" valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Captura 
                                                de una gr�fica de movimientos 
                                                para la pantalla de seguimiento 
                                                de cuentas. Las librer&iacute;as 
                                                de generaci&oacute;n de gr&aacute;ficos 
                                                est&aacute;n realizadas por el 
                                                <a href="http://www.globecom.se/tora/">proyecto 
                                                Tora</a></font></div></td>
                                            <td width="3%">&nbsp;</td>
                                            <td width="25%"><div align="center"> 
                                                <table width="73%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/estadisticas.png"><img src="img/splash/estadisticas.gif" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                          </tr>
                                        </table> </td>
                                    </tr>
                                  </table>
								  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="23%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/mpatrimoniales.png"><img src="img/splash/mpatrimoniales.gif" width="100" height="69"  border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><BR>
                                                Ejemplo de Composicion de masas 
                                                patrimoniales.</font></div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" cellspacing="0" cellpadding="3">
                                          <tr> 
                                            <td width="73%" valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                                Ejemplo de Composicion de balances. 
                                                </font></div></td>
                                            <td width="1%">&nbsp;</td>
                                            <td width="26%"><div align="center"> 
                                                <table width="72%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/compbalance.png"><img src="img/splash/compbalance.gif" width="100" height="51" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
								  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="77%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/librodiario.png"><img src="img/splash/librodiario.gif" width="100" height="75" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Esta 
                                                imagen muestra el diario en modo 
                                                aprendizaje y formato HTML, creado 
                                                por Toni Mirabete.</font></div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" cellspacing="0" cellpadding="3">
                                          <tr> 
                                            <td width="70%" valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                                Vista del diario usando el proyecto 
                                                reports.</font></div></td>
                                            <td width="4%">&nbsp;</td>
                                            <td width="26%"><div align="center"> 
                                                <table width="71%" border="1" align="center" cellpadding="0" cellspacing="0">
                                                  <tr> 
                                                    <td><a href="img/librodiario1.png"><img src="img/splash/librodiario1.gif" width="100" height="71"  border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
								  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="80%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/splash.png"><img src="img/splash/splash.gif" width="100" height="80" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Splash 
                                                del programa para la versi�n 0.3.1 
                                                imagen cedida por <a href="http://www.fotonatura.org/galerias/foto.php?id_foto=27130&id_galeria=16">Victor 
                                                Bas</a>.</font></div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  
                                </td>
                              </tr>
                            </table>
                            
                          </div>
						  </td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
