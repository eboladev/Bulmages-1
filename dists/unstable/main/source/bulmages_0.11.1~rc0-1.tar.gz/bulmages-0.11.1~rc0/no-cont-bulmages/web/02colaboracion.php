<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/02cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/02menuizq.php")?>
                    </div></td>
                  <td width="66%"><table width="506" height="498" border="0" cellpadding="0" cellspacing="0">
<tr> 
                        <td height="19">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp; 
                                Want to collaborate?</strong></font></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">As 
                                        BulmaGes is a 100% GPL project, it's nourished 
                                        mainly of collaborations.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">The 
                                        first and only step to collaborate in 
                                        this project is to register in the mailing 
                                        list. This way you will be in contact 
                                        with all the members of BulmaGes. The 
                                        task distribution is completely voluntary.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Please 
                                        remembers that it is worse to say that 
                                        you are going to do something but not 
                                        to do it, that not to say anything. Think 
                                        it well before commit yourself.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Anyone 
                                        can collaborate because the project is 
                                        sufficiently ample. But we specially need:</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Programmers.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Documentation.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Testers.</font></p>
                                      <p align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Financial support.</font></p>
                                      <BR> </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <p align="right"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif"></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;</font></p></td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/02pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
