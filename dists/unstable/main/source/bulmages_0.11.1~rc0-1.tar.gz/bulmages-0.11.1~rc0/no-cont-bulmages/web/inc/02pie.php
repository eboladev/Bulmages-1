<table width="684" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
    <td align="right"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Questions, 
      suggestions or comments about the project?. Write to our <a href="links.php"> 
      mailing list.</a>. </font></td>
</tr>
</table>
