<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Estilo2 {color: #000000}
-->
</style>
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>
              <?php include("inc/01cabecera.php") ?>
              </strong></font> </td>
          </tr>
          <tr> 
            <td><table border="0" width="97%" align="center" cellpadding="0" cellspacing="0">
<tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/01menuizq.php")?>
                    </div></td>
                  <td><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                      <tr> 
                        <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                          </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td width="97%"><div align="right"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Col&middot;laboradors 
                                  del projecte BulmaG&eacute;s </font> </div></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table>
                    <BR> <table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
                      <tr> 
                        <td><div align="right"> 
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong> 
                              Cuna i mare del projecte</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                            </font><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><a href="http://bulmalug.net"><img src="img/bulma_small.jpg" width="250" height="44" border="0"></a></strong></font></p>						
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong> 
                              Programaci&oacute;</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                              </font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><span class="Estilo2">Tomeu
                              Borr&agrave;s</span></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> tborras 
                              en conetxia.com<br>
                              <span class="Estilo2">Toni Mirabete </span>amirabet 
                              en biada.org<br>
                              </font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><span class="Estilo2">Oscar Serna</span></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> oserna 
                              enregamallorca.com<br>
                              </font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><span class="Estilo2">Celso
                              Gonz&aacute;lez</span></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> mitago 
                              en ono.com<br>
                              <span class="Estilo2">Santiago Capel Torres</span> scapel 
                              en sierradigital.es<br>
                              <span class="Estilo2">Josep Burci�n</span> josep 
                              en burcion.com<br>
                              <span class="Estilo2">Jean Ren� M�rou<br>
                              Fco. Javier M.C.</span><BR>
                              <span class="Estilo2">Victor G. Marim�n</span></font></p>
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong> 
                              CVS</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                              Sourceforge <a href="http://www.sourceforge.net">http://www.sourceforge.net</a></font></p>
							  
							  
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Depuraci&oacute; 
                              i manuals</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                              <span class="Estilo2">Cristina Marco</span> cmarco 
                              enconetxia.com</font><BR>
                              <font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                              <span class="Estilo2">Alberto Caso</span> alberto.caso 
                              en adaptia.net</font><br>
							   <font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> <span class="Estilo2">Josep
							   Burci�n</span> josep 
                            en burcion.com</font>                            </p>							  
							  
                            <p><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                              <font color="#333333" size="2"><strong>WebMaster</strong></font><br>
                              <span class="Estilo2">Cristina Marco</span> cmarco 
                              en conetxia.com</font></p>
							  
                            <p><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                              <font color="#333333" size="2"><strong>Traducci&oacute; 
                              al catal&agrave;</strong></font><br>
                              (web y manual) <span class="Estilo2">Josep Antoni
                              Ruiz</span> josep
                               en eivissaweb.net</font><br>
							   <font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif">(programa)<span class="Estilo2">							   Antoni Villalonga i Noceras</span> webmaster
                               en friki.org </font></p>
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Llista
                                  de Correu</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                              <span class="Estilo2">Tomeu Borr&agrave;s</span> tborras
                               en conetxia.com<BR>
                              <span class="Estilo2">Xisco Llad� </span>xisco 
                            en bulma.net</font></p>
							  
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Domini
                                   bulmages.bulma.net</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                              <span class="Estilo2">Xisco Llad�</span> xisco 
                              en bulma.net</font></p>							  
							  
                            <p><font color="#333333" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong><font size="2">Assessorament</font></strong></font><font color="#666666" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                                <span class="Estilo2">Antoni</span> Aloy aloy 
                              en ctv.es <br>
                              <span class="Estilo2">M&ordf; Dolores Hern&aacute;ndez</span> mdhernandez 
                              en conetxia.com<br>
                              <span class="Estilo2">Fco. Javier MC</span> </font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"> fcojavmc
                               en todo-redes.com
                              </font></p>
                            <p><font color="#333333" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong><font size="2">Libreries
                                     de terceres persones</font></strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                              Proyecto Tora<br>
                              QMC:Widgets<br>
                              <a href="http://reports.sourceforge.net/">Proyecte
                               Reports</a></font></p>
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Idea,
                                   logotip i nom</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                            Benjam&iacute; Villoslada</font></p>
							  
							  
                            <p><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Antics
                                   Col&middot;laboradors</strong></font><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif"><BR>
                            Daniel Rodr�guez</font></p>							  
							  
                          </div></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/01pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
