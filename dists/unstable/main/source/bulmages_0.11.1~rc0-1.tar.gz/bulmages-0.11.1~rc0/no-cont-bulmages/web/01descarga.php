<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/01cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/01menuizq.php")?>
                    </div></td>
                  <td width="71%"> <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tr> 
                                    <td width="3%">&nbsp;</td>
                                    <td width="97%"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Instruccions 
                                      d'Instal&middot;laci&oacute; </font> </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="1" align="center" cellpadding="3" cellspacing="0" bordercolor="#999999">
                            <tr> 
                              <td height="94"><div align="justify"> 
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="descarga/installbulmages_0_3_7.tgz"><font color="#999999" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Descarregar 
                                    l'executable de BulmaGes 0.3.7</strong></font></a> 
                                    (<a href="descarga/installbulmages_0_3_7.tgz">aqui</a>) 
                                    </font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Per 
                                    al correcte funcionament del programa, deu 
                                    tenir instal&middot;lat el motor de bases 
                                    de dades postgresql i les llibreries qt-mt 
                                    i les llibreries lpq (d'acc&eacute;s a postgres).</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Descomprimir 
                                    l'arxiu tgz en un directori.</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Executar 
                                    com root el script d'instal&middot;laci&oacute;: 
                                    installbulmages.</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Assegurar-se 
                                    que el directori /usr/local/bin es troba en 
                                    el path. Per a arrencar el programa n'hi ha 
                                    prou amb escriure bulmages en la l&iacute;nia 
                                    de comando.</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Nota1</strong>: 
                                    Revisi el manual del programa per a assegurar-se 
                                    que t&eacute; b&eacute; configurat el motor 
                                    de bases de dades.</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Nota2</strong>: 
                                    Actualment no est&agrave; contemplada la compatibilitat 
                                    de bases de dades entre versions. Si ja t&eacute; 
                                    una versi&oacute; de Bulmag&eacute;s amb dades 
                                    de valor per a V&egrave;. no instal&middot;li 
                                    una nova versi&oacute; sense consultar pr&egrave;viament 
                                    en la llista de distribuci&oacute; sobre com 
                                    migrar d'una versi&oacute; a una altra.</font></p>
                                </div></td>
                            </tr>
                          </table></td>
                      </tr>
                      <tr> 
                        <td>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tr> 
                                    <td width="3%">&nbsp;</td>
                                    <td width="97%"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Sources 
                                      del programa</font></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <br> <table width="97%" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#999999">
                            <tr> 
                              <td height="24"><div align="justify"> 
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Existeix 
                                    un CVS amb el codi font del programa:</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>cvs 
                                    -d:pserver:anonymous@cvs.sourceforge.net:/cvsroot/bulmages 
                                    login <br>
                                    <br>
                                    cvs -z3 -d:pserver:anonymous@cvs.sourceforge.net:/cvsroot/bulmages 
                                    co bulmages</strong></font></p>
                                  <p></p>
                                  <p></p>
                                </div></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p></td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/01pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
