<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> 
              <?php include("inc/01cabecera.php") ?>
            </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/01menuizq.php")?>
                    </div></td>
                  <td width="66%"><table width="506" height="498" border="0" cellpadding="0" cellspacing="0">
<tr> 
                        <td height="19">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Vols 
                                col&middot;laborar?</strong></font></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">BulmaGes 
                                        com projecte 100% GPL es nodreix principalment 
                                        de col&middot;laboracions.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                        primer i &uacute;nic, pas per a col&middot;laborar 
                                        en el projecte &eacute;s donar-se d'alta 
                                        en la llista de distribuci&oacute;, d'aquesta 
                                        forma estar&agrave;s en contacte amb tots 
                                        els membres de BulmaGes. A partir de aqui, 
                                        la distribuci&oacute; de tasques &eacute;s 
                                        completament volunt&agrave;ria.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Aix&ograve; 
                                        si, recorda que &eacute;s m&eacute;s perjudicial 
                                        dir que vas a fer alguna cosa i no fer-ho, 
                                        que no dir gens. Pensa'l b&eacute; abans 
                                        de comprometre't.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Qualsevol 
                                        pot col&middot;laborar, ja que el projecte 
                                        &eacute;s suficientment &aacute;mplio. 
                                        El que m&eacute;s precisem s&oacute;n:</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Programadors.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Documentadores.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Testeadores.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Financiadores.</font></p>
                                      <BR> </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <p align="right"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif"></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;</font></p></td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/01pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
