<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<style type="text/css">
<!--
a {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #000000;
	text-decoration: none;
}

a:hover {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #663333;
	text-decoration: none;
}

-->
</style>

</head>
<body bgcolor="#cdd5d8">

<?php include("inc/cabecera.php") ?>
 <table width="684" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr valign="top"> 
          <td width="15%"><div align="right"><img name="home_r3_c2" src="img/cabecera/borde.gif" width="22" height="498" border="0" alt=""></div></td>
          <td width="18%"><?php include("inc/menuizq.php")?></td>
          <td width="66%"><table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
              <tr> 
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td height="40"><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                    <tr> 
                      <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                        </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr> 
                            <td width="4%" height="19">&nbsp;</td>
                            <td width="96%"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Manual 
                              Bulmages</font> - <font color="#333333" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="manual.php">&Iacute;ndice 
                              de Contenidos</a></font></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table>
				  
                </td>
              </tr>
              <tr> 
                <td height="440"><table width="97%" height="100%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999">
                    <tr> 
                      <td height="43"><?php include("manualindex.php") ?></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          <td width="1%"><img name="home_r3_c5" src="img/cabecera/home_r3_c5.gif" width="24" height="498" border="0" alt=""></td>
        </tr>
      </table></td>
  </tr>
  </table>
<?php include("inc/pie.php") ?>
  
</body>
</html>
