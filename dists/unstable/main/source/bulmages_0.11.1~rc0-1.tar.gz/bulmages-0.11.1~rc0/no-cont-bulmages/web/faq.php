<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>
              <?php include("inc/cabecera.php") ?>
              </strong></font> </td>
          </tr>
          <tr> 
            <td><table border="0" width="97%" align="center" cellpadding="0" cellspacing="0">
<tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td>
                    <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td height="19">
						
				  <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;BulmaG&eacute;s 
                                FAQ (Preguntas m&aacute;s Frecuentes)</strong></font></td>
                            </tr>
                          </table>
						
						</td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Inauguramos 
                                        esta nueva secci&oacute;in en la web para 
                                        intentar resolver las dudas y problemas 
                                        que m&aacute;s se repiten en el entorno 
                                        de BulmaG&eacute;s. Si no encuentras la 
                                        respuesta que buscabas, escr&iacute;benos 
                                        a la <a href="http://bulmages.bulma.net/mailman/listinfo/bulmages_bulmages.bulma.net" target="_blank">lista</a> 
                                        del proyecto o a cualquiera de los <a href="colaboradores.php">colaboradores</a>.</font></p>
                                      </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><a href="faqgen.php"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Preguntas 
                                Generales sobre BulmaG&eacute;s</strong></font></a></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="9%"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td width="91%"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Qu&eacute; 
                                            es BulmaG&eacute;s? </font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Qui&eacute;n 
                                            hace BulmaG&eacute;s?</font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Puedo 
                                            utilizar ya el programa?</font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Cu&aacute;nto 
                                            falta para que est&eacute; terminado?</font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;D&oacute;nde 
                                            puedo conseguir m&aacute;s informaci&oacute;n?</font></td>
                                        </tr>
                                      </table>
                                      
                                    </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><a href="faqgen.php"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Preguntas 
                                sobre la descarga de BulmaG&eacute;s</strong></font></a></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="9%"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td width="91%">&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                      </table></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><a href="faqgen.php"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Preguntas 
                                sobre la instalaci&oacute;n de BulmaG&eacute;s</strong></font></a></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="9%"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td width="91%"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Qu&eacute; 
                                            necesito para instalar BulmaG&eacute;s?</font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                      </table></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><a href="faqgen.php"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Preguntas 
                                sobre el funcionamiento BulmaG&eacute;s</strong></font></a></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="9%"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td width="91%">&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                      </table></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><a href="faqgen.php"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Otras 
                                Preguntas </strong></font></a></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td>&nbsp;</td>
                            </tr>
                          </table>
                          <p align="right">&nbsp;</p></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
