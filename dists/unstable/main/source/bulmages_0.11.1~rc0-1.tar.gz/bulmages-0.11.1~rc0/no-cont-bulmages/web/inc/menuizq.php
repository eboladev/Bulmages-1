<table width="98%" height="498" border="0" cellspacing="1" cellpadding="0" valigh="top">
  <tr> 
    <td valign="top"><div align="center">
        <table width="98%" border=0 cellspacing=0 cellpadding=0>
          <tr> 
            <td colspan="2" class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Concurso</font></strong></div></td>
          </tr>
          <tr> 
		  	<td class="tdmensaje"><a href="http://www.solico.tk"><img src="img/slsol00.gif" border="0"></a></td>
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">BulmaG&eacute;s 
                  ha ganado el concurso SOLICO. Premio concedido por su gran calidad 
                  a pesar de no encajar bien en las bases del concurso. ENHORABUENA 
                  !!!!!! </font></p>
                <p align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                  <a href="http://www.cps.unizar.es/%7Eisf/html/031124.html" target="_blank">[resoluci&oacute;n]</a> 
                  <br>
                  <a href="http://www.solico.tk" target="_blank">[web 
                  solico]</a></font></p>
              </div></td>
          </tr>
        </table>
        <BR>
        <table width="98%" border=0 cellspacing=0 cellpadding=0>
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">Noticias</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Se ha mejorado el sistema de informes mediante el proyecto RTK (Reports ToolKit) de Santiago Capel.</font></p>
                <p align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://reports.sourceforge.net">[RTK]</a> 
                  </font></p>
              </div></td>
          </tr>
        </table>	
        <BR>
        <table width="98%" border=0 cellspacing=0 cellpadding=0>
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">Noticias</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ya 
                  puedes consultar la Explicaci&oacute;n de los diagramas de Base 
                  de Datos (DER).</font></p>
                <p align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://bulmages.bulma.net/erm/">[DER]</a> 
                  </font></p>
              </div></td>
          </tr>
        </table>
        <br>
        <table border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Configuraci&oacute;n</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                  archivo /etc/bulmages.conf contiene muchos parametros de configuraci&oacute;n, 
                  en el se puede establecer el servidor que aloja la base de datos 
                  que va a utilizar el programa..</font></p>
                </div></td>
          </tr>
        </table>
		
		<BR>
        <table border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Configuraci&oacute;n</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Los 
                  listados en formato HTML tienen una hoja de estilos asiciada, 
                  mediante la que se puede cambiar la apariencia del listado. 
                  Las hojas de ejemplo se encuentran en /usr/share/bulmages/css 
                  </font></p>
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
