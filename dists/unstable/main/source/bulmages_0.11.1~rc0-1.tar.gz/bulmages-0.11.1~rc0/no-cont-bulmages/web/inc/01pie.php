<table width="684" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
    <td align="right"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Preguntes, 
      suggeriments o comentaris sobre el projecte?. Escrigui a la nostra <a href="links.php"> 
      llista de distribuci�</a>. </font></td>
</tr>
</table>
