<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td height="53" bgcolor="#FFFFFF"> <table width="100%" border="0" cellpadding="3" cellspacing="0" dwcopytype="CopyTableRow">
                      <tr> 
                        <td><font color="#FF9966" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Sobre BulmaG&eacute;s</strong></font></td>
                      </tr>
                      <tr> 
                        <td><a href="http://llistes.bulma.net/mailman/listinfo/bulmages" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Lista 
                          de ditribuci&oacute;n de BulmaG&eacute;s</font></a></td>
                      </tr>
                      <tr> 
                        <td><a href="http://bulmalug.net/" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Bulma: 
                          Biso&ntilde;os Usuarios de Linux de Mallorca y Alrededores 
                          </font></a></td>
                      </tr>
                      <tr>
                        <td><a href="http://www.burcion.com/bulmages.htm" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">P&aacute;gina de Josep Burci&oacute;n </FONT></a></td>
                      </tr>
                      <tr>
                        <td><a href="http://www.iglues.org" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Asociaci�n Iglues.</FONT></a></td>
                      </tr>		      
		      
                      <tr> 
                        <td><font color="#FF9966" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Proyectos 
                          Relacionados: </strong></font></td>
                      </tr>
                      <tr> 
                        <td><a href="http://www.fisterra.org" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Fisterra</font></a></td>
                      </tr>
                      <tr> 
                        <td><a href="http://www.facturalux.org" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Facturalux</font></a></td>
                      </tr>
                      <tr> 
                        <td><a href="http://www.josepmguasch.net/guco/guco.html" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">GUCO</font></a></td>
                      </tr>
                      <tr> 
                        <td><a href="http://fact.aspl.es/bugs.html" target="_blank"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">ASPL-Fact</font></a></td>
                      </tr>
                      <tr> 
                        <td><a href="http://gestiong.sourceforge.net"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">GestiONG</font></a></td>
                      </tr>
                    </table>
					
                  </td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
