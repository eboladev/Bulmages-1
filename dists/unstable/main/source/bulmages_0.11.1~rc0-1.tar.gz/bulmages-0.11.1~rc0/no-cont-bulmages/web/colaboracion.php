<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td width="66%"><table width="506" height="498" border="0" cellpadding="0" cellspacing="0">
<tr> 
                        <td height="19">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;&iquest;Quieres 
                                colaborar ?</strong></font></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">BulmaGes 
                                        como proyecto 100% GPL se nutre principalmente 
                                        de colaboraciones.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                        primer y &uacute;nico, paso para colaborar 
                                        en el proyecto es darse de alta en la 
                                        <a href="links.php">lista de distribuci&oacute;n</a>, 
                                        de esta forma estar&aacute;s en contacto 
                                        con todos los miembros de BulmaGes. A 
                                        partir de aqui, la distribuci&oacute;n 
                                        de tareas es completamente voluntaria.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Eso 
                                        s&iacute;, recuerda que es m&aacute;s 
                                        perjudicial decir que vas a hacer algo 
                                        y no hacerlo, que no decir nada. Pi&eacute;nsalo 
                                        bien antes de comprometerte.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cualquiera 
                                        puede colaborar, ya que el proyecto es 
                                        suficientemente &aacute;mplio, lo que 
                                        m&aacute;s precisamos son:</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Programadores.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Documentadores.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Testeadores.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                        Financiadores.</font></p>
                                      <BR> </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <p align="right"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif"></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;</font></p></td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
