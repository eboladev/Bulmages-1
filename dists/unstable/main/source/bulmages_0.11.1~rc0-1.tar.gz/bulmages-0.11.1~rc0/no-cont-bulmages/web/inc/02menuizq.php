<table width="98%" height="498" border="0" cellspacing="1" cellpadding="0" valigh="top">
  <tr> 
    <td valign="top"><div align="center">
        <table width="98%" border=0 cellspacing=0 cellpadding=0>
          <tr> 
            <td colspan="2" class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Award</font></strong></div></td>
          </tr>
          <tr> 
		  	<td class="tdmensaje"><a href="http://www.solico.tk"><img src="img/slsol00.gif" border="0"></a></td>
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">BulmaGes 
                  has been awarded with the SOLICO award. This Prize was granted 
                  by its great quality in spite of not fitting well in the bases 
                  of the award.</font></p>
                <p align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.solico.tk">[more 
                  info]</a> </font></p>
              </div></td>
          </tr>
        </table>
        <BR>
        <table width="98%" border=0 cellspacing=0 cellpadding=0>
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">News</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Now 
                  you can consult the Entity Relationship Diagram (ERD).</font></p>
                <p align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://bulmages.bulma.net/erm/">[consult]</a> 
                  </font></p>
              </div></td>
          </tr>
        </table>
        <br>
        <table border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Configuration</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">File 
                  /etc/bulmages.conf contains many configuration parameters, in 
                  it you can set the server who holds the data base that the program 
                  is going to use.</font></p>
                </div></td>
          </tr>
        </table>
		
		<BR>
        <table border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Configuration</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Listings 
                  in HTML format have an associatedstyle sheet. Here you can change 
                  the listings appearanc. The example sheets are in /usr/share/bulmages/css</font></p>
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
