<table width="684" border="0" align="center" cellpadding="0" cellspacing="0">
<tr><td>
<table width="684" border="0" cellspacing="0" cellpadding="0" align="center">        <tr> 
          <td width="29%"> 
<div align="center">
<br>
 <img src="img/xutp.png"></div></td>
          <td width="71%"> 
            <div align="center">
              <table width="30%" border="0" align="right" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="38%"><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="index.php">castellano</a></font></div></td>
                  <td width="28%"><div align="center"><a href="01index.php"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">catal&agrave;</font></a></div></td>
                  <td width="26%"><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="02index.php">english</a></font></div></td>
                  <td width="8%">&nbsp;</td>
                </tr>
              </table>
              <br>
			  <table width="470" height="117" border="0" align="right" cellpadding="10" cellspacing="1" bordercolor="#000000" bgcolor="#CCCCCC" class="tablacabecera">
                <tr> 
                  <td width="138" height="12" valign="middle" background="/web/descarga.php"> 
                    <div align="center"> </div></td>
                  <td width="289" valign="top" background="/web/descarga.php"><font size="+3" face="Arial, Helvetica, sans-serif">Projecte 
                    BulmaG&eacute;s</font><br> <br> <br> <font size="+1" face="Arial, Helvetica, sans-serif">comptabilitat 
                    per a Linux</font></td>
                </tr>
              </table>
</div></td>
        </tr>
      </table>
</td></tr>
<!--
  <tr> 
    <td valign="bottom"><img name="home_r1_c1" src="img/cabecera/cabecera.gif" width="684" height="124" border="0" alt=""></td></tr>

	  <tr><td><img src="img/cabecera/cabecera2.gif" alt="" name="cabecera2" border="0" usemap="#cabecera2Map"></td>
</tr>
-->

<tr><td>
<br>
<table width="684" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td width="29%"> 
<div align="center"> 
              <table class="tablacabecera">
<tr>
                  <td> <div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">[<a href="01colaboradores.php">col�laboradors</a>]</font></div></td>
                </tr>
              </table>
</div></td>
          <td width="71%"> 
            <div align="center"> 
              <table width="500" align="right" class="tablacabecera">
<tr>
                  <td width="500" height="14"> 
<div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="01index.php">[home]</a><a href="01manual.php"> 
                      [documentaci&oacute;]</a> [<a href="01articulos.php">articles</a>] 
                      <a href="01screenindex.php"> [screenshots]</a> <a href="01colaboracion.php">[col&middot;laboraci&oacute; 
                      ]</a> [<a href="01descarga.php">download</a>] [<a href="01links.php">links</a>] 
                      </font></div></td>
                </tr>
              </table>
</div></td>
        </tr>
      </table>
</td></tr>
</table>

<!--
<map name="cabecera2Map">
<area shape="rect" coords="315,5,395,19" href="presentacion.php">
<area shape="rect" coords="252,6,295,18" href="index.php">
<area shape="rect" coords="604,6,639,19" href="links.php">
<area shape="rect" coords="512,5,580,19" href="descarga.php">
<area shape="rect" coords="49,4,130,18" href="colaboradores.php">
<area shape="rect" coords="412,5,493,20" href="colaboracion.php">
</map>
-->