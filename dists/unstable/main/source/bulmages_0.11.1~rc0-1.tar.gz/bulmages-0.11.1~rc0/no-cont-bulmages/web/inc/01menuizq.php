 
<p></p>
<table width="98%" height="498" border="0" cellspacing="1" cellpadding="0" valigh="top">
  <tr> 
    <td valign="top"><div align="center">
        <table width="98%" border=0 cellspacing=0 cellpadding=0>
          <tr> 
            <td colspan="2" class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Concurs</font></strong></div></td>
          </tr>
          <tr> 
		  	<td class="tdmensaje"><a href="http://www.solico.tk"><img src="img/slsol00.gif" border="0"></a></td>
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">BulmaG&eacute;s 
                  ha guanyat el concurs SOLICO. Premi concedit per la seva gran 
                  qualitat a pesar de no encaixar b&eacute; en les bases del concurs. 
                  ENHORABONA !!!!!!</font></p>
                <p align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.solico.tk">[mes 
                  info]</a> </font></p>
              </div></td>
          </tr>
        </table>
        <BR>
        <table width="98%" border=0 cellspacing=0 cellpadding=0>
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">Not&iacute;cia</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ja 
                  pots consultar l'Explicaci&oacute; dels diagrames de Base de 
                  Dades (DER). </font></p>
                <p align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://bulmages.bulma.net/erm/">[(DER)]</a> 
                  </font></p>
              </div></td>
          </tr>
        </table>
        <br>
        <table border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Configuraci&oacute;</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">L'arxiu 
                  /etc/bulmages.conf cont&eacute; molts parametros de configuraci&oacute;, 
                  on pots establir el servidor que allotja la base de dades que 
                  va a utilitzar el programa.</font></p>
                </div></td>
          </tr>
        </table>
		
		<BR>
        <table border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td class="tdhead"> <div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Configuraci&oacute;</font></strong></div></td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" class="tdmensaje"> <div align="left"> 
                <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Els 
                  llistats en format HTML tenen una fulla d'estils asiciada, mitjan&ccedil;ant 
                  la qual es pot canviar l'aparen&ccedil;a del llistat. Les fulles 
                  d'exemple es troben en /usr/share/bulmages/css</font></p>
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
