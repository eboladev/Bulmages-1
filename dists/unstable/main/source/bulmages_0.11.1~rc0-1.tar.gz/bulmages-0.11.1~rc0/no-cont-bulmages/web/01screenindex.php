<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/01cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/01menuizq.php")?>
                    </div></td>
                  <td width="66%"><table width="506" height="498" border="0" cellpadding="0" cellspacing="0">
<tr> 
                        <td height="19">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Screenshots</strong></font></td>
                            </tr>
                          </table>
                          <BR>
						  <table width="90%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC" dwcopytype="CopyTableRow">
                              <tr>
                                <td>
								<br>
								<table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td>
									  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="60%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/mdi.png"><img src="img/splash/mdi.gif" width="86" height="72" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Aquesta 
                                              imatge presenta l'entorn de treball. 
                                              Mostra la introducci&oacute; d'apunts 
                                              el llibre diari, l'extracte i alguns 
                                              balan&ccedil;os. </font></div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" cellspacing="0" cellpadding="3">
                                          <tr> 
                                            <td width="72%" valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Captura 
                                              d'una gr&agrave;fica de moviments 
                                              per a la pantalla de seguiment de 
                                              comptes. Les biblioteques de generaci&oacute; 
                                              de gr&agrave;fics estan realitzades 
                                              pel <a href="http://www.globecom.se/tora/">projecte 
                                              Tora</a></font></div></td>
                                            <td width="3%">&nbsp;</td>
                                            <td width="25%"><div align="center"> 
                                                <table width="73%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/estadisticas.png"><img src="img/splash/estadisticas.gif" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                          </tr>
                                        </table> </td>
                                    </tr>
                                  </table>
								  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="23%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/mpatrimoniales.png"><img src="img/splash/mpatrimoniales.gif" width="100" height="69"  border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><BR>
                                              Exemple de Composici&oacute; de 
                                              masses patrimonials.</font></div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" cellspacing="0" cellpadding="3">
                                          <tr> 
                                            <td width="73%" valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                              Exemple de Composici&oacute; de 
                                              balan&ccedil;os. </font></div></td>
                                            <td width="1%">&nbsp;</td>
                                            <td width="26%"><div align="center"> 
                                                <table width="72%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/compbalance.png"><img src="img/splash/compbalance.gif" width="100" height="51" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
								  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="77%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/librodiario.png"><img src="img/splash/librodiario.gif" width="100" height="75" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Aquesta 
                                              imatge mostra el diari en manera 
                                              aprenentatge i format HTML, creat 
                                              per Toni Mirabete.</font></div></td>

                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
                                  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" cellspacing="0" cellpadding="3">
                                          <tr> 
                                            <td width="70%" valign="middle"><div align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                              Vista del diari usant el projecte 
                                              Reports.</font></div></td>
                                            <td width="4%">&nbsp;</td>
                                            <td width="26%"><div align="center"> 
                                                <table width="71%" border="1" align="center" cellpadding="0" cellspacing="0">
                                                  <tr> 
                                                    <td><a href="img/librodiario1.png"><img src="img/splash/librodiario1.gif" width="100" height="71"  border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  <br>
								  <table width="95%" border="1" align="center" cellpadding="0" cellspacing="0">
                                    <tr> 
                                      <td><table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
                                          <tr> 
                                            <td><div align="center"> 
                                                <table width="80%" border="1" cellspacing="0" cellpadding="0">
                                                  <tr> 
                                                    <td><a href="img/splash.png"><img src="img/splash/splash.gif" width="100" height="80" border="0"></a></td>
                                                  </tr>
                                                </table>
                                              </div></td>
                                            <td>&nbsp;</td>
                                            <td valign="middle"><div align="justify">
                                              <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.fotonatura.org/galerias/foto.php?id_foto=27130&id_galeria=16">Splash 
                                                del programa per a la versi&oacute; 
                                                0.3.1 imatge cedida per </a></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.fotonatura.org/galerias/foto.php?id_foto=27130&id_galeria=16">Victor 
                                                Bas</a>.</font></p>
                                              </div></td>
                                          </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                  
                                </td>
                              </tr>
                            </table>
                          <p align="right"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif"></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;</font></p></td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/01pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
