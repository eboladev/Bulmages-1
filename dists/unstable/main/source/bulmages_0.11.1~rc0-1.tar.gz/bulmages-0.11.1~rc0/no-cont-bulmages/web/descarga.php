<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td width="71%"> <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tr> 
                                    <td width="3%">&nbsp;</td>
                                    <td width="97%"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Instrucciones 
                                      de Instalaci&oacute;n</font> </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="1" align="center" cellpadding="3" cellspacing="0" bordercolor="#999999">
                            <tr> 
                              <td height="94"><div align="justify"> 
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="descarga/installbulmages_0_4_1.tgz"><font color="#999999" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Descargar 
                                    el ejecutable de BulmaGes 0.4.1</strong></font></a> 
                                    (<a href="descarga/installbulmages_0_4_1.tgz">aqui</a>) 
                                    </font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Para 
                                    el correcto funcionamiento del programa, debe 
                                    tener instalado el motor de bases de datos 
                                    postgresql y las librerias qt-mt y las librerias 
                                    lpq (de acceso a postgres)</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Descomprimir 
                                    el archivo tgz en un directorio</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Ejecutar 
                                    como root el script de instalaci&oacute;n: 
                                    installbulmages</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Para 
                                    arrancar el programa basta con escribir bulmages 
                                    en la l&iacute;nea de comando.</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Nota1</strong>: 
                                    Revise el <a href="manualindex.php">manual</a> 
                                    del programa, para asegurarse de que tiene 
                                    bien configurado el motor de bases de datos.</font></p>
                                  <p>&nbsp;</p>
                                </div></td>
                            </tr>
                          </table></td>
                      </tr>
                      <tr> 
                        <td><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999" bgcolor="#CDD5D8">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tr> 
                                    <td width="3%">&nbsp;</td>
                                    <td width="97%"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Sources 
                                      del programa</font></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <br> <table width="97%" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#999999">
                            <tr> 
                              <td height="24"><div align="justify"> 
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Actualmente no se distribuye el c�digo fuente de cada liberaci�n. Siempre se puede obtener la �ltima versi�n a partir del CVS que usamos para trabajar:</font></p>
                                  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>cvs 
                                    -d:pserver:anonymous@cvs.sourceforge.net:/cvsroot/bulmages 
                                    login <br>
                                    <br>
                                    cvs -z3 -d:pserver:anonymous@cvs.sourceforge.net:/cvsroot/bulmages 
                                    co bulmages</strong></font></p>
                                  <p></p>
                                </div></td>
                            </tr>
                          </table>
                          <p>&nbsp;</p></td>
                      </tr>
                      <tr> 
                        <td>&nbsp;</td>
                      </tr>
                    </table></td>
                  <td width="0%">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
