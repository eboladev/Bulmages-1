<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>
              <?php include("inc/02cabecera.php") ?>
              </strong></font> </td>
          </tr>
          <tr> 
            <td><table border="0" width="97%" align="center" cellpadding="0" cellspacing="0">
<tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/02menuizq.php")?>
                    </div></td>
                  <td>
                    <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td height="19"><table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;Introducing&nbsp;BulmaG&eacute;s</strong></font></td>
                            </tr>
                          </table></td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">The 
                                        main target of BulmaG&eacute;s project 
                                        is to introduce the operating system GNU/Linux 
                                        in the enterprise scope.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">The 
                                        carried out reasoning is that all company 
                                        that tries to make a serious migration 
                                        towards the world of Free Software will 
                                        begin this migration by a department not 
                                        committed, with isolated aplications and 
                                        independent of the normal operation of 
                                        the company.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">The 
                                        best candidate than happens itself to 
                                        us is the accounting department, therefore 
                                        we centered all our efforts in offering 
                                        to the enterprise world, free, an accounting 
                                        program that satisfies the most demanding 
                                        accountants. A program with simple operating, 
                                        fast and effective and at the same time 
                                        that allows future interdepartmental integrations. 
                                        <br>
                                        <br>
                                        Under this frame and philosophy we launch 
                                        the accounting program BulmaG&eacute;s.</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;BulmaG&eacute;s 
                                0.3.7</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">The 
                                        last published version of BulmaG&eacute;s 
                                        is the 0.3.7.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">At 
                                        the moment BulmaGes has all the basic 
                                        functions of an accounting program and, 
                                        in this aspect, it'is 100% usable.</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <br><br>
                          <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;<font color="#990000">BulmaG&eacute;s 
                                Code Parties</font></strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">The 
                                        collaborators of the project organize 
                                        every week a BulmaG&eacute;s Code Party 
                                        and you are all guests. It will Sundaies 
                                        at about 4 or 5 in the afternoon.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">If 
                                        you want more information or to confirm 
                                        your attendance write to the project mailing 
                                        list. What are you waiting for?</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/02pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
