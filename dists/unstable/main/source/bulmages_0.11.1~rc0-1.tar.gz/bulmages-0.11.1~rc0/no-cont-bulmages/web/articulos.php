<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body bgcolor="#cdd5d8">
<div id="Layer1" style="position:absolute; left:396px; top:563px; width:421px; height:108px; z-index:1; visibility: hidden;">
  <p>contabilidad linux gestion libre gratis open source free software programa 
    descarga contabilidad plan contable espa&ntilde;ol general diario mayor balance 
    bulma download </p>
</div>
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td height="294" bgcolor="#FFFFFF"><table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                      <tr> 
                        <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;La 
                          importancia del Software Libre en el entorno educativo</strong></font></td>
                      </tr>
                    </table>
<table width="97%" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                      <tr> 
                        <td width="96%" height="1322"> 
<p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Actualmente, 
                            un proceso educativo que no incluya la docencia de 
                            conocimientos (aunque sean b&aacute;sicos) de inform&aacute;tica, 
                            es considerado deficiente.<br>
                            Si bien hasta hace muy pocos a&ntilde;os la inform&aacute;tica 
                            era una gran desconocida para la mayor parte de los 
                            mortales, en pocos a&ntilde;os se ha convertido en 
                            un requisito indispensable para la casi totalidad 
                            de los puestos de trabajo de oficina.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Hace 
                            apenas 10 a&ntilde;os, aprender conceptos b&aacute;sicos 
                            de inform&aacute;tica supon&iacute;a utilizar un m&eacute;todo 
                            autodidacta, apuntarse a una &quot;academia&quot; 
                            o especializarse mediante cursos de entidades privadas 
                            o p&uacute;blicas. Sin embargo, hoy en d&iacute;a, 
                            la mayor parte de los centros educativos (especialmente 
                            los de origen privado) disponen, al menos, de un aula 
                            de inform&aacute;tica donde los alumnos pueden familiarizarse 
                            con el ordenador (en una primera etapa y a trav&eacute;s 
                            de juegos) y aprender (m&aacute;s adelante), al menos, 
                            nociones b&aacute;sicas (especialmente sobre ofim&aacute;tica 
                            o el manejo de Internet como fuente de obtenci&oacute;n 
                            de recursos)</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Pero, 
                            incluso con este gran avance, la inserci&oacute;n 
                            en el plan de estudios de la utilizaci&oacute;n de 
                            ordenadores sigue siendo una tarea especialmente dif&iacute;cil 
                            de afrontar, principalmente por las tremendas inversiones 
                            de capital que supone la compra de equipos, la adquisici&oacute;n 
                            de software, las infraestructuras, los costes en telecomunicaciones, 
                            el soporte t&eacute;cnico y el mantenimiento y actualizaci&oacute;n 
                            del sistema.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Este 
                            gran problema, quiz&aacute;s el m&aacute;s importante, 
                            puede solucionarse m&aacute;s f&aacute;cilmente de 
                            lo que parece con la utilizaci&oacute;n de software 
                            libre. La gran ventaja es, evidentemente, la gratuidad 
                            del mismo. Cualquiera puede tener una copia obtenida 
                            de cualquier fuente, instalarla donde quiera, como 
                            quiera y cuando quiera y cederla a otros posibles 
                            usuarios sin ning&uacute;n coste para ambos.<br>
                            El coste de renovaciones y manuales tambi&eacute;n 
                            desaparece, as&iacute; como el coste del soporte t&eacute;cnico 
                            si se tienen en cuenta la infinidad de manuales y 
                            grupos que est&aacute;n disponibles especialmente 
                            en Internet y que no cobran por ofrecer su ayuda al 
                            usuario. Adem&aacute;s, el software libre tiene una 
                            licencia de uso gratuito para siempre, esto garantiza 
                            su uso libre sin ning&uacute;n riesgo legal.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Con 
                            la utilizaci&oacute;n del software libre tambi&eacute;n 
                            desaparecen los problemas econ&oacute;micos de la 
                            actualizaci&oacute;n y mejora del software, ya que 
                            todas las versiones posteriores y mejoradas del software 
                            que hayamos elegido son autom&aacute;ticamente puestas 
                            a disposici&oacute;n de todos los posibles usuarios. 
                            Sin ning&uacute;n coste monetario, por supuesto.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Por 
                            otro lado, y este punto es especialmente importante, 
                            la utilizaci&oacute;n de software libre permite que 
                            todas y cada una de las personas interesadas puedan 
                            modificar, ampliar y mejorar el software del que disponen. 
                            Esto no s&oacute;lo hace referencia al punto anterior 
                            (gracias al cual todos los usuarios se benefician) 
                            sino que, adem&aacute;s, permite que el software utilizado 
                            se adapte perfectamente a los requisitos del usuario. 
                            As&iacute;, no es necesario adquirir todo un paquete 
                            de programas si s&oacute;lo nos interesan una parte 
                            de ellos y cada uno de esos programas que vayamos 
                            a instalar es adaptable a lo que nosotros queremos 
                            que sea. Por ejemplo, podemos instalar un programa 
                            de contabilidad desarrollado en c&oacute;digo abierto 
                            y a&ntilde;adirle un peque&ntilde;o programa que corrija 
                            los errores de los alumnos y les explique qu&eacute; 
                            fallo han cometido al realizar ejercicios con &eacute;l. 
                            La &uacute;nica condici&oacute;n del software libre 
                            es que, as&iacute; como nosotros podemos beneficiarnos 
                            de todas las mejoras que otros usuarios han introducido 
                            al programa, tambi&eacute;n estamos obligados a hacer 
                            p&uacute;blicas, y gratuitas, todas las mejoras o 
                            modificaciones que nosotros realicemos.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">En 
                            cuesti&oacute;n de inversi&oacute;n en hardware el 
                            software libre tambi&eacute;n ofrece bastantes ventajas. 
                            Para comenzar, al estar desarrollado por multitud 
                            de usuarios que no comparten las mismas caracter&iacute;sticas 
                            t&eacute;cnicas, el software libre suele ser compatible 
                            con casi todos los componentes del mercado. Incluso 
                            con aquellos que programas o sistemas operativos actuales 
                            consideran obsoletos. Esto supone no estar invirtiendo 
                            continuamente en nuevo hardware.<br>
                            Por otro lado, &uacute;ltimamente en varios centros 
                            educativos, y con la ayuda de asociaciones de fomento 
                            del uso del software libre y particulares, se est&aacute; 
                            procediendo a la reconversi&oacute;n de equipos obsoletos 
                            que no son capaces de funcionar por s&iacute; mismos. 
                            El sistema consiste en instalar un servidor, como 
                            &uacute;nica inversi&oacute;n, que est&aacute; basado 
                            en sistemas operativos linux y conectar los otros 
                            ordenadores a este servidor de forma que utilicen 
                            sus recursos para funcionar. El usurario final, en 
                            este caso los alumnos, no notan ninguna diferencia, 
                            Y el ahorro que supone para el centro educativo es 
                            inestimable. (<a href="http://www.hispalinux.net/casos.html?id=24" target="_blank">http://www.hispalinux.net/casos.html?id=24</a> 
                            - HISPALINUX.NET)</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">A 
                            esto debemos a&ntilde;adirle que la educaci&oacute;n 
                            debe ser objetiva y parcial. La pregunta es la siguiente 
                            &iquest;queremos ense&ntilde;ar a los estudiantes 
                            el uso de la tecnolog&iacute;a o el uso de un solo 
                            programa? Utilizar un solo sistema operativo en la 
                            ense&ntilde;anza, por ejemplo, es como si les inculc&aacute;semos 
                            que para escribir s&oacute;lo valen unos bol&iacute;grafos 
                            de una marca determinada. Por este motivo, incluso 
                            aunque el centro se decante por la utilizaci&oacute;n 
                            de software con c&oacute;digo cerrado, tambi&eacute;n 
                            deber&iacute;a introducir el software libre, no s&oacute;lo 
                            para que los alumnos aprendan a usarlo aunque sea 
                            a un nivel b&aacute;sico, sino para que conozcan su 
                            existencia y puedan elegir entre las diferentes opciones 
                            que existen en el mercado. El software libre fomenta, 
                            principalmente, la libertad y la cooperaci&oacute;n 
                            como valores ineludibles, no se favorece a ninguna 
                            empresa y no fomenta las copias ilegales (pirater&iacute;a)</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Por 
                            &uacute;ltimo, imagine todo lo que se puede hacer 
                            con los millones de euros que se ahorrar&iacute;an 
                            anualmente en adquisici&oacute;n, mantenimiento y 
                            mejora del software en el &aacute;mbito educativo: 
                            mejores recursos en las aulas, m&aacute;s becas de 
                            estudios, m&aacute;s centros educativos, mejora de 
                            las instalaciones, aumento del profesorado y ense&ntilde;anzas 
                            personalizadas... &iquest;Merece o no merece la pena 
                            considerar esta opci&oacute;n?</font></p>
                          <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FF0000"><br>
                            M&aacute;s informaci&oacute;n:</font></strong></font></p>
                          <font color="#3399FF" size="1" face="Verdana, Arial, Helvetica, sans-serif">Proyecto 
                          GNU en las escuelas:</font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://gnu.mirror.widexs.nl/education/education.es.html" target="_blank"> 
                          http://gnu.mirror.widexs.nl/education/education.es.html</a><br>
                          <font color="#3399FF">Open Source Education Foundation 
                          Website: </font><a href="http://www.osef.org/" target="_blank">http://www.osef.org/</a><br>
                          <font color="#3399FF">OFSET (Organitation for Free Software 
                          in Eduaction and Teaching)</font> <a href="http://www.ofset.org/" target="_blank">http://www.ofset.org</a> 
                          <BR>
                          <font color="#3399FF">UNESCO Free Software Portal:</font></font> 
                          <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.unesco.org/webworld/portal_freesoft/" target="_blank">http://www.unesco.org/webworld/portal_freesoft/</a><BR>
                          <font color="#3399FF">HISPALINUX:</font></font> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.hispalinux.es" target="_blank">http://www.hispalinux.es</a><BR>
                          <font color="#3399FF">Open Source en la Educaci&oacute;n:</font></font> 
                          <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.geekvoice.com/articulo/otro/14/" target="_blank">http://www.geekvoice.com/articulo/otro/14/</a></font> 
                          <BR> <font color="#3399FF" size="1" face="Verdana, Arial, Helvetica, sans-serif">Grupo 
                          de Usuarios de Linux Escuela Normal de Zacatecas - Noticias 
                          en Educaci&oacute;n y Gobierno:</font> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://enmac.seul.org/noticias.html" target="_blank">http://enmac.seul.org/noticias.html</a></font>
                          <p></p>
                          <p></p>
                          <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cristina 
                            Marco - Agosto 2003 <br>
                            cmarco(arroba)conetxia.com <br>
                            Puede reproducir esta noticia sin necesidad de pedir 
                            autorizaci&oacute;n para ello siempre y cuando cite 
                            a la fuente y a la autora y notifique dicha reproducci&oacute;n.</font> 
                          </p></td>
                      </tr>
                    </table>
<br>
                    <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                      <tr> 
                        <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Por 
                          qu&eacute; y c&oacute;mo migrar hacia Linux</strong></font></td>
                      </tr>
                    </table>
                    <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                      <tr> 
                        <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                          </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                  En los &uacute;ltimos a&ntilde;os el software 
                                  libre ha adquirido una importancia relevante 
                                  en el mundo de la inform&aacute;tica. Contra 
                                  todo pron&oacute;stico, la comunidad del software 
                                  libre crece d&iacute;a a d&iacute;a poniendo 
                                  a disposici&oacute;n de todo el mundo gran variedad 
                                  de problemas resueltos de forma excelente.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cada 
                                  d&iacute;a vemos c&oacute;mo el software libre 
                                  rompe el modelo del software propietario haciendo 
                                  que muchas empresas hayan perdido cuota de mercado 
                                  en &aacute;reas como el sector de servidores, 
                                  bases de datos, sistemas de alto rendimiento 
                                  y un largo etc&eacute;tera de &aacute;reas donde 
                                  la inform&aacute;tica es imprescindible.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&iquest;Cu&aacute;les 
                                  son las ventajas del software libre?</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  Mayor independencia: Normalmente, la elecci&oacute;n 
                                  de un programa propietario implica una fuerte 
                                  dependencia de una empresa externa, cuyos objetivos 
                                  no son los mismos que los de su empresa.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Si 
                                  Vd. elige cualquier programa comercial, no s&oacute;lo 
                                  habr&aacute; comprado el derecho de uso del 
                                  programa. Tambi&eacute;n estar&aacute; expuesto 
                                  a los caprichos de la empresa que ha realizado 
                                  dicho programa. Es decir, es como si Vd. pudiera 
                                  coger a sus clientes, obligarles a adquirir 
                                  las &uacute;ltimas versiones de sus productos 
                                  alegando incompatibilidades con versiones anteriores, 
                                  cobrarles las correcciones de los fallos cometidos 
                                  como caracter&iacute;sticas nuevas, o incluso 
                                  estropear partes que funcionan correctamente 
                                  para luego poder revenderlas como novedades, 
                                  obligarles a trabajar para usted como testadores 
                                  de su producto, etc &iquest;Lo har&iacute;a?, 
                                  &iquest;Har&iacute;a algo para solucionar este 
                                  circulo vicioso que le resulta tan beneficioso?</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Si 
                                  Vd. elige un sistema hecho a medida para su 
                                  empresa ha adquirido la obligaci&oacute;n de 
                                  trabajar con determinada empresa a muy largo 
                                  plazo. Durante un largo periodo de tiempo su 
                                  software no estar&aacute; integrado completamente 
                                  con su empresa y aun cuando consiga dicha meta 
                                  tendr&aacute; todas unas tareas de mantenimiento 
                                  que afrontar para su programa. Una pregunta 
                                  al respecto: Si Usted paga por el desarrollo 
                                  de un programa, &iquest;Por qu&eacute; luego 
                                  no obtiene todo lo necesario para reconstruir 
                                  dicho programa? &iquest;Por qu&eacute;, suponiendo 
                                  que Vd. entiende de inform&aacute;tica, no puede 
                                  modificarlo a su antojo sin tener que pagar 
                                  un nuevo desarrollo a la empresa que le hizo 
                                  el desarrollo inicial? &iquest;Tiene Vd la certeza 
                                  de que lo que ha pagado no ser&aacute; luego 
                                  revendido a sus competidores, incluso a menor 
                                  costo del que le costo a Vd?.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  software libre pretende evitar todos estos problemas 
                                  al desvincular la propiedad del software realizado 
                                  con cualquier empresa. Esto significa que todo 
                                  el mundo tiene acceso al c&oacute;digo fuente 
                                  del programa y, adem&aacute;s, puede modificarlo 
                                  e introducir mejoras y nuevas caracter&iacute;sticas 
                                  de las que Vd. se puede beneficiar a largo plazo.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Y 
                                  esto a m&iacute; en qu&eacute; me beneficia 
                                  y en qu&eacute; me perjudica</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Los 
                                  beneficios de esta estrategia de desarrollo 
                                  de software son principalmente dos:</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  Vd. obtiene software con muchos menos compromisos 
                                  que las versiones propietarias. Esto se traduce 
                                  en una menor exposici&oacute;n.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  Vd. puede beneficiarse del trabajo de los dem&aacute;s.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Las 
                                  desventajas son las siguientes</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  Sus competidores pueden beneficiarse de su trabajo.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Y 
                                  qui&eacute;n m&aacute;s se beneficia del software 
                                  libre</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  software libre no s&oacute;lo le beneficia a 
                                  Vd. tambi&eacute;n beneficia a todos los inform&aacute;ticos 
                                  del mundo. (No confunda el termino inform&aacute;ticos 
                                  con el termino empresas de inform&aacute;tica. 
                                  No es lo mismo) El software propietario, normalmente, 
                                  no beneficia a sus creadores. Estos suelen ser 
                                  personas contratadas, sin derechos sobre su 
                                  admirable trabajo. Preg&uacute;ntese c&oacute;mo 
                                  es posible que el manual de un programa cueste 
                                  m&aacute;s que el propio programa, cuando los 
                                  costes del programa son infinitamente superiores 
                                  a los de la elaboraci&oacute;n del manual. &iquest;Se 
                                  ha preguntado como es posible que conozca el 
                                  nombre de los autores de su libro favorito, 
                                  y no conozca a los realizadores de aquellos 
                                  programas que usa a diario?</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  software libre ofrece muchas m&aacute;s oportunidades 
                                  a los propios programadores, que pueden cobrar 
                                  por su programaci&oacute;n sin tener que preocuparse 
                                  por temas como canales de distribuci&oacute;n, 
                                  niveles de ventas, o an&aacute;lisis de costes. 
                                  De esta forma un programador puede dedicarse 
                                  a aquello que realmente le interesa, cobrar 
                                  por sus servicios y, al mismo tiempo, ayudar 
                                  al resto del mundo.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  modelo supone que los programadores deben actuar 
                                  en comunidad para la realizaci&oacute;n del 
                                  software y luego cobrar por las tareas especificas 
                                  que dicho software implica en cada empresa.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>D&oacute;nde 
                                  usar software libre</strong></font></p>
                                <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Los 
                                  pros y contras del software libre est&aacute;n 
                                  sobre la mesa, ahora falta decidir si usar software 
                                  libre o no y d&oacute;nde es mejor usarlo y 
                                  d&oacute;nde no.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Una 
                                  de las mejores &aacute;reas de aplicaci&oacute;n 
                                  del software libre, y donde obtendr&aacute; 
                                  todas las ventanas de &eacute;ste y ning&uacute;n 
                                  inconveniente es en los sectores comunes. Programas 
                                  que no alteran el funcionamiento de la empresa, 
                                  que resuelven tareas cuotidianas y no estructuran 
                                  para nada su empresa. Por ejemplo: lectores 
                                  de correo electr&oacute;nico, navegadores, procesadores 
                                  de texto, hojas de calculo, etc. Existen gran 
                                  variedad de productos de igual o superior nivel 
                                  que los costosos programas comerciales, con 
                                  menos problemas de compatibilidades y con un 
                                  soporte estupendo. </font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Otra 
                                  &aacute;rea de aplicaci&oacute;n es en los programas 
                                  de uso de la empresa, no tan cotidianos como 
                                  los anteriores, pero si de uso por un gran numero 
                                  de empresas, o por todas las empresas de un 
                                  determinado sector, contabilidad, facturaci&oacute;n, 
                                  control de stock, etc. Bulmag&eacute;s se encuentra 
                                  dentro de esta &aacute;rea.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>D&oacute;nde 
                                  no es conveniente usar software libre:</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Existen 
                                  problemas espec&iacute;ficos de su empresa. 
                                  Normalmente no encontrar&aacute; programas comerciales 
                                  que den respuesta a estos problemas, son programas 
                                  de gran valor para Vd. ya que de ellos depende 
                                  el buen funcionamiento de la empresa. Normalmente 
                                  Vd. no precisar&aacute; programas de este nivel, 
                                  pero si es su caso act&uacute;e de la siguiente 
                                  manera para no quedar petrificado. Exija el 
                                  c&oacute;digo fuente de los programas que se 
                                  realicen para Vd. No es necesario que lo distribuya, 
                                  pero obligue a que dicho c&oacute;digo no sea 
                                  distribido. No exponga el coraz&oacute;n de 
                                  su empresa. Si es preciso ases&oacute;rese por 
                                  terceros para que se defiendan los intereses 
                                  de su empresa y no los de otros.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Pero, 
                                  atenci&oacute;n, esto no significa que no pueda 
                                  aprovechar las herramientas de software libre 
                                  para la realizaci&oacute;n de este programa. 
                                  Vd. puede realizar, y utilizar dicho programa 
                                  utilizando todo el software libre que necesite 
                                  sin incurrir en ning&uacute;n delito.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">La 
                                  &uacute;nica condici&oacute;n es que no podr&aacute; 
                                  distribuir este software a nadie m&aacute;s 
                                  que no sea Vd. Cosa que, por otra parte, no 
                                  le interesa ya que el programa &uacute;nicamente 
                                  resuelve los problemas de su empresa y la distribuci&oacute;n 
                                  de dicho software ser&iacute;a un error estrat&eacute;gico 
                                  para Vd.</font></p></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table>
                    <br>
                    <br>
                    <p align="center"> <a href="http://bulmalug.net"><img src="img/bulma_small.jpg" width="250" height="44" border="0"></a></p>
</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
