<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>
              <?php include("inc/01cabecera.php") ?>
              </strong></font> </td>
          </tr>
          <tr> 
            <td><table border="0" width="97%" align="center" cellpadding="0" cellspacing="0">
<tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/01menuizq.php")?>
                    </div></td>
                  <td>
                    <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td height="19"><table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;BulmaG&eacute;s 
                                Presentaci&oacute;</strong></font></td>
                            </tr>
                          </table></td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"><table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">L'objectiu 
                                        fonamental del projecte BulmaG&eacute;s 
                                        &eacute;s introduir el sistema operatiu 
                                        GNU/Linux en l'&agrave;mbit empresarial.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                        raonament portat a terme &eacute;s que 
                                        tot empresa que pretengui realitzar una 
                                        migraci&oacute; seriosa cap al m&oacute;n 
                                        del Programari Lliure comen&ccedil;ar&agrave; 
                                        aquesta migraci&oacute; per un departament 
                                        poc comprom&egrave;s, amb aplicacions 
                                        aillades i independents del normal funcionament 
                                        de l'empresa.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                        millor candidat que se'ns ocorre &eacute;s 
                                        el departament comptable, per tant centrem 
                                        tots els nostres esfor&ccedil;os a oferir 
                                        al m&oacute;n empresarial, de forma gratu&iuml;ta, 
                                        un programa de Comptabilitat que satisfaci 
                                        als comptables m&eacute;s exigents, que 
                                        sigui senzill, r&agrave;pid i efectiu 
                                        i al mateix temps permeti futures inegraciones 
                                        interdepartamentales</font></p>
										
                                      <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Sota 
                                      aquest marc i filosofia vam presentar el 
                                      programa de comptabilitat BulmaG&eacute;s.</font> 
                                    </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <BR> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;BulmaG&eacute;s 
                                0.3.7</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">L'&uacute;ltima 
                                        versi&oacute; publicada de BulmaG&eacute;s 
                                        &eacute;s la 0.3.7.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Pot 
                                        descarregar-la en la nostra secci&oacute; 
                                        de <a href="01descarga.php">download</a>.</font></p>
                                      </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                         <br><br>
						
                          <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;<font color="#990000">BulmaG&eacute;s 
                                Code Parties</font></strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Els 
                                        col&middot;laboradors del projecte organitzen 
                                        cada setmana una Code Party de BulmaG&eacute;s 
                                        i esteu tots convidats. Excepte av&iacute;s, 
                                        ser&agrave; cada diumenge a la tarda (sobre 
                                        les 16:00 o 17:00 h.)</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Si 
                                        vols m&eacute;s informaci&oacute; o confirmar 
                                        la teva assist&egrave;ncia escriu a la 
                                        llista de distribuci&oacute; del projecte. 
                                        Sommi... a que esperes</font><font size="1" face="Verdana, Arial, Helvetica, sans-serif">?</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/01pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
