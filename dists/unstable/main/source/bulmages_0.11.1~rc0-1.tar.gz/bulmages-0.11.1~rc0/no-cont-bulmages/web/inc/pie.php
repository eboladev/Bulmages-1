<table width="684" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
    <td align="right"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">�Preguntas, 
      sugerencias o comentarios sobre el proyecto?. Escriba a nuestra <a href="links.php"> 
      lista de distribuci�n</a>.<br> <A HREF="http://www.iglues.org">Asociaci&oacute;n Iglues</A>, Septiempbre 2004</font></td>
</tr>
</table>
