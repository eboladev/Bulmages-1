<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body bgcolor="#cdd5d8">
<div id="Layer1" style="position:absolute; left:396px; top:563px; width:421px; height:108px; z-index:1; visibility: hidden;">
  <p>contabilidad linux gestion libre gratis open source free software programa 
    descarga contabilidad plan contable espa&ntilde;ol general diario mayor balance 
    bulma download </p>
</div>
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"> <?php include("inc/01cabecera.php") ?> </td>
          </tr>
          <tr> 
            <td><table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/01menuizq.php")?>
                    </div></td>
                  <td height="294" bgcolor="#FFFFFF"><table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                      <tr> 
                        <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;La 
                          import&agrave;ncia del Programari Lliure en l'entorn 
                          educatiu</strong></font></td>
                      </tr>
                    </table>
<table width="97%" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                      <tr> 
                        <td width="96%" height="1322"> <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Actualment, 
                            un proc&eacute;s educatiu que no inclogui la doc&egrave;ncia 
                            de coneixements (encara que siguin b&agrave;sics) 
                            d'inform&agrave;tica, &eacute;s considerat deficient. 
                            Si b&eacute; fins fa molt pocs anys la inform&agrave;tica 
                            era una gran desconeguda per a la major part dels 
                            mortals, en pocs anys s'ha convertit en un requisit 
                            indispensable per a la gaireb&eacute; totalitat dels 
                            llocs de treball d'oficina.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            Fa tot just 10 anys, aprendre conceptes b&agrave;sics 
                            d'inform&agrave;tica suposava utilitzar un m&egrave;tode 
                            autodidacta, apuntar-se a una &quot;acad&egrave;mia&quot; 
                            o especialitzar-se mitjan&ccedil;ant cursos d'entitats 
                            privades o p&uacute;bliques. No obstant aix&ograve;, 
                            avui en dia, la major part dels centres educatius 
                            (especialment els d'origen privat) disposen, almenys, 
                            d'un aula d'inform&agrave;tica on els alumnes poden 
                            familiaritzar-se amb l'ordinador (en una primera etapa 
                            i a trav&eacute;s de jocs) i aprendre (m&eacute;s 
                            endavant), almenys, nocions b&agrave;siques (especialment 
                            sobre ofim&agrave;tica o el maneig d'Internet com 
                            font d'obtenci&oacute; de recursos)</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Per&ograve;, 
                            fins i tot amb aquest gran avan&ccedil;, la inserci&oacute; 
                            en el pla d'estudis de la utilitzaci&oacute; d'ordinadors 
                            segueix sent una tasca especialment dif&iacute;cil 
                            d'afrontar, principalment per les tremendes inversions 
                            de capital que suposa la compra d'equips, l'adquisici&oacute; 
                            de programari, les infraestructures, els costos en 
                            telecomunicacions, el suport t&egrave;cnic i el manteniment 
                            i actualitzaci&oacute; del sistema.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Aquest 
                            gran problema, potser el m&eacute;s important, pot 
                            solucionar-se m&eacute;s f&agrave;cilment del que 
                            sembla amb la utilitzaci&oacute; de programari lliure. 
                            El gran avantatge &eacute;s, evidentment, la gratu&iuml;tat 
                            del mateix. Qualsevol pot tenir una c&ograve;pia obtinguda 
                            de qualsevol font, instal&middot;lar-la on vulgui, 
                            com vulgui i quan vulgui i cedir-la a altres possibles 
                            usuaris sense cap cost per a ambd&oacute;s.<br>
                            El cost de renovacions i manuals tamb&eacute; desapareix, 
                            aix&iacute; com el cost del suport t&egrave;cnic si 
                            es tenen en compte la infinitat de manuals i grups 
                            que estan disponibles especialment en Internet i que 
                            no cobren per oferir la seva ajuda a l'usuari. A m&eacute;s, 
                            el programari lliure t&eacute; una llic&egrave;ncia 
                            d'&uacute;s gratu&iuml;t per a sempre, aix&ograve; 
                            garanteix el seu &uacute;s lliure sense cap risc legal.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Amb 
                            la utilitzaci&oacute; del programari lliure tamb&eacute; 
                            desapareixen els problemes econ&ograve;mics de l'actualitzaci&oacute; 
                            i millora del programari, ja que totes les versions 
                            posteriors i millorades del programari que h&agrave;gim 
                            elegit s&oacute;n autom&agrave;ticament posades a 
                            la disposici&oacute; de tots els possibles usuaris. 
                            Sense cap cost monetari, per descomptat.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">D'altra 
                            banda, i aquest punt &eacute;s especialment important, 
                            la utilitzaci&oacute; de programari lliure permet 
                            que totes i cadascuna de les persones interesades 
                            puguin modificar, ampliar i millorar el programari 
                            del que disposen. Aix&ograve; no nom&eacute;s fa refer&egrave;ncia 
                            a l'instant anterior (gr&agrave;cies al com tots els 
                            usuaris es beneficien) sin&oacute; que, a m&eacute;s, 
                            permet que el programari utilitzat s'adapti perfectament 
                            als requisits de l'usuari. Aix&iacute;, no &eacute;s 
                            necessari adquirir tot un paquet de programes si nom&eacute;s 
                            ens interessen una part d'ells i cadascun d'aquests 
                            programes que anem a instal&middot;lar &eacute;s adaptable 
                            al que nosaltres volem que sigui. Per exemple, podem 
                            instal&middot;lar un programa de comptabilitat desenvolupat 
                            en codi obert i afegir-li un petit programa que corregeixi 
                            els errors dels alumnes i els expliqui quina fallada 
                            han com&egrave;s al realitzar exercicis amb ell. L'&uacute;nica 
                            condici&oacute; del programari lliure &eacute;s que, 
                            aix&iacute; com nosaltres podem beneficiar-nos de 
                            totes les millores que altres usuaris han introdu&iuml;t 
                            al programa, tamb&eacute; estem obligats a fer p&uacute;bliques, 
                            i gratu&iuml;tes, totes les millores o modificacions 
                            que nosaltres realitzem.</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">En 
                            q&uuml;esti&oacute; d'inversi&oacute; en maquinari 
                            el programari lliure tamb&eacute; ofereix bastants 
                            avantatges. Per a comen&ccedil;ar, a l'estar desenvolupat 
                            per multitud d'usuaris que no comparteixen les mateixes 
                            caracter&iacute;stiques t&egrave;cniques, el programari 
                            lliure sol ser compatible amb gaireb&eacute; tots 
                            els components del mercat. Fins i tot amb aquells 
                            que programes o sistemes operatius actuals consideren 
                            obsolets. Aix&ograve; suposa no estar invertint cont&iacute;nuament 
                            en nou maquinari.
							<br>
                            D'altra banda, &uacute;ltimament en diversos centres 
                            educatius, i amb l'ajuda d'associacions de foment 
                            de l'&uacute;s del programari lliure i particulars, 
                            s'est&agrave; procedint a la reconversi&oacute; d'equips 
                            obsolets que no s&oacute;n capa&ccedil;os de funcionar 
                            per si mateixos. El sistema consisteix a instal&middot;lar 
                            un servidor, com &uacute;nica inversi&oacute;, que 
                            est&agrave; basat en sistemes operatius linux i connectar 
                            els altres ordinadors a aquest servidor de forma que 
                            utilitzin els seus recursos per a funcionar. El usurario 
                            final, en aquest cas els alumnes, no noten cap difer&egrave;ncia, 
                            I 
                            l'estalvi que suposa per al centre educatiu &eacute;s 
                            inestimable. <br>(<a href="http://www.hispalinux.net/casos.html?id=24" target="_blank">http://www.hispalinux.net/casos.html?id=24</a> 
                            - HISPALINUX.NET)</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">A 
                            aix&ograve; hem d'afegir-li que l'educaci&oacute; 
                            ha de ser objectiva i parcial. La pregunta &eacute;s 
                            la seg&uuml;ent &iquest;volem ensenyar als estudiants 
                            l'&uacute;s de la tecnologia o l'&uacute;s d'un sol 
                            programa? Utilitzar un sol sistema operatiu en l'ensenyament, 
                            per exemple, &eacute;s com si els inculqu&eacute;ssim 
                            que per a escriure nom&eacute;s valen uns bol&iacute;grafs 
                            d'una marca determinada. Per aquest motiu, fins i 
                            tot encara que el centre es decanti per la utilitzaci&oacute; 
                            de programari amb codi tancat, tamb&eacute; deuria 
                            ntroduir el programari lliure, no nom&eacute;s perqu&egrave; 
                            els alumnes aprenguin a usar-ho encara que sigui a 
                            un nivell b&agrave;sic, sin&oacute; perqu&egrave; 
                            coneguin la seva exist&egrave;ncia i puguin elegir 
                            entre les diferents opcions que existeixen en el mercat. 
                            El programari lliure fomenta, principalment, la llibertat 
                            i la cooperaci&oacute; com valors ineludibles, no 
                            s'afavoreix a cap empresa i no fomenta les c&ograve;pies 
                            il&middot;legals (pirateria)</font></p>
                          <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Finalment, 
                            imagini tot el que es pot fer amb els milions d'euros 
                            que s'estalviarien anualment en adquisici&oacute;, 
                            manteniment i millora del programari en l'&agrave;mbit 
                            educatiu: millors recursos en les aules, m&eacute;s 
                            beques d'estudis, m&eacute;s centres educatius, millora 
                            de les instal&middot;lacions, augment del professorat 
                            i ensenyaments personalitzats... &iquest;Mereix o 
                            no mereix la pena considerar aquesta opci&oacute;?</font></p>
                          <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FF0000"><br>
                            M&aacute;s informaci&oacute;:</font></strong></font></p>
                          <font color="#3399FF" size="1" face="Verdana, Arial, Helvetica, sans-serif">Projecte 
                          GNU en les escoles:</font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://gnu.mirror.widexs.nl/education/education.es.html" target="_blank"> 
                          http://gnu.mirror.widexs.nl/education/education.es.html</a><br>
                          <font color="#3399FF">Open Source Education Foundation 
                          Website: </font><a href="http://www.osef.org/" target="_blank">http://www.osef.org/</a><br>
                          <font color="#3399FF">OFSET (Organitation for Free Software 
                          in Eduaction and Teaching)</font> <a href="http://www.ofset.org/" target="_blank">http://www.ofset.org</a> 
                          <BR>
                          <font color="#3399FF">UNESCO Free Software Portal:</font></font> 
                          <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.unesco.org/webworld/portal_freesoft/" target="_blank">http://www.unesco.org/webworld/portal_freesoft/</a><BR>
                          <font color="#3399FF">HISPALINUX:</font></font> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.hispalinux.es" target="_blank">http://www.hispalinux.es</a><BR>
                          <font color="#3399FF">Open Source en l'Educaci&oacute;:</font></font> 
                          <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://www.geekvoice.com/articulo/otro/14/" target="_blank">http://www.geekvoice.com/articulo/otro/14/</a></font> 
                          <BR>
                          <font color="#3399FF" size="1" face="Verdana, Arial, Helvetica, sans-serif">Grup 
                          d'Usuaris de Linux Escola Normal de Zacatecas i Govern:</font> 
                          <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="http://enmac.seul.org/noticias.html" target="_blank">http://enmac.seul.org/noticias.html</a></font> 
                          <p></p>
                          <p></p>
                          <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cristina 
                            Marco - Agost 2003 <br>
                            cmarco(arroba)conetxia.com <br>
                            Pot reproduir aquesta not&iacute;cia sense necessitat 
                            de demanar autoritzaci&oacute; per a aix&ograve; sempre 
                            que citi a la font i a l'autora i notifiqui aquesta 
                            reproducci&oacute;.</font> </p></td>
                      </tr>
                    </table>
<br>
                    <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                      <tr> 
                        <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;Per 
                          que i com migrar cap a Linux</strong></font></td>
                      </tr>
                    </table>
                    <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                      <tr> 
                        <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                          </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                  En els &uacute;ltims anys el programari lliure 
                                  ha adquirit una import&agrave;ncia rellevant 
                                  en el m&oacute;n de la inform&agrave;tica. Contra 
                                  tot pron&ograve;stic, la comunitat del programari 
                                  lliure creix dia a dia posant a la disposici&oacute; 
                                  de tot el m&oacute;n gran varietat de problemes 
                                  resolts de forma excel&middot;lent.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cada 
                                  dia veiem com el programari lliure trenca el 
                                  model del programari propietari fent que moltes 
                                  empreses hagin perdut quota de mercat en &agrave;rees 
                                  com el sector de servidors, bases de dades, 
                                  sistemes d'alt rendiment i un llarg etc&egrave;tera 
                                  d'&agrave;rees on la inform&agrave;tica &eacute;s 
                                  imprescindible.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&iquest;Quins 
                                  s&oacute;n els avantatges del programari lliure?</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  Major independ&egrave;ncia: Normalment, l'elecci&oacute; 
                                  d'un programa propietari implica una forta depend&egrave;ncia 
                                  d'una empresa externa, els objectius de la qual 
                                  no s&oacute;n els mateixos que els de la seva 
                                  empresa.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Si 
                                  V&egrave;. elegeix qualsevol programa comercial, 
                                  no nom&eacute;s haur&agrave; comprat el dret 
                                  d'&uacute;s del programa. Tamb&eacute; estar&agrave; 
                                  exposat als capritxos de l'empresa que ha realitzat 
                                  aquest programa. &Eacute;s a dir, &eacute;s 
                                  com si V&egrave;. pogu&eacute;s agafar als seus 
                                  clients, obligar-los a adquirir les &uacute;ltimes 
                                  versions dels seus productes al&middot;legant 
                                  incompatibilitats amb versions anteriors, cobrar-los 
                                  les correccions de les errades comeses com caracter&iacute;stiques 
                                  noves, o fins i tot espatllar parts que funcionen 
                                  correctament per a despr&eacute;s poder revendre-les 
                                  com novetats, obligar-los a treballar per a 
                                  vost&egrave; com testadores del seu producte, 
                                  etc &iquest;Ho faria?, &iquest;Faria alguna 
                                  cosa per a solucionar aquest cercle vici&oacute;s 
                                  que li resulta tan benefici&oacute;s?</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Si 
                                  V&egrave;. elegeix un sistema fet a mesura per 
                                  a la seva empresa ha adquirit l'obligaci&oacute; 
                                  de treballar amb determinada empresa a molt 
                                  llarg termini. Durant una llarg&agrave;ria per&iacute;ode 
                                  de temps el seu programari no estar&agrave; 
                                  integrat completament amb la seva empresa i 
                                  tot i que aconsegueixi aquesta meta tindr&agrave; 
                                  totes unes tasques de manteniment que afrontar 
                                  per al seu programa. Una pregunta referent a 
                                  aix&ograve;: Si Vost&egrave; paga pel desenvolupament 
                                  d'un programa, &iquest;Per qu&egrave; despr&eacute;s 
                                  no obt&eacute; tot el necessari per a reconstruir 
                                  aquest programa? &iquest;Per qu&egrave;, suposant 
                                  que V&egrave;. ent&eacute;n d'inform&agrave;tica, 
                                  no pot modificar-ho al seu antull sense haver 
                                  de pagar un nou desenvolupament a l'empresa 
                                  que li va fer el desenvolupament inicial? &iquest;T&eacute; 
                                  V&egrave;. la certesa que el que ha pagat no 
                                  ser&agrave; despr&eacute;s revenut als seus 
                                  competidors, fins i tot a menor cost del que 
                                  li cost a Vd?.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  programari lliure pret&eacute;n evitar tots 
                                  aquests problemes al desvincular la propietat 
                                  del programari realitzat amb qualsevol empresa. 
                                  Aix&ograve; significa que tot el m&oacute;n 
                                  t&eacute; acc&eacute;s al codi font del programa 
                                  i, a m&eacute;s, pot modificar-ho i introduir 
                                  millores i noves caracter&iacute;stiques de 
                                  les quals V&egrave;. es pot beneficiar a llarg 
                                  termini.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>I 
                                  aix&ograve; a mi en que em beneficia i en que 
                                  em perjudica</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Els 
                                  beneficis d'aquesta estrat&egrave;gia de desenvolupament 
                                  de programari s&oacute;n principalment dos:</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  V&egrave;. obt&eacute; programari amb molts 
                                  menys compromissos que les versions propiet&agrave;ries. 
                                  Aix&ograve; es tradueix en una menor exposici&oacute;.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  V&egrave;. pot beneficiar-se del treball dels 
                                  altres.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Els 
                                  desavantatges s&oacute;n les seg&uuml;ents:</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">- 
                                  Els seus competidors poden beneficiar-se del 
                                  seu treball.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>I 
                                  qui m&eacute;s es beneficia del programari lliure</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  programari lliure no nom&eacute;s li beneficia 
                                  a V&egrave;. tamb&eacute; beneficia a tots els 
                                  inform&agrave;tics del m&oacute;n. (No confongui 
                                  el terme inform&agrave;tics amb el terme empreses 
                                  d'inform&agrave;tica. No &eacute;s el mateix) 
                                  El programari propietari, normalment, no beneficia 
                                  als seus creadors. Aquests solen ser persones 
                                  contractades, sense drets sobre el seu admirable 
                                  treball. Pregunti's com &eacute;s possible que 
                                  el manual d'un programa costi m&eacute;s que 
                                  el propi programa, quan els costos del programa 
                                  s&oacute;n infinitament superiors als de l'elaboraci&oacute; 
                                  del manual. &iquest;S'ha preguntat com &eacute;s 
                                  possible que conegui el nom dels autors del 
                                  seu llibre favorit, i no conegui als realitzadors 
                                  d'aquells programes que usa di&agrave;riament?</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  programari lliure ofereix moltes m&eacute;s 
                                  oportunitats als propis programadors, que poden 
                                  cobrar per la seva programaci&oacute; sense 
                                  haver de preocupar-se per temes com canals de 
                                  distribuci&oacute;, nivells de vendes, o an&agrave;lisi 
                                  de costos. D'aquesta forma un programador pot 
                                  dedicar-se a all&ograve; que realment li interessa, 
                                  cobrar pels seus serveis i, al mateix temps, 
                                  ajudar a la resta del m&oacute;n.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">El 
                                  model suposa que els programadors han d'actuar 
                                  en comunitat per a la realitzaci&oacute; del 
                                  programari i despr&eacute;s cobrar per les tasques 
                                  especifiques que aquest programari implica en 
                                  cada empresa.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>On 
                                  fer servir programari lliure</strong></font></p>
                                <p align="justify"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Els 
                                  pros i contres del programari lliure estan sobre 
                                  la taula, ara falta decidir si usar programari 
                                  lliure o no i on &eacute;s millor usar-ho i 
                                  on no.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Una 
                                  de les millors &agrave;rees d'aplicaci&oacute; 
                                  del programari lliure, i on obtindr&agrave; 
                                  totes les finestres d'aquest i cap inconvenient 
                                  &eacute;s en els sectors comuns. Programes que 
                                  no alteren el funcionament de l'empresa, que 
                                  resolen tasques cuotidianas i no estructuren 
                                  per res la seva empresa. Per exemple: lectors 
                                  de correu electr&ograve;nic, navegadors, processadors 
                                  de text, fulles de c&agrave;lcul, etc. Existeixen 
                                  gran varietat de productes d'igual o superior 
                                  nivell que els costosos programes comercials, 
                                  amb menys problemes de compatibilitats i amb 
                                  un suport estupend. </font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Una 
                                  altra &agrave;rea d'aplicaci&oacute; &eacute;s 
                                  en els programes d'&uacute;s de l'empresa, no 
                                  tan quotidians com els anteriors, per&ograve; 
                                  si d'&uacute;s per un gran nombre d'empreses, 
                                  o per totes les empreses d'un determinat sector, 
                                  comptabilitat, facturaci&oacute;, control de 
                                  stock, etc. Bulmag&eacute;s es troba dintre 
                                  d'aquesta &agrave;rea.</font></p>
                                <p align="justify"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>On 
                                  no &eacute;s convenient usar programari lliure:</strong></font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Existeixen 
                                  problemes espec&iacute;fics de la seva empresa. 
                                  Normalment no trobar&agrave; programes comercials 
                                  que donin resposta a aquests problemes, s&oacute;n 
                                  programes de gran valor per a V&egrave;. ja 
                                  que d'ells dep&egrave;n el bon funcionament 
                                  de l'empresa. Normalment V&egrave;. no precisar&agrave; 
                                  programes d'aquest nivell, per&ograve; si &eacute;s 
                                  el seu cas actu&iuml; de la seg&uuml;ent manera 
                                  per a no quedar petrificat. Exigeixi el codi 
                                  font dels programes que es realitzin per a V&egrave;. 
                                  No &eacute;s necessari que el distribueixi, 
                                  per&ograve; obligui que aquest codi no sigui 
                                  distribuit. No exposi el <br>
                                  cor de la seva empresa. Si cal assessori's per 
                                  tercers perqu&egrave; es defensin els interessos 
                                  de la seva empresa i no els d'uns altress.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Per&ograve;, 
                                  atenci&oacute;, aix&ograve; no significa que 
                                  no pugui aprofitar les eines de programari lliure 
                                  per a la realitzaci&oacute; d'aquest programa. 
                                  V&egrave;. pot realitzar, i utilitzar aqueix 
                                  programa utilitzant tot el programari lliure 
                                  que necessiti sense inc&oacute;rrer en cap delicte.</font></p>
                                <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">L'&uacute;nica 
                                  condici&oacute; &eacute;s que no podr&agrave; 
                                  distribuir aquest programari a ning&uacute; 
                                  m&eacute;s que no sigui V&egrave;. Cosa que, 
                                  per altra banda, no li interessa ja que el programa 
                                  &uacute;nicament resol els problemes de la seva 
                                  empresa i la distribuci&oacute; de dita programari 
                                  seria un error estrat&egrave;gic per a V&egrave;.</font></p></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table>
                    <br>
                    <br>
                    <p align="center"> <a href="http://bulmalug.net"><img src="img/bulma_small.jpg" width="250" height="44" border="0"></a></p>
</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/01pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
