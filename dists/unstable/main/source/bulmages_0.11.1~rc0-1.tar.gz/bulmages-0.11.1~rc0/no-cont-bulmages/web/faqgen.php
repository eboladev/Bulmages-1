<html>
<head>
<title>BulmaGes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="FW MX DW MX HTML">
<link href="styles/miestilo.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#cdd5d8">
<div align="center">
  <table width="700" border="0" cellpadding="0" cellspacing="0" class="tablaprincipal">
    <tr> 
      <td><table width="684" border="0" align="center" cellpadding="0" cellspacing="0" class="tabladocumento">
          <tr> 
            <td valign="bottom"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>
              <?php include("inc/cabecera.php") ?>
              </strong></font> </td>
          </tr>
          <tr> 
            <td><table border="0" width="97%" align="center" cellpadding="0" cellspacing="0">
<tr valign="top"> 
                  <td width="29%"> <div align="center"> 
                      <?php include("inc/menuizq.php")?>
                    </div></td>
                  <td>
                    <table width="506" height="498" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr> 
                        <td height="19"><table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;Preguntas 
                                Generales sobre BulmaG&eacute;s</strong></font></td>
                            </tr>
                          </table> </td>
                      </tr>
                      <tr> 
                        <td height="294" valign="top"> 
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="9%"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td width="91%"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Qu&eacute; 
                                            es BulmaG&eacute;s? </font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Qui&eacute;n 
                                            hace BulmaG&eacute;s?</font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Puedo 
                                            utilizar ya el programa?</font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Cu&aacute;nto 
                                            falta para que est&eacute; terminado?</font></td>
                                        </tr>
                                        <tr> 
                                          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">-</font></div></td>
                                          <td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&iquest;Cu&aacute;nto 
                                            cuesta el programa? &iquest;D&oacute;nde 
                                            lo compro? </font></td>
                                        </tr>
                                      </table>
                                      
                                    </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
						  <br><br>
                          <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;&iquest;Qu&eacute; 
                                es BulmaG&eacute;s?</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">BulmaG&eacute;s 
                                        es un proyecto serio nacido desde la asociaci&oacute;n 
                                        <a href="http://bulma.net" target="_blank">BULMA</a> 
                                        que pretende realizar un programa de contabilidad 
                                        bajo entorno Linux. Pero no un programa 
                                        cualquiera, sino una herramienta completa 
                                        y eficaz capaz de realizar todas las tareas 
                                        contables que pueda necesitar una gran 
                                        empresa. <br>
                                        Es decir, el programa se prepara para 
                                        una asctividad contable profesional, pero 
                                        esto no implica que no pueda ser utilizado 
                                        por peque&ntilde;as empresas e incluso 
                                        por particulares. BulmaG&eacute;s dispone 
                                        de sistemas de configuraci&oacute;n que 
                                        facilitan y resumen las tareas contables 
                                        sin perder su eficacia.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#333333">- 
                                        &iquest;Qu&eacute; significa que el programa 
                                        sea &quot;para Linux&quot;? </font></strong><br>
                                        Linux es un sistema operativo de entorno 
                                        libre. Esto significa mucho m&aacute;s 
                                        que el hecho de que el programa est&eacute; 
                                        desarrollado y funcione bajo entorno Linux. 
                                        Significa que sigue la filosof&iacute;a 
                                        del software libre y es un proyecto de 
                                        c&oacute;digo abierto, en todos los sentidos. 
                                        Para m&aacute;s informaci&oacute;n sobre 
                                        el software libre, visite la p&aacute;gina 
                                        de: </font></p>
                                      <p align="justify"><font color="#333333" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>- 
                                        Entonces, si uso otro sistema operativo, 
                                        &iquest;no puedo usar BulmaG&eacute;s? 
                                        </strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                                        S&iacute; que puede, s&oacute;lo tiene 
                                        que saber c&oacute;mo hacerlo. Consulte 
                                        la secci&oacute;n de Funcionamiento bajo 
                                        otros sistemas operativos.</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
						  <br>
                          <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;&iquest;Qui&eacute;n 
                                hace BulmaG&eacute;s?</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Hay 
                                        muchas personas que, de forma organizada, 
                                        colaboran o han colaborado con este proyecto. 
                                        Puede consultar sus nombres en la secci&oacute;n 
                                        de<a href="colaboradores.php"> Colaboradores</a>.<br>
                                        Todos ellos lo hacen de forma desinteresada 
                                        y libre, sin recibir ninguna compensaci&oacute;n 
                                        (ni monetaria ni material) por ello salvo 
                                        la satisfacci&oacute;n de sacar BulmaG&eacute;s 
                                        adelante. BulmaG&eacute;s no pertenece 
                                        a ninguno de ellos, ni a una empresa, 
                                        instituci&oacute;n o asociaci&oacute;n. 
                                        Es un proyecto que se pertenece a s&iacute; 
                                        mismo y a todas y cada una de las personas 
                                        que colaboran con &eacute;l.</font></p>
                                      <p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#333333">- 
                                        &iquest;Puedo colaborar con BulmaG&eacute;s? 
                                        </font></strong><br>
                                        &iexcl;Por supuesto! Gracias a las colaboraciones, 
                                        BulmaG&eacute;s avanza cada d&iacute;a. 
                                        Visite la secci&oacute;n de <a href="colaboracion.php">Colaboraci&oacute;n</a> 
                                        para conocer c&oacute;mo hacerlo. Y recuerde 
                                        que cualquier cosa que pueda hacer ser&aacute; 
                                        bienvenida. BulmaG&eacute;s siempre necesita 
                                        programadores porque esa &aacute;rea es 
                                        la que m&aacute;s trabajo presenta (sin 
                                        c&oacute;digo, no hay programa :) Pero 
                                        tambi&eacute;n necesita traductores, testadores, 
                                        asesores, documentadores y cualquier otra 
                                        cosa que se le ocurra que pueda aportar. 
                                        Y, por supuesto, financiadores.</font></p>
                                      <p align="justify"><font color="#333333" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>- 
                                        Y &iquest;qu&eacute; pasa si BulmaG&eacute;s 
                                        recibe una ayuda, un premio o una subvenci&oacute;n?</strong></font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
                                        Por desgracia es muy dif&iacute;cil conseguir 
                                        todas esas cosas cuando se trata de un 
                                        progr&aacute;ma de c&oacute;digo abierto, 
                                        aunque no imposible. Por norma general 
                                        BulmaG&eacute;s procura exponer el tema 
                                        a todos los colaboradores y decidir juntos 
                                        qu&eacute; hacer con esa aportaci&oacute;n 
                                        o premio. Nunca se destina a una persona 
                                        en particular, siempre se busca la soluci&oacute;n 
                                        m&aacute;s beneficiosa para el proyecto 
                                        y, en definitva, para todos.</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <br> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;&iquest;Puedo 
                                utilizar ya el programa?</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">S&iacute;, 
                                        s&oacute;lo tiene que descargarlo y ejecutarlo. 
                                        Pero recuerde que actualmente es una versi&oacute;n 
                                        Beta. Esto significa que el programa ya 
                                        es operativo y realiza todas las de las 
                                        tareas contables propias de un programa 
                                        de contabilidad. Pero pueden producirse 
                                        fallos y errores hasta que est&eacute; 
                                        finalizado, por lo que debe usarse con 
                                        cautela. <br>
                                        Pero estamos trabajando para que BulmaG&eacute;s 
                                        sea 100% fiable y, cada d&iacute;a que 
                                        pasa, queda un poco menos para conseguirlo. 
                                        Actualmente varias empresas reales ya 
                                        se han instalado el programa y lo utilizan 
                                        normalmente. </font></p>
                                      </td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <br> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;&iquest;Cu&aacute;nto 
                                falta para que est&eacute; terminado?</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Es 
                                        imposible establecer una fecha l&iacute;mite 
                                        de finalizaci&oacute;n del programa puesto 
                                        que se nutre de colaboraciones y el proyecto 
                                        es lo suficientemente grande y complicado 
                                        como para realizarlo con el tiempo que 
                                        se merece.
										<br>
                                        Por otro lado, al ser un programa de c&oacute;digo 
                                        abierto, esperamos que no se termine nunca, 
                                        ya que siempre habr&aacute; una nueva 
                                        idea que a&ntilde;adir, una nueva actualizaci&oacute;n 
                                        o una nueva mejora que lo convierta en 
                                        un programa mejor.</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <br> <table width="97%" border="0" align="center" cellpadding="0" cellspacing="3" bgcolor="#CCCCCC">
                            <tr> 
                              <td width="96%" height="19"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;&nbsp;&nbsp;&iquest;Cu&aacute;nto 
                                cuesta el programa? &iquest;D&oacute;nde lo compro?</strong></font></td>
                            </tr>
                          </table>
                          <table width="97%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
                            <tr> 
                              <td><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                                </font></strong> <table width="100%" border="1" cellpadding="5" cellspacing="0" bordercolor="#CCCCCC">
                                  <tr> 
                                    <td width="96%" height="19"><p align="justify"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">BulmaG&eacute;s 
                                        no se compra y no se vende. Su distribuci&oacute;n 
                                        es libre. Puede bajarse la &uacute;ltima 
                                        versi&oacute;n del programa desde <a href="descarga.php">aqu&iacute;</a>.</font></p></td>
                                  </tr>
                                </table></td>
                            </tr>
                          </table>
                          <p align="right">&nbsp;</p></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td valign="top"><div align="right"> 
                <?php include("inc/pie.php") ?>
              </div></td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
