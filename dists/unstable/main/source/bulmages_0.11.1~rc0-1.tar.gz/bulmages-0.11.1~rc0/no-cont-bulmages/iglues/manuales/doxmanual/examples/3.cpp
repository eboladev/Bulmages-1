int a;///Esto es un comentario de la variable a
int b;///Esto es un comentario de la variable b
int c;///Esto es un comentario de la variable c

int d;

float x;///< Estoy comentando a \c x
