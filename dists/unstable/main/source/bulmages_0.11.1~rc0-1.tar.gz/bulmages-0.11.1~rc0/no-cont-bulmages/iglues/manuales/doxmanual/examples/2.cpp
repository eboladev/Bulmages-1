/// Comentario de una sola l�nea
//! Tambi�n de una sola l�nea

/** Varias l�neas
  * ��la estrellita del principio
  * se ignora!!
*/

/*! De varias l�neas
Aqui podr�an venir o no una estrellita al principo de la l�nea
eso da igual.
*/

///< Esto tiene un significado especial

/**< Y esto */

/*!< Y esto otro */
