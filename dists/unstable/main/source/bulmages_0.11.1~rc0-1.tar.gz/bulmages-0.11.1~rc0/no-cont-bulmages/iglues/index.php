<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
  <title>IGLUES</title>
  <meta name="GENERATOR" content="Quanta Plus">
  <meta http-equiv="refresh" content="10; url=home.php">
  <link rel="stylesheet" type="text/css" href="iglues.css">
</head>
<SCRIPT>
//if (navigator.appName.indexOf("Microsoft") != -1) 
//	alert("Est� ejecutando Internet Explorer");
</SCRIPT>
<body>
<table width="100%" height="100%" border="0">
<tr><td valign="middle" align="center">

<a href="home.php">
<img src="img/igloo_web.jpg" width="600" height="397" border="0" alt="No te imaginas lo que se est� montando aqu� dentro...">
</a>
<br />
<h1>IGLUES contra las patentes de software
<br /> <br />
<A href='http://movilizacion.proinnova.org/'><IMG src='img/banner_movilizacion.gif' width='468' height='60' align='middle' border='0'></A>
<br />
</h1>
I.G.L.U.E.S. - 
Iniciativa
de Gestion
Libre
Universal
para Empresas
y Sociedades

</td></tr></tr>
</table>
</body>
</html>
