/** \brief Esto es una descripci�n corta

Esta es una descripci�n larga de la clase que 
he programado despues de incontables noches en vela.
*/

class myclass {
	public:
	int a;
	float b;
/**\brief Funci�n importante

Esta funci�n devuelve el valor de la variable \ref b.
*/
	
	int f(int x);
	private:
	double c;
}