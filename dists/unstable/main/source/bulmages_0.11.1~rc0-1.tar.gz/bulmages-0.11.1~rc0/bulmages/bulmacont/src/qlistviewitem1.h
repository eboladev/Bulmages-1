/***************************************************************************
 *   Copyright (C) 2003 by Tomeu Borras Riera                              *
 *   tborras@conetxia.com                                                  *
 *   http://www.iglues.org Asociación Iglues -- Contabilidad Linux         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef QLISTVIEWITEM1_H
#define QLISTVIEWITEM1_H

/*
#include <Q3ListView>
*/

///
/** */
/*
//class QListViewItem1 : public Q3ListViewItem {
public:
    int tipolista;
 
public:
 
    QListViewItem1(Q3ListView *parent) : Q3ListViewItem(parent) {}
    ;
    QListViewItem1(Q3ListViewItem *parent) : Q3ListViewItem(parent) {}
    ;
    ~QListViewItem1() {}
    ;
    void  paintCell(QPainter *, const QColorGroup &, int, int ,int);
    void setTipo(int a) {
        tipolista = a;
    };
    void width(const QFontMetrics &, const Q3ListView *, int);
 
};
*/
#endif

