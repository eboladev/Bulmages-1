#include "tecladonumerico.h"

TecladoNumerico::TecladoNumerico ( EmpresaBase *emp, QWidget *parent ) : BLWidget ( emp, parent )
{
    setupUi ( this );
}


TecladoNumerico::~TecladoNumerico()
{}

