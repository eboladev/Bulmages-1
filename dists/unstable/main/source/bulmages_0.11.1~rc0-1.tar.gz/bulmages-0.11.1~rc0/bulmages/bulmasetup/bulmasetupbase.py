# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'bulmasetupbase.ui'
#
# Created: Sat Mar 22 00:56:29 2008
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(QtCore.QSize(QtCore.QRect(0,0,557,459).size()).expandedTo(MainWindow.minimumSizeHint()))

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed,QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)

        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.label = QtGui.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20,20,209,150))
        self.label.setMinimumSize(QtCore.QSize(209,150))
        self.label.setMaximumSize(QtCore.QSize(209,150))
        self.label.setPixmap(QtGui.QPixmap("bulmasetup_iglues.jpg"))
        self.label.setObjectName("label")

        self.mui_crearusuario = QtGui.QPushButton(self.centralwidget)
        self.mui_crearusuario.setGeometry(QtCore.QRect(250,30,291,61))
        self.mui_crearusuario.setFocusPolicy(QtCore.Qt.NoFocus)
        self.mui_crearusuario.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.mui_crearusuario.setIcon(QtGui.QIcon("bulmasetup_usuario.xpm"))
        self.mui_crearusuario.setIconSize(QtCore.QSize(48,48))
        self.mui_crearusuario.setObjectName("mui_crearusuario")

        self.mui_crearbulmacont = QtGui.QPushButton(self.centralwidget)
        self.mui_crearbulmacont.setGeometry(QtCore.QRect(250,100,291,61))
        self.mui_crearbulmacont.setFocusPolicy(QtCore.Qt.NoFocus)
        self.mui_crearbulmacont.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.mui_crearbulmacont.setIcon(QtGui.QIcon("bulmasetup_bulmacont.png"))
        self.mui_crearbulmacont.setIconSize(QtCore.QSize(48,48))
        self.mui_crearbulmacont.setObjectName("mui_crearbulmacont")

        self.mui_crearbulmafact = QtGui.QPushButton(self.centralwidget)
        self.mui_crearbulmafact.setGeometry(QtCore.QRect(250,170,291,61))
        self.mui_crearbulmafact.setFocusPolicy(QtCore.Qt.NoFocus)
        self.mui_crearbulmafact.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.mui_crearbulmafact.setIcon(QtGui.QIcon("bulmasetup_bulmafact.png"))
        self.mui_crearbulmafact.setIconSize(QtCore.QSize(48,48))
        self.mui_crearbulmafact.setObjectName("mui_crearbulmafact")

        self.label_2 = QtGui.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(30,210,171,81))
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")

        self.mui_salir = QtGui.QPushButton(self.centralwidget)
        self.mui_salir.setGeometry(QtCore.QRect(460,420,75,24))
        self.mui_salir.setIcon(QtGui.QIcon("bulmasetup_exit.png"))
        self.mui_salir.setObjectName("mui_salir")

        self.line = QtGui.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(230,20,20,331))
        self.line.setFrameShape(QtGui.QFrame.VLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")

        self.mui_adminempresas = QtGui.QPushButton(self.centralwidget)
        self.mui_adminempresas.setGeometry(QtCore.QRect(250,240,291,61))
        self.mui_adminempresas.setFocusPolicy(QtCore.Qt.NoFocus)
        self.mui_adminempresas.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.mui_adminempresas.setIcon(QtGui.QIcon("bulmasetup_empresa.xpm"))
        self.mui_adminempresas.setIconSize(QtCore.QSize(48,48))
        self.mui_adminempresas.setObjectName("mui_adminempresas")

        self.mui_restbackup = QtGui.QPushButton(self.centralwidget)
        self.mui_restbackup.setGeometry(QtCore.QRect(250,310,291,61))
        self.mui_restbackup.setFocusPolicy(QtCore.Qt.NoFocus)
        self.mui_restbackup.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.mui_restbackup.setIcon(QtGui.QIcon("bulmasetup_cargarempresa.xpm"))
        self.mui_restbackup.setIconSize(QtCore.QSize(48,48))
        self.mui_restbackup.setObjectName("mui_restbackup")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QObject.connect(self.mui_salir,QtCore.SIGNAL("released()"),MainWindow.close)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QtGui.QApplication.translate("MainWindow", "MainWindow", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_crearusuario.setText(QtGui.QApplication.translate("MainWindow", "Nuevo Usuario de PostgreSQL", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_crearbulmacont.setText(QtGui.QApplication.translate("MainWindow", "Nueva Empresa de Contabilidad", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_crearbulmafact.setText(QtGui.QApplication.translate("MainWindow", "Nueva Empresa de Facturacion / TPV", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'Sans Serif\'; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;\">\n"
        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">BulmaSetup v 0.11</span></p>\n"
        "<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Administración de Bases</p>\n"
        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">de Datos para BulmaGés</p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_salir.setText(QtGui.QApplication.translate("MainWindow", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_adminempresas.setText(QtGui.QApplication.translate("MainWindow", "Administrar Empresas Existentes", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_restbackup.setText(QtGui.QApplication.translate("MainWindow", "Restaurar una Copia de Seguridad", None, QtGui.QApplication.UnicodeUTF8))

