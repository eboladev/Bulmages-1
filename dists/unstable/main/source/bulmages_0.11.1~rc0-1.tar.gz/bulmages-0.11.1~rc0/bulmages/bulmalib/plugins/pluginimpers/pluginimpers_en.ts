<!DOCTYPE TS><TS>
<context>
    <name>EQToolButton</name>
    <message>
        <source>Impresion Informes Personales</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
