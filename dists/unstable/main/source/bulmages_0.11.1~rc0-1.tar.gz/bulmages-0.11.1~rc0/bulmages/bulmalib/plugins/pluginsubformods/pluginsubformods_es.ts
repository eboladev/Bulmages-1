<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="es">
<context>
    <name>myplugsubformods</name>
    <message>
        <location filename="pluginsubformods.cpp" line="93"/>
        <source>Exportar a hoja de calculo</source>
        <translation type="unfinished">Exportar a hoja de cálculo</translation>
    </message>
</context>
</TS>
