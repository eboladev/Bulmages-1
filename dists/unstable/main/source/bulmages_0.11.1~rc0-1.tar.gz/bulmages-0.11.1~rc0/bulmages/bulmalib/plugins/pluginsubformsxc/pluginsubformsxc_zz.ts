<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="es_ES">
<context>
    <name>myplugsubformsxc</name>
    <message>
        <location filename="pluginsubformsxc.cpp" line="44"/>
        <source>Exportar a Hoja de Calculo</source>
        <translation>Manipular con KSpread</translation>
    </message>
</context>
</TS>
