--
-- PostgreSQL database dump
--
BEGIN;

SET client_encoding = 'UNICODE';
SET check_function_bodies = false;

SET search_path = public, pg_catalog;

--
-- Data for TOC entry 2 (OID 1345982)
-- Name: diario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY diario (iddiario, descripcion) FROM stdin;
\.

COMMIT;