# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'restbackupbase.ui'
#
# Created: Mon Mar 10 20:54:29 2008
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_RestBackupBase(object):
    def setupUi(self, RestBackupBase):
        RestBackupBase.setObjectName("RestBackupBase")
        RestBackupBase.resize(QtCore.QSize(QtCore.QRect(0,0,450,118).size()).expandedTo(RestBackupBase.minimumSizeHint()))

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed,QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(RestBackupBase.sizePolicy().hasHeightForWidth())
        RestBackupBase.setSizePolicy(sizePolicy)
        RestBackupBase.setMaximumSize(QtCore.QSize(450,118))

        self.gridlayout = QtGui.QGridLayout(RestBackupBase)
        self.gridlayout.setObjectName("gridlayout")

        self.label = QtGui.QLabel(RestBackupBase)
        self.label.setObjectName("label")
        self.gridlayout.addWidget(self.label,0,0,1,1)

        self.mui_dbname = QtGui.QLineEdit(RestBackupBase)
        self.mui_dbname.setObjectName("mui_dbname")
        self.gridlayout.addWidget(self.mui_dbname,0,1,1,3)

        self.label_2 = QtGui.QLabel(RestBackupBase)
        self.label_2.setObjectName("label_2")
        self.gridlayout.addWidget(self.label_2,1,0,1,1)

        self.mui_filename = QtGui.QLineEdit(RestBackupBase)
        self.mui_filename.setObjectName("mui_filename")
        self.gridlayout.addWidget(self.mui_filename,1,1,1,2)

        self.mui_filesearch = QtGui.QToolButton(RestBackupBase)
        self.mui_filesearch.setObjectName("mui_filesearch")
        self.gridlayout.addWidget(self.mui_filesearch,1,3,1,1)

        self.mui_aceptar = QtGui.QPushButton(RestBackupBase)
        self.mui_aceptar.setObjectName("mui_aceptar")
        self.gridlayout.addWidget(self.mui_aceptar,2,1,1,1)

        self.mui_cancelar = QtGui.QPushButton(RestBackupBase)
        self.mui_cancelar.setObjectName("mui_cancelar")
        self.gridlayout.addWidget(self.mui_cancelar,2,2,1,2)
        self.label.setBuddy(self.mui_dbname)

        self.retranslateUi(RestBackupBase)
        QtCore.QObject.connect(self.mui_cancelar,QtCore.SIGNAL("released()"),RestBackupBase.reject)
        QtCore.QMetaObject.connectSlotsByName(RestBackupBase)

    def retranslateUi(self, RestBackupBase):
        RestBackupBase.setWindowTitle(QtGui.QApplication.translate("RestBackupBase", "Restaurar Backup", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("RestBackupBase", "Base de Datos a crear", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("RestBackupBase", "Archivo a Restaurar", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_filesearch.setText(QtGui.QApplication.translate("RestBackupBase", "...", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_aceptar.setText(QtGui.QApplication.translate("RestBackupBase", "Aceptar", None, QtGui.QApplication.UnicodeUTF8))
        self.mui_cancelar.setText(QtGui.QApplication.translate("RestBackupBase", "Cancelar", None, QtGui.QApplication.UnicodeUTF8))

