--
-- PostgreSQL database dump
--
BEGIN;

SET client_encoding = 'UNICODE';
SET check_function_bodies = false;

SET search_path = public, pg_catalog;

--
-- Data for TOC entry 3 (OID 1346100)
-- Name: amortizacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY amortizacion (idamortizacion, idcuentaactivo, idcuentaamortizacion, descamortizacion, nomamortizacion, fechacompra, fecha1cuota, valorcompra, periodicidad, numcuotas, metodo, nifproveedor, nomproveedor, dirproveedor, telproveedor, agrupacion) FROM stdin;
4	770	770	\N	coche	2007-01-01	2007-01-01	120000	\N	5	\N	\N	\N	\N	\N	vehiculos
2	770	770	\N	motocicleta	2007-01-01	2007-12-31	6700	\N	5	\N	\N	\N	\N	\N	la amoto
5	483	586	\N	Edificio Sa Riera	2005-09-10	2005-09-10	100	\N	10	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 2 (OID 1346098)
-- Name: amortizacion_idamortizacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('amortizacion_idamortizacion_seq', 5, true);

COMMIT;