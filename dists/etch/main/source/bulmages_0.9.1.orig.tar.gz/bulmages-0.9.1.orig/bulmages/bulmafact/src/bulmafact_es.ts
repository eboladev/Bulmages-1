<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="es">
<context>
    <name>AboutView</name>
    <message>
        <location filename="aboutview.cpp" line="36"/>
        <source>Compilado usando la version de QT:</source>
        <translation>Compilado usando la version de QT:</translation>
    </message>
</context>
<context>
    <name>AlbaranCliente</name>
    <message>
        <location filename="albarancliente.cpp" line="38"/>
        <source>Id albaran</source>
        <translation>Id albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="39"/>
        <source>Id cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="40"/>
        <source>Id almacen</source>
        <translation>Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="41"/>
        <source>Numero de albaran</source>
        <translation>NÃºmero de albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="42"/>
        <source>Fecha albaran</source>
        <translation>Fecha albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="43"/>
        <source>Contacto albaran</source>
        <translation>Contacto albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="44"/>
        <source>Telefono</source>
        <translation>TelÃ©fono</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="45"/>
        <source>Comentario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="46"/>
        <source>Comentario priv albaran</source>
        <translation>Comentario priv albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="47"/>
        <source>Id forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="48"/>
        <source>Id trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="49"/>
        <source>Procesado albaran</source>
        <translation>Procesado albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="50"/>
        <source>Descripcion albaran</source>
        <translation>DescripciÃ³n albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albarancliente.cpp" line="51"/>
        <source>Referencia albaran</source>
        <translation>Referencia albarÃ¡n</translation>
    </message>
</context>
<context>
    <name>AlbaranClienteBase</name>
    <message>
        <location filename="albaranclientebase.ui" line="599"/>
        <source>Procesado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="855"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1613"/>
        <source>0.00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="203"/>
        <source>Agregar a factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="480"/>
        <source>Descripcion:</source>
        <translation>DescripciÃ³n:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="albaranclientebase.ui" line="532"/>
        <source>NÂº de albaran:</source>
        <translation>NÂº de albarÃ¡n:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="691"/>
        <source>Almacen:</source>
        <translation>AlmacÃ©n:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="723"/>
        <source>Forma de pago:</source>
        <translation>Forma de pago:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="755"/>
        <source>Trabajador:</source>
        <translation>Trabajador:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="647"/>
        <source>Fecha de creacion:</source>
        <translation>Fecha de creaciÃ³n:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="813"/>
        <source>Persona de contacto:</source>
        <translation>Persona de contacto:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1683"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1665"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="784"/>
        <source>Telefono de contacto:</source>
        <translation>TelÃ©fono de contacto:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="907"/>
        <source>Comentarios publicos:</source>
        <translation>Cometarios pÃºblicos:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="943"/>
        <source>Comentarios privados:</source>
        <translation>Comentarios privados:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="389"/>
        <source>Guardar albaran</source>
        <translation>Guardar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="355"/>
        <source>Borrar albaran</source>
        <translation>Borrar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="321"/>
        <source>Imprimir albaran</source>
        <translation>Imprimir albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="147"/>
        <source>Referencia del albaran:</source>
        <translation>Referencia del albarÃ¡n:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="871"/>
        <source>Descuen&amp;tos</source>
        <translation>Descuen&amp;tos</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="887"/>
        <source>Comentario&amp;s</source>
        <translation>Comentario&amp;s</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="13"/>
        <source>Nuevo albaran de cliente</source>
        <translation>Nuevo albarÃ¡n de cliente</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="436"/>
        <source>Mostrar/ocultar cabecera</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1010"/>
        <source>Descuentos:</source>
        <translation>Descuentos:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1119"/>
        <source>Base imponible:</source>
        <translation>Base imponible:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1331"/>
        <source>Impuestos:</source>
        <translation>Impuestos:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1543"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1437"/>
        <source>R.E.:</source>
        <translation>R.E.:</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="169"/>
        <source>Registrar cobro a cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="237"/>
        <source>Generar factura a partir de este albaran</source>
        <translation>Generar factura a partir de este albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="271"/>
        <source>Ver pedidos con la misma referencia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientebase.ui" line="1225"/>
        <source>I.R.P.F.:</source>
        <translation>I.R.P.F.:</translation>
    </message>
</context>
<context>
    <name>AlbaranClienteList</name>
    <message>
        <location filename="albaranclientelist.cpp" line="174"/>
        <source>Error al borrar el albaran a cliente</source>
        <translation>Error al borrar el albarÃ¡n a cliente</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="160"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="185"/>
        <source>Albaranes a clientes</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>AlbaranClienteListBase</name>
    <message>
        <location filename="albaranclientelistbase.ui" line="500"/>
        <source>Procesados</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="92"/>
        <source>Nuevo albaran</source>
        <translation>Nuevo albaraÅ</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="129"/>
        <source>Editar albaran</source>
        <translation>Editar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="166"/>
        <source>Borrar albaran</source>
        <translation>Borrar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="240"/>
        <source>Filtrar albaranes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="280"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="320"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="379"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="424"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="457"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="552"/>
        <source>Total: </source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="17"/>
        <source>Albaranes a clientes</source>
        <translation>Albaranes a clientes</translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="255"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="295"/>
        <source>Ctrl+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelistbase.ui" line="335"/>
        <source>F5</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>AlbaranClienteListSubform</name>
    <message>
        <location filename="albaranclientelist.cpp" line="244"/>
        <source>Referencia de albaran</source>
        <translation>Referencia del albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="245"/>
        <source>Codigo de almacen</source>
        <translation>CÃ³digo de almacÃ©n</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="246"/>
        <source>Numero de albaran</source>
        <translation>NÃºmero de albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="248"/>
        <source>Fecha de albaran</source>
        <translation>Fecha de albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="249"/>
        <source>Nombre de cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="250"/>
        <source>ID forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="251"/>
        <source>Descripcion de forma de pago</source>
        <translation>DescripciÃ³n de forma de pago</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="252"/>
        <source>ID trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="253"/>
        <source>ID cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="254"/>
        <source>ID albaran</source>
        <translation>ID albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="255"/>
        <source>Comentarios del albaran</source>
        <translation>Comentarios del albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="256"/>
        <source>ID almacen</source>
        <translation>ID almacÃ©n</translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="257"/>
        <source>Base imponible</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="258"/>
        <source>Impuestos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="259"/>
        <source>Total</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclientelist.cpp" line="247"/>
        <source>Descripcion</source>
        <translation>DescripciÃ³n</translation>
    </message>
</context>
<context>
    <name>AlbaranClienteView</name>
    <message>
        <location filename="albaranclienteview.cpp" line="193"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="albaranclienteview.cpp" line="193"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="albaranclienteview.cpp" line="279"/>
        <source>Num. albaran</source>
        <translation>NÃºm. albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranclienteview.cpp" line="318"/>
        <source>Albaran a cliente</source>
        <translation>AlbarÃ¡n a cliente</translation>
    </message>
    <message>
        <location filename="albaranclienteview.cpp" line="191"/>
        <source>Factura existente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranclienteview.cpp" line="192"/>
        <source>Existe una factura a este cliente con la misma referencia que este albaran. Desea abrirla para verificar?</source>
        <translation>Existe una factura a este cliente con la misma referencia que este albarÃ¡n. Â¿Desea abrirla para verificar?</translation>
    </message>
    <message>
        <location filename="albaranclienteview.cpp" line="70"/>
        <source>Error al crear el albaran a cliente</source>
        <translation>Error al crear el albarÃ¡n a cliente</translation>
    </message>
</context>
<context>
    <name>AlbaranProveedor</name>
    <message>
        <location filename="albaranproveedor.cpp" line="34"/>
        <source>Id albaran proveedor</source>
        <translation>Id albarÃ¡n proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="35"/>
        <source>Numero albaran proveedor</source>
        <translation>NÃºmero albarÃ¡n proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="36"/>
        <source>Fecha albaran proveedor</source>
        <translation>Fecha albarÃ¡n proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="37"/>
        <source>Comentario albaran proveedor</source>
        <translation>Comentario albarÃ¡n proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="38"/>
        <source>Id proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="39"/>
        <source>Id forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="40"/>
        <source>Id almacen</source>
        <translation>Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="41"/>
        <source>Referencia albaran proveedor</source>
        <translation>Referencia albarÃ¡n proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedor.cpp" line="42"/>
        <source>Descripcion albaran proveedor</source>
        <translation>DescripciÃ³n albarÃ¡n proveedor</translation>
    </message>
</context>
<context>
    <name>AlbaranProveedorBase</name>
    <message>
        <location filename="albaranproveedorbase.ui" line="677"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="693"/>
        <source>Desc&amp;uentos</source>
        <translation>Desc&amp;uentos</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="709"/>
        <source>&amp;Comentarios</source>
        <translation>&amp;Comentarios</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="1366"/>
        <source>0.00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="348"/>
        <source>Referencia:</source>
        <translation>Referencia:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="1421"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="21"/>
        <source>Nuevo albaran de proveedor</source>
        <translation>Nuevo albarÃ¡n de proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="448"/>
        <source>Descripcion:</source>
        <translation>DescripciÃ³n:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="albaranproveedorbase.ui" line="477"/>
        <source>NÂº de albaran:</source>
        <translation>NÂº de albarÃ¡n:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="616"/>
        <source>Fecha de creacion:</source>
        <translation>Fecha de creaciÃ³n:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="558"/>
        <source>Forma de pago:</source>
        <translation>Forma de pago:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="587"/>
        <source>Almacen:</source>
        <translation>AlmacÃ©n:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="763"/>
        <source>Descuentos:</source>
        <translation>Descuentos:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="872"/>
        <source>Base imponible:</source>
        <translation>Base imponible:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="1084"/>
        <source>Impuestos:</source>
        <translation>Impuestos:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="1442"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="978"/>
        <source>I.R.P.F.</source>
        <translation>I.R.P.F.</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="1296"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="1190"/>
        <source>R.E.:</source>
        <translation>R.E.:</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="104"/>
        <source>Guardar albaran</source>
        <translation>Guardar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="119"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="149"/>
        <source>Borrar albaran</source>
        <translation>Borrar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="164"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="210"/>
        <source>Ver pedidos a proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="252"/>
        <source>Generar factura a partir de este albaran</source>
        <translation>Generar factura a partir de este albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="294"/>
        <source>Registrar pago a proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="401"/>
        <source>Mostrar/ocultar cabecera</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedorbase.ui" line="416"/>
        <source>Ctrl+G</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>AlbaranProveedorView</name>
    <message>
        <location filename="albaranproveedorview.cpp" line="305"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="albaranproveedorview.cpp" line="150"/>
        <source>Factura inexistente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranproveedorview.cpp" line="305"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="albaranproveedorview.cpp" line="77"/>
        <source>Error al crear el albaran proveedor</source>
        <translation>Error al crear el albarÃ¡n proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedorview.cpp" line="194"/>
        <source>Albaran de proveedor</source>
        <translation>AlbarÃ¡n de proveedor</translation>
    </message>
    <message>
        <location filename="albaranproveedorview.cpp" line="151"/>
        <source>No existe una factura asociada a este albaran.
Desea crearla?</source>
        <translation>No existe una factura asociada a este albarÃ¡n.(new line)Â¿Desea crearla?</translation>
    </message>
    <message>
        <location filename="albaranproveedorview.cpp" line="303"/>
        <source>Factura de proveedor existente</source>
        <translation>Factura de proveedor existente</translation>
    </message>
    <message>
        <location filename="albaranproveedorview.cpp" line="304"/>
        <source>Existe una factura de este proveedor con la misma referencia que este albaran. Desea abrirla para verificar?</source>
        <translation>Existe una factura de este proveedor con la misma referencia que este albarÃ¡n. Â¿Desea abrirla para verificar?</translation>
    </message>
</context>
<context>
    <name>AlbaranesProveedor</name>
    <message>
        <location filename="albaranesproveedor.cpp" line="233"/>
        <source>Error al borrar albaran de proveedor</source>
        <translation>Error al borrar albarÃ¡n de proveedor</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="203"/>
        <source>Albaranes de proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="218"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
</context>
<context>
    <name>AlbaranesProveedorListBase</name>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="411"/>
        <source>Procesados</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="92"/>
        <source>Nuevo albaran</source>
        <translation>Nuevo albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="129"/>
        <source>Editar albaran</source>
        <translation>Editar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="166"/>
        <source>Borrar albaran</source>
        <translation>Borrar albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="240"/>
        <source>Filtrar albaranes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="280"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="320"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="358"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="434"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="467"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="532"/>
        <source>Total: </source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="17"/>
        <source>Albaranes de proveedor</source>
        <translation>Albaranes de proveedor</translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="255"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="295"/>
        <source>Ctrl+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedorlistbase.ui" line="335"/>
        <source>F5</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>AlbaranesProveedorListSubform</name>
    <message>
        <location filename="albaranesproveedor.cpp" line="249"/>
        <source>ID albaran</source>
        <translation>ID albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="250"/>
        <source>Numero de albaran</source>
        <translation>NÃºmero de albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="256"/>
        <source>ID proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="257"/>
        <source>ID forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="258"/>
        <source>ID almacen</source>
        <translation>ID almacÃ©n</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="259"/>
        <source>Nombre del proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="260"/>
        <source>Nombre del almacen</source>
        <translation>Nombre del almacÃ©n</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="261"/>
        <source>Descripcion de la forma de pago</source>
        <translation>DescripciÃ³n de la forma de pago</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="262"/>
        <source>Base imponible</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="263"/>
        <source>Impuestos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="264"/>
        <source>Total albaran</source>
        <translation>Total albarÃ¡n</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="251"/>
        <source>Descripcion</source>
        <translation>DescripciÃ³n</translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="252"/>
        <source>Referencia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="253"/>
        <source>Fecha</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="254"/>
        <source>Comentario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="albaranesproveedor.cpp" line="255"/>
        <source>Procesado</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Articulo</name>
    <message>
        <location filename="articulo.cpp" line="38"/>
        <source>Identificador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="39"/>
        <source>Codigo</source>
        <translation>CÃ³digo</translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="40"/>
        <source>Nombre del articulo</source>
        <translation>Nombre del artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="41"/>
        <source>Abreviacion</source>
        <translation>AbreviaciÃ³n</translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="42"/>
        <source>Observaciones</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="43"/>
        <source>Incluir en presentaciones</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="44"/>
        <source>Incluir en control de stock</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="45"/>
        <source>Tipo de articulo</source>
        <translation>Tipo de artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="46"/>
        <source>Tipo de I.V.A.</source>
        <translation>Tipo de I.V.A.</translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="47"/>
        <source>Codigo completo</source>
        <translation>CÃ³digo completo</translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="48"/>
        <source>Familia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="49"/>
        <source>Stock</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="50"/>
        <source>Inactivo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulo.cpp" line="51"/>
        <source>P.V.P. base</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ArticuloBase</name>
    <message>
        <location filename="articleeditbase.ui" line="67"/>
        <source>Guardar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="89"/>
        <source>Borrar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="616"/>
        <source>&amp;Datos generales</source>
        <translation>&amp;Datos generales</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="987"/>
        <source>C&amp;omponentes</source>
        <translation>C&amp;omponentes</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="124"/>
        <source>Codigo completo:</source>
        <translation>CÃ³digo completo:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="780"/>
        <source>Subcodigo:</source>
        <translation>SubcÃ³digo:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="878"/>
        <source>Tipo de I.V.A.:</source>
        <translation>Tipo de I.V.A.:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="686"/>
        <source>Cam&amp;biar imagen</source>
        <translation>Cam&amp;biar imagen</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="1003"/>
        <source>Descripcio&amp;n</source>
        <translation>DescripciÃ³&amp;n</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="1050"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="1043"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="16"/>
        <source>Nuevo articulo</source>
        <translation>Nuevo artÃ­culo</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="747"/>
        <source>Codigo del articulo:</source>
        <translation>CÃ³digo del articulo:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="819"/>
        <source>Informacion del articulo:</source>
        <translation>InformaciÃ³n del artÃ­culo:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="957"/>
        <source>Nombre del articulo:</source>
        <translation>Nombre del artÃ­culo:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="932"/>
        <source>Texto para etiqueta:</source>
        <translation>Texto para etiqueta:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="704"/>
        <source>Otros datos:</source>
        <translation>Otros datos:</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="644"/>
        <source>Imagen del articulo:</source>
        <translation>Imagen del artÃ­culo:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="articleeditbase.ui" line="716"/>
        <source>Incluir este artÃ­culo en el catÃ¡logo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="articleeditbase.ui" line="719"/>
        <source>&amp;Incluir en el catÃ¡logo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="articleeditbase.ui" line="726"/>
        <source>Activar el control de stock para este artÃ­culo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="729"/>
        <source>Activar el &amp;control de stock.</source>
        <translation>Activar el &amp;control de stock.</translation>
    </message>
    <message>
        <location filename="articleeditbase.ui" line="911"/>
        <source>P.V.P. s/IVA:</source>
        <translation>P.V.P. s/IVA:</translation>
    </message>
</context>
<context>
    <name>ArticuloList</name>
    <message>
        <location filename="articulolist.cpp" line="355"/>
        <source>Editar articulo</source>
        <translation>Editar artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="356"/>
        <source>Borrar articulo</source>
        <translation>Borrar artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="151"/>
        <source>Esta a punto de borrar un articulo. Estos datos pueden dar problemas.</source>
        <translation>Esta a punto de borrar un artÃ­culo. Estos datos pueden dar problemas.</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="322"/>
        <source>Elija el archivo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="324"/>
        <source>Clientes (*.xml)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="60"/>
        <source>Selector de articulos</source>
        <translation>Selector de artÃ­culos</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="161"/>
        <source>Error al borrar el articulo</source>
        <translation>Error al borrar el artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="144"/>
        <source>Tiene que seleccionar un articulo</source>
        <translation>Tiene que seleccionar un artÃ­culo</translation>
    </message>
</context>
<context>
    <name>ArticuloListBase</name>
    <message>
        <location filename="articleslistbase.ui" line="410"/>
        <source>Exportar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="95"/>
        <source>Nuevo articulo</source>
        <translation>Nuevo artÃ­culo</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="163"/>
        <source>Borrar articulo</source>
        <translation>Borrar artÃ­culo</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="231"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="265"/>
        <source>Filtrar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="302"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="339"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="373"/>
        <source>Exportar articulos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="407"/>
        <source>Importar articulos</source>
        <translation>Importar artÃ­culos</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="442"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="511"/>
        <source>Solo usados</source>
        <translation>SÃ³lo usados</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="524"/>
        <source>S&amp;olo presentables</source>
        <translation>&amp;SÃ³lo presentables</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="527"/>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="17"/>
        <source>Articulos</source>
        <translation>ArtÃ­culos</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="129"/>
        <source>Editar articulo</source>
        <translation>Editar artÃ­culo</translation>
    </message>
    <message>
        <location filename="articleslistbase.ui" line="197"/>
        <source>Imprimir catalogo</source>
        <translation>Imprimir catÃ¡logo</translation>
    </message>
</context>
<context>
    <name>ArticuloListSubForm</name>
    <message>
        <location filename="articulolist.cpp" line="376"/>
        <source>ID articulo</source>
        <translation>ID artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="377"/>
        <source>Codigo completo del articulo</source>
        <translation>CÃ³digo completo del artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="378"/>
        <source>Nombre del articulo</source>
        <translation>Nombre del artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="379"/>
        <source>Descripcion abreviada del articulo</source>
        <translation>DescripciÃ³n abreviada del artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="380"/>
        <source>Observaciones sobre el articulo</source>
        <translation>Observaciones sobre el artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="381"/>
        <source>Descripcion del tipo de articulo</source>
        <translation>DescripciÃ³n del tipo de artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="382"/>
        <source>Descripcion tipo de I.V.A.</source>
        <translation>DescripciÃ³n tipo de I.V.A.</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="383"/>
        <source>P.V.P. articulo</source>
        <translation>P.V.P. artÃ­culo</translation>
    </message>
    <message>
        <location filename="articulolist.cpp" line="384"/>
        <source>Disponible en stock</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ArticuloView</name>
    <message>
        <location filename="articuloview.cpp" line="217"/>
        <source>Borrar articulo</source>
        <translation>Borrar artÃ­culo</translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="218"/>
        <source>Esta a punto de borrar un articulo. Desea continuar?</source>
        <translation>EstÃ¡ a punto de borrar un artÃ­culo. Â¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="219"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="219"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="340"/>
        <source>Imagenes (*.jpg)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="338"/>
        <source>Abrir ventana de archivo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="69"/>
        <source>Error al crear el articulo</source>
        <translation>Error al crear el artÃ­culo</translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="121"/>
        <source>Articulo</source>
        <translation>ArtÃ­culo</translation>
    </message>
    <message>
        <location filename="articuloview.cpp" line="166"/>
        <source>Error en la carga del articulo</source>
        <translation>Error en la carga del artÃ­culo</translation>
    </message>
</context>
<context>
    <name>BusquedaArticuloBase</name>
    <message>
        <location filename="busquedaarticulobase.ui" line="13"/>
        <source>Form1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="busquedaarticulobase.ui" line="99"/>
        <source>Articulo</source>
        <translation>ArtÃ­culo</translation>
    </message>
    <message>
        <location filename="busquedaarticulobase.ui" line="41"/>
        <source>Articulo:</source>
        <translation>ArtÃ­culo:</translation>
    </message>
</context>
<context>
    <name>BusquedaClienteBase</name>
    <message>
        <location filename="busquedaclientebase.ui" line="13"/>
        <source>Form1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="busquedaclientebase.ui" line="129"/>
        <source>Cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="busquedaclientebase.ui" line="47"/>
        <source>Cliente:</source>
        <translation>Cliente:</translation>
    </message>
</context>
<context>
    <name>BusquedaFamiliaBase</name>
    <message>
        <location filename="busquedafamiliabase.ui" line="13"/>
        <source>Form1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="busquedafamiliabase.ui" line="99"/>
        <source>Familia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="busquedafamiliabase.ui" line="41"/>
        <source>Familia:</source>
        <translation>Familia:</translation>
    </message>
</context>
<context>
    <name>BusquedaProveedorBase</name>
    <message>
        <location filename="busquedaproveedorbase.ui" line="16"/>
        <source>Form1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="busquedaproveedorbase.ui" line="92"/>
        <source>Proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="busquedaproveedorbase.ui" line="107"/>
        <source>Proveedor:</source>
        <translation>Proveedor:</translation>
    </message>
</context>
<context>
    <name>BusquedaReferenciaBase</name>
    <message>
        <location filename="busquedareferenciabase.ui" line="30"/>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BusquedaTipoArticuloBase</name>
    <message>
        <location filename="busquedatipoarticulobase.ui" line="13"/>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="busquedatipoarticulobase.ui" line="99"/>
        <source>Tipo de articulo</source>
        <translation>Tipo de artÃ­culo</translation>
    </message>
    <message>
        <location filename="busquedatipoarticulobase.ui" line="41"/>
        <source>Tipo de articulo:</source>
        <translation>Tipo de artÃ­culo:</translation>
    </message>
</context>
<context>
    <name>Cliente</name>
    <message>
        <location filename="cliente.cpp" line="38"/>
        <source>ID cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="39"/>
        <source>Nombre del cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="40"/>
        <source>Nombre alternativo del cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="41"/>
        <source>C.I.F. del cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="42"/>
        <source>Numero cuenta corriente</source>
        <translation>NÃºmero cuenta corriente</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="43"/>
        <source>Direccion</source>
        <translation>DirecciÃ³n</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="44"/>
        <source>Poblacion</source>
        <translation>PoblaciÃ³n</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="45"/>
        <source>Provincia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="46"/>
        <source>Codigo postal</source>
        <translation>CÃ³digo postal</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="47"/>
        <source>Numero de telefono</source>
        <translation>NÃºmero de telÃ©fono</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="48"/>
        <source>Numero de telefono en el trabajo</source>
        <translation>NÃºmero de telÃ©fono en el trabajo</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="49"/>
        <source>Numero de telefono movil</source>
        <translation>NÃºmero de telÃ©fono movil</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="50"/>
        <source>Numero de fax</source>
        <translation>NÃºmero de fax</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="51"/>
        <source>Direccion electronica</source>
        <translation>DirecciÃ³n electrÃ³nica</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="52"/>
        <source>Identificador de presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="53"/>
        <source>Fecha de alta del cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="54"/>
        <source>Fecha de baja del cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="55"/>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="56"/>
        <source>Cliente inactivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="58"/>
        <source>Codigo</source>
        <translation>CÃ³digo</translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="59"/>
        <source>Empresa</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="57"/>
        <source>Regimen fiscal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="60"/>
        <source>Forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cliente.cpp" line="61"/>
        <source>Recargo de Equivalencia</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ClienteBase</name>
    <message>
        <location filename="clientebase.ui" line="17"/>
        <source>Cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="110"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="708"/>
        <source>Pres&amp;upuestos</source>
        <translation>Pres&amp;upuestos</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="724"/>
        <source>Pedidos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="740"/>
        <source>Albaranes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="756"/>
        <source>&amp;Facturas</source>
        <translation>&amp;Facturas</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="772"/>
        <source>Co&amp;bros</source>
        <translation>Co&amp;bros</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="788"/>
        <source>Co&amp;ntratos</source>
        <translation>Co&amp;ntratos</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="882"/>
        <source>Ver</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="890"/>
        <source>Vigentes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="895"/>
        <source>Vencidos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="900"/>
        <source>Todos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="937"/>
        <source>D&amp;ivisiones</source>
        <translation>D&amp;ivisiones</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="95"/>
        <source>Guardar cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="135"/>
        <source>Borrar cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="259"/>
        <source>&amp;Datos generales</source>
        <translation>&amp;Datos generales</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="603"/>
        <source>Nombre comercial:</source>
        <translation>Nombre comercial:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="412"/>
        <source>Direccion:</source>
        <translation>DirecciÃ³n:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="467"/>
        <source>Codigo postal:</source>
        <translation>CÃ³digo postal:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="587"/>
        <source>Poblacion:</source>
        <translation>PoblaciÃ³n:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="428"/>
        <source>Provincia:</source>
        <translation>Provincia:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="687"/>
        <source>Pagina web:</source>
        <translation>PÃ¡gina web:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="672"/>
        <source>Datos bancarios:</source>
        <translation>Datos bancarios:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="926"/>
        <source>Resumen por articulos:</source>
        <translation>Resumen por artÃ­culos:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="1029"/>
        <source>Produ&amp;ctos suministrados</source>
        <translation>Produ&amp;ctos suministrados</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="1142"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="1135"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="629"/>
        <source>Numero de fax:</source>
        <translation>NÃºmero de fax:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="568"/>
        <source>Telefono del trabajo:</source>
        <translation>TelÃ©fono del trabajo:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="555"/>
        <source>Nombre completo:</source>
        <translation>Nombre completo:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="389"/>
        <source>Telefono fijo:</source>
        <translation>TelÃ©fono fijo:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="513"/>
        <source>Correo electronico:</source>
        <translation>Correo electrÃ³nico:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="438"/>
        <source>Codigo de cliente:</source>
        <translation>CÃ³digo de cliente:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="497"/>
        <source>Empresa:</source>
        <translation>Empresa:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="616"/>
        <source>Telefono movil:</source>
        <translation>TelÃ©fono mÃ³vil:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="645"/>
        <source>C.I.F./N.I.F./N.I.E.:</source>
        <translation>C.I.F./N.I.F./N.I.E.:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="287"/>
        <source>Comentarios:</source>
        <translation>Comentarios:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="324"/>
        <source>Datos de comercio electronico:</source>
        <translation>Datos de comercio electrÃ³nico:</translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="354"/>
        <source>Regimen fiscal</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="370"/>
        <source>Forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="700"/>
        <source>Aplicar Recargo de Equivalencia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="175"/>
        <source>Imprimir informe</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="212"/>
        <source>Imprimir</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="150"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientebase.ui" line="227"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ClienteListSubform</name>
    <message>
        <location filename="clientslist.cpp" line="226"/>
        <source>ID cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="229"/>
        <source>Nombre de cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="230"/>
        <source>Nombre alternativo del cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="228"/>
        <source>C.I.F.</source>
        <translation>C.I.F.</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="231"/>
        <source>Numero cuenta corriente</source>
        <translation>NÃºmero cuenta corriente</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="232"/>
        <source>Direccion</source>
        <translation>DirecciÃ³n</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="233"/>
        <source>Poblacion</source>
        <translation>PoblaciÃ³n</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="234"/>
        <source>Codigo postal</source>
        <translation>CÃ³digo postal</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="235"/>
        <source>Numero de telefono</source>
        <translation>NÃºmero de telÃ©fono</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="236"/>
        <source>Numero de fax</source>
        <translation>NÃºmero de fax</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="237"/>
        <source>Direccion de correo electronica</source>
        <translation>DirecciÃ³n de correo electrÃ³nica</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="238"/>
        <source>Direccion URL</source>
        <translation>DirecciÃ³n URL</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="240"/>
        <source>Fecha de alta del cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="241"/>
        <source>Fecha de baja del cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="242"/>
        <source>Comentarios</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="227"/>
        <source>Codigo</source>
        <translation>CÃ³digo</translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="239"/>
        <source>Empresa</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ClienteView</name>
    <message>
        <location filename="clienteview.cpp" line="77"/>
        <source>Error al crear el cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clienteview.cpp" line="112"/>
        <source>Cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clienteview.cpp" line="132"/>
        <source>Error al cargar el cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clienteview.cpp" line="228"/>
        <source>Edicion de clientes</source>
        <translation>EdiciÃ³n de clientes</translation>
    </message>
    <message>
        <location filename="clienteview.cpp" line="230"/>
        <source>Esta a punto de borrar un cliente.
Esta seguro que desea borrarlo?</source>
        <translation>Esta a punto de borrar un cliente.(new line)Â¿Esta seguro que desea borrarlo?</translation>
    </message>
</context>
<context>
    <name>ClientsList</name>
    <message>
        <location filename="clientslist.cpp" line="201"/>
        <source>Elija el archivo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="203"/>
        <source>Clientes (*.xml)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="54"/>
        <source>Selector de clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="164"/>
        <source>Error al borrar un cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslist.cpp" line="130"/>
        <source>Listado de Clientes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientsListBase</name>
    <message>
        <location filename="clientslistbase.ui" line="17"/>
        <source>Clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="253"/>
        <source>Exportar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="275"/>
        <source>Importar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="344"/>
        <source>Pro&amp;cesados</source>
        <translation>Pro&amp;cesados</translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="68"/>
        <source>Nuevo cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="90"/>
        <source>Editar cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="112"/>
        <source>Borrar cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="134"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="178"/>
        <source>Filtrar clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="203"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="228"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="250"/>
        <source>Exportar clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="272"/>
        <source>Importar clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="307"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="clientslistbase.ui" line="156"/>
        <source>Informe Compras/Ventas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Cobro</name>
    <message>
        <location filename="cobro.cpp" line="36"/>
        <source>ID cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobro.cpp" line="37"/>
        <source>ID cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobro.cpp" line="38"/>
        <source>Prevision de cobro</source>
        <translation>PrevisiÃ³n de cobro</translation>
    </message>
    <message>
        <location filename="cobro.cpp" line="39"/>
        <source>Fecha de cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobro.cpp" line="40"/>
        <source>Referencia del cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobro.cpp" line="41"/>
        <source>Cantidad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobro.cpp" line="42"/>
        <source>Comentarios</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CobroBase</name>
    <message>
        <location filename="cobrobase.ui" line="233"/>
        <source>Guardar cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="270"/>
        <source>Borrar cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="316"/>
        <source>Referencia:</source>
        <translation>Referencia:</translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="68"/>
        <source>Prevision</source>
        <translation>PrevisiÃ³n</translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="75"/>
        <source>Fecha cobro:</source>
        <translation>Fecha cobro:</translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="123"/>
        <source>Total cobro:</source>
        <translation>Total cobro:</translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="157"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="164"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="14"/>
        <source>Nuevo cobro a cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="101"/>
        <source>Descripcion del cobro:</source>
        <translation>DescripciÃ³n del cobro:</translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="248"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobrobase.ui" line="285"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CobroView</name>
    <message>
        <location filename="cobroview.cpp" line="51"/>
        <source>Error al crear el cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroview.cpp" line="88"/>
        <source>Cobro</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CobrosList</name>
    <message>
        <location filename="cobroslist.cpp" line="237"/>
        <source>Editar cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="238"/>
        <source>Borrar cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="222"/>
        <source>Debe seleccionar una fila primero</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="182"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="167"/>
        <source>Cobros a clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="196"/>
        <source>Error al borrar el cobro a cliente</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CobrosListBase</name>
    <message>
        <location filename="cobroslistbase.ui" line="92"/>
        <source>Nuevo cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="129"/>
        <source>Editar cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="166"/>
        <source>Borrar cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="240"/>
        <source>Filtrar cobros</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="280"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="320"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="371"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="416"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="449"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="574"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="500"/>
        <source>Cobros Previstos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="507"/>
        <source>Cobros Efectivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="17"/>
        <source>Cobros a clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="255"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="295"/>
        <source>Ctrl+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslistbase.ui" line="335"/>
        <source>F5</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CobrosListSubForm</name>
    <message>
        <location filename="cobroslist.cpp" line="260"/>
        <source>ID cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="261"/>
        <source>Nombre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="262"/>
        <source>C.I.F.</source>
        <translation>C.I.F.</translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="263"/>
        <source>Numero de telefono</source>
        <translation>NÃºmero de telÃ©fono</translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="264"/>
        <source>Direccion de correo electronico</source>
        <translation>DirecciÃ³n de correo electrÃ³nica</translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="265"/>
        <source>Fecha de cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="266"/>
        <source>Cantidad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="267"/>
        <source>Referencia del cobro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="268"/>
        <source>Prevision de cobro</source>
        <translation>PrevisiÃ³n de cobro</translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="269"/>
        <source>Comentarios</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="270"/>
        <source>ID trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="271"/>
        <source>Nombre del trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="272"/>
        <source>Apellidos del trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="cobroslist.cpp" line="259"/>
        <source>ID cobro</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FPagoBase</name>
    <message>
        <location filename="fpagobase.ui" line="405"/>
        <source>tipoplazoprimerpago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="346"/>
        <source>tipoplazoentrerecibofpago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="445"/>
        <source>&amp;Cerrar</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="370"/>
        <source>Nombre:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="302"/>
        <source>Plazo primer recibo (dias):</source>
        <translation>Plazo primer recibo (dÃ­as):</translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="274"/>
        <source>Descuento:</source>
        <translation>Descuento:</translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="242"/>
        <source>Numero de plazos:</source>
        <translation>NÃºmero de plazos:</translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="210"/>
        <source>Plazo entre recibos (dias):</source>
        <translation>Plazo entre recibos (dÃ­as):</translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="60"/>
        <source>Nueva forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="82"/>
        <source>Borrar forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="104"/>
        <source>Guardar forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="16"/>
        <source>Formas de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="182"/>
        <source>Informacion de la forma de pago:</source>
        <translation>InformaciÃ³n de la forma de pago:</translation>
    </message>
</context>
<context>
    <name>FPagoView</name>
    <message>
        <location filename="fpagoview.cpp" line="118"/>
        <source>Guardar forma de pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="fpagoview.cpp" line="119"/>
        <source>Desea guardar los cambios.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Factura</name>
    <message>
        <location filename="factura.cpp" line="37"/>
        <source>Id factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="38"/>
        <source>Id cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="39"/>
        <source>Id almacen</source>
        <translation>Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="factura.cpp" line="40"/>
        <source>Numero factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="41"/>
        <source>Ffactura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="42"/>
        <source>Procesada factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="43"/>
        <source>Codigo serie factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="44"/>
        <source>Comentario factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="45"/>
        <source>Referencia factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="46"/>
        <source>Descripcion factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="47"/>
        <source>Id trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="factura.cpp" line="48"/>
        <source>Id formad de pago</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FacturaBase</name>
    <message>
        <location filename="facturabase.ui" line="606"/>
        <source>Procesada</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="765"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="790"/>
        <source>Desc&amp;uentos</source>
        <translation>Desc&amp;uentos</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="806"/>
        <source>&amp;Comentarios</source>
        <translation>&amp;Comentarios</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="1463"/>
        <source>0.00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="105"/>
        <source>Guardar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="139"/>
        <source>Borrar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="173"/>
        <source>Imprimir factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="366"/>
        <source>Referencia:</source>
        <translation>Referencia:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="455"/>
        <source>Descripcion:</source>
        <translation>DescripciÃ³n:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="521"/>
        <source>Numero de factura:</source>
        <translation>NÃºmero de factura:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="666"/>
        <source>Serie:</source>
        <translation>Serie:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="634"/>
        <source>Forma de pago:</source>
        <translation>Forma de pago:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="734"/>
        <source>Fecha de creacion:</source>
        <translation>Fecha de creaciÃ³n:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="695"/>
        <source>Almacen:</source>
        <translation>AlmacÃ©n:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="1533"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="1515"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="260"/>
        <source>Agregar albaran a la factura</source>
        <translation>Agregar albarÃ¡n a la factura</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="419"/>
        <source>Mostrar/ocultar cabecera</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="860"/>
        <source>Descuentos:</source>
        <translation>Descuentos:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="969"/>
        <source>Base imponible:</source>
        <translation>Base imponible:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="1075"/>
        <source>I.R.P.F.:</source>
        <translation>I.R.P.F.:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="1181"/>
        <source>Impuestos:</source>
        <translation>Impuestos:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="1287"/>
        <source>R.E.:</source>
        <translation>R.E.:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="1393"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="14"/>
        <source>Nueva factura a cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="226"/>
        <source>Ver albaranes con la misma referencia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturabase.ui" line="294"/>
        <source>Registrar cobro a cliente</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FacturaProveedor</name>
    <message>
        <location filename="facturap.cpp" line="38"/>
        <source>Id facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="39"/>
        <source>Id proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="40"/>
        <source>Numero</source>
        <translation>NÃºmero</translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="41"/>
        <source>Fecha</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="42"/>
        <source>Procesada facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="43"/>
        <source>Comentario facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="44"/>
        <source>Referencia facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="45"/>
        <source>Descripcion facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="46"/>
        <source>Id trabajador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="47"/>
        <source>Id forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="233"/>
        <source>Codigo</source>
        <translation type="unfinished">CÃ³digo</translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="234"/>
        <source>Concepto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="235"/>
        <source>Cant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="236"/>
        <source>Precio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="237"/>
        <source>Desc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="283"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="281"/>
        <source>Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="282"/>
        <source>Porcentaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="313"/>
        <source>Base </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="326"/>
        <source>IVA </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturap.cpp" line="329"/>
        <source>Total </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FacturaProveedorBase</name>
    <message>
        <location filename="facturapbase.ui" line="419"/>
        <source>Procesada</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="584"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="1273"/>
        <source>0.00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="189"/>
        <source>Guardar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="89"/>
        <source>Borrar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="461"/>
        <source>Forma de pago:</source>
        <translation>Forma de pago:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="532"/>
        <source>Descripcion:</source>
        <translation>DescripciÃ³n:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="1332"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="1325"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="490"/>
        <source>Fecha de factura:</source>
        <translation>Fecha de factura:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="600"/>
        <source>Descuen&amp;tos</source>
        <translation>Descuen&amp;tos</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="616"/>
        <source>Comentario&amp;s</source>
        <translation>Comentario&amp;s</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="670"/>
        <source>Descuentos:</source>
        <translation>Descuentos:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="779"/>
        <source>Base imponible:</source>
        <translation>Base imponible:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="991"/>
        <source>Impuestos:</source>
        <translation>Impuestos:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="1203"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="14"/>
        <source>Nueva factura de proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="167"/>
        <source>Referencia de la factura:</source>
        <translation>Referencia de la factura:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="facturapbase.ui" line="370"/>
        <source>NÂº de factura:</source>
        <translation>NÂº de factura:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="104"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="129"/>
        <source>Ver albaranes con la misma referencia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="204"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="263"/>
        <source>Registrar pago a proveedor</source>
        <translation>Registrar pago a proveedor</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="323"/>
        <source>Mostrar/ocultar cabecera</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="338"/>
        <source>Ctrl+G</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="885"/>
        <source>I.R.P.F.:</source>
        <translation>I.R.P.F.:</translation>
    </message>
    <message>
        <location filename="facturapbase.ui" line="1097"/>
        <source>R.E.:</source>
        <translation>R.E.:</translation>
    </message>
</context>
<context>
    <name>FacturaProveedorView</name>
    <message>
        <location filename="facturapview.cpp" line="143"/>
        <source>Factura de proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapview.cpp" line="69"/>
        <source>Error al crear la factura proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturapview.cpp" line="174"/>
        <source>Error al guardar la factura proveedor</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FacturaView</name>
    <message>
        <location filename="facturaview.cpp" line="150"/>
        <source>Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaview.cpp" line="191"/>
        <source>ALBARAN: Num </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaview.cpp" line="81"/>
        <source>Error al crear la factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaview.cpp" line="191"/>
        <source>Ref:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaview.cpp" line="191"/>
        <source>Fecha:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FacturasList</name>
    <message>
        <location filename="facturaslist.cpp" line="198"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="184"/>
        <source>Facturas a clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="212"/>
        <source>Error al borrar la factura a cliente</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FacturasListBase</name>
    <message>
        <location filename="facturaslistbase.ui" line="504"/>
        <source>Pro&amp;cesada</source>
        <translation>Pro&amp;cesada</translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="507"/>
        <source>Alt+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="92"/>
        <source>Nueva factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="129"/>
        <source>Editar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="166"/>
        <source>Borrar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="240"/>
        <source>Filtrar facturas</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="280"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="320"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="379"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="514"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="524"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="610"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="17"/>
        <source>Facturas a clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="255"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="295"/>
        <source>Ctrl+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturaslistbase.ui" line="335"/>
        <source>F5</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FacturasListSubform</name>
    <message>
        <location filename="facturaslist.cpp" line="232"/>
        <source>Ref factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="231"/>
        <source>Id factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="238"/>
        <source>Codigo almacen</source>
        <translation type="unfinished">CÃ³digo almacÃ©n</translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="237"/>
        <source>Nombre cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="239"/>
        <source>Contact factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="240"/>
        <source>Telefono factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="241"/>
        <source>Comentario factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="242"/>
        <source>Id trabajador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="243"/>
        <source>Id cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="244"/>
        <source>Id almacen</source>
        <translation type="unfinished">Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="245"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="246"/>
        <source>Base imponible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="247"/>
        <source>Impuestos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="236"/>
        <source>CIF cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="233"/>
        <source>Serie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="234"/>
        <source>Numero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturaslist.cpp" line="235"/>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FacturasProveedorList</name>
    <message>
        <location filename="facturasplist.cpp" line="160"/>
        <source>Error al cargar la factura proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="191"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="202"/>
        <source>Error al borrar la factura de proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="213"/>
        <source>Facturas de proveedores</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FacturasProveedorListBase</name>
    <message>
        <location filename="facturasplistbase.ui" line="511"/>
        <source>Procesa&amp;da</source>
        <translation>Procesa&amp;da</translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="514"/>
        <source>Alt+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="92"/>
        <source>Nueva factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="129"/>
        <source>Editar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="166"/>
        <source>Borrar factura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="240"/>
        <source>Filtrar facturas</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="280"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="320"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="382"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="435"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="468"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="566"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="17"/>
        <source>Facturas de proveedores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="255"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="295"/>
        <source>Ctrl+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="facturasplistbase.ui" line="335"/>
        <source>F5</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FacturasProveedorListSubform</name>
    <message>
        <location filename="facturasplist.cpp" line="230"/>
        <source>Nombre proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="235"/>
        <source>Id trabajador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="236"/>
        <source>Id proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="237"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="238"/>
        <source>Base imponible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="239"/>
        <source>Impuestos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="227"/>
        <source>Referencia factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="228"/>
        <source>Id factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="229"/>
        <source>Numero factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="231"/>
        <source>Fecha factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="232"/>
        <source>Persona de contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="233"/>
        <source>Telefono factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="facturasplist.cpp" line="234"/>
        <source>Comentario factura</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FamiliasView</name>
    <message>
        <location filename="familiasview.cpp" line="398"/>
        <source>Nombre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="397"/>
        <source>Codigo</source>
        <translation>CÃ³digo</translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="45"/>
        <source>Descripcion</source>
        <translation>DescripciÃ³n</translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="45"/>
        <source>Id familia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="45"/>
        <source>Codigo completo</source>
        <translation>CÃ³digo completo</translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="222"/>
        <source>Guardar familia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="223"/>
        <source>Desea guardar los cambios?</source>
        <translation>Â¿Desea guardar los cambios?</translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="338"/>
        <source>Debe seleccionar una familia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="317"/>
        <source>Borrar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="318"/>
        <source>Desea eliminar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasview.cpp" line="327"/>
        <source>No se ha podido borrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InformeCliente</name>
    <message>
        <location filename="informereferencia.cpp" line="379"/>
        <source>Articulo</source>
        <translation type="unfinished">ArtÃ­culo</translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="417"/>
        <source>Pres.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="465"/>
        <source>Pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="466"/>
        <source>Entregado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="467"/>
        <source>Facturado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="421"/>
        <source>Cobrado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="468"/>
        <source>Pagado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InformeClientes</name>
    <message>
        <location filename="informereferencia.cpp" line="586"/>
        <source>Articulo</source>
        <translation type="unfinished">ArtÃ­culo</translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="619"/>
        <source>Pres.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="667"/>
        <source>Pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="668"/>
        <source>Entregado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="669"/>
        <source>Facturado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="623"/>
        <source>Cobrado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="670"/>
        <source>Pagado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InformeReferencia</name>
    <message>
        <location filename="informereferencia.cpp" line="134"/>
        <source>Articulo</source>
        <translation type="unfinished">ArtÃ­culo</translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="171"/>
        <source>Pres.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="219"/>
        <source>Pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="220"/>
        <source>Entregado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="221"/>
        <source>Facturado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="175"/>
        <source>Cobrado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="informereferencia.cpp" line="222"/>
        <source>Pagado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Inventario</name>
    <message>
        <location filename="inventario.cpp" line="34"/>
        <source>Identificador inventario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventario.cpp" line="35"/>
        <source>Fecha inventario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventario.cpp" line="36"/>
        <source>Nombre inventario</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InventarioBase</name>
    <message>
        <location filename="inventariobase.ui" line="14"/>
        <source>Inventario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="92"/>
        <source>Procesado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="140"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="227"/>
        <source>Guardar inventario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="261"/>
        <source>Borrar inventario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="314"/>
        <source>Pregenerar inventario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="29"/>
        <source>Descripcion:</source>
        <translation>DescripciÃ³n:</translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="39"/>
        <source>Fecha creacion:</source>
        <translation>Fecha creaciÃ³n:</translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="127"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="inventariobase.ui" line="120"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
</context>
<context>
    <name>InventarioView</name>
    <message>
        <location filename="inventarioview.cpp" line="76"/>
        <source>Borrar inventario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventarioview.cpp" line="77"/>
        <source>Esta a punto de borrar un inventario. Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventarioview.cpp" line="78"/>
        <source>Si</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventarioview.cpp" line="78"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventarioview.cpp" line="55"/>
        <source>Tiene que escribir una descripcion de inventario antes de guardar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InventariosBase</name>
    <message>
        <location filename="inventariosbase.ui" line="89"/>
        <source>Nuevo inventario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariosbase.ui" line="123"/>
        <source>Editar inventario</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariosbase.ui" line="17"/>
        <source>Listado de inventarios</source>
        <translation></translation>
    </message>
    <message>
        <location filename="inventariosbase.ui" line="157"/>
        <source>Borrar inventario</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InventariosSubForm</name>
    <message>
        <location filename="inventariosview.cpp" line="107"/>
        <source>Id inventario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventariosview.cpp" line="108"/>
        <source>Nombre del inventario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inventariosview.cpp" line="109"/>
        <source>Fecha del inventario</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InventariosView</name>
    <message>
        <location filename="inventariosview.cpp" line="85"/>
        <source>Tiene que seleccionar un inventario</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListAlmacenBase</name>
    <message>
        <location filename="listalmacenbase.ui" line="16"/>
        <source>Almacenes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="listalmacenbase.ui" line="55"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="listalmacenbase.ui" line="62"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
</context>
<context>
    <name>ListAlmacenSubForm</name>
    <message>
        <location filename="listalmacenview.cpp" line="80"/>
        <source>Id almacen</source>
        <translation type="unfinished">Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="listalmacenview.cpp" line="81"/>
        <source>Codigo almacen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listalmacenview.cpp" line="82"/>
        <source>Nombre almacen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListCompArticuloView</name>
    <message>
        <location filename="comparticulolistview.cpp" line="38"/>
        <source>Codigo completo del articulo</source>
        <translation type="unfinished">CÃ³digo completo del artÃ­culo</translation>
    </message>
    <message>
        <location filename="comparticulolistview.cpp" line="39"/>
        <source>Nombre del articulo</source>
        <translation type="unfinished">Nombre del artÃ­culo</translation>
    </message>
    <message>
        <location filename="comparticulolistview.cpp" line="40"/>
        <source>Cantidad de componente de articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="comparticulolistview.cpp" line="41"/>
        <source>ID componente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="comparticulolistview.cpp" line="42"/>
        <source>ID articulo</source>
        <translation type="unfinished">ID artÃ­culo</translation>
    </message>
</context>
<context>
    <name>ListConfiguracionBase</name>
    <message>
        <location filename="listconfiguracionbase.ui" line="14"/>
        <source>Configuraciones</source>
        <translation></translation>
    </message>
    <message>
        <location filename="listconfiguracionbase.ui" line="53"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="listconfiguracionbase.ui" line="60"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
</context>
<context>
    <name>ListConfiguracionSubForm</name>
    <message>
        <location filename="listconfiguracionview.cpp" line="72"/>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listconfiguracionview.cpp" line="73"/>
        <source>Valor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListControlStockView</name>
    <message>
        <location filename="listcontrolstockview.cpp" line="28"/>
        <source>Punteado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcontrolstockview.cpp" line="29"/>
        <source>Codigo almacen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcontrolstockview.cpp" line="30"/>
        <source>Nombre almacen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcontrolstockview.cpp" line="31"/>
        <source>Codigo completo articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcontrolstockview.cpp" line="33"/>
        <source>Stock anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcontrolstockview.cpp" line="35"/>
        <source>Id articulo</source>
        <translation type="unfinished">Id artÃ­culo</translation>
    </message>
    <message>
        <location filename="listcontrolstockview.cpp" line="34"/>
        <source>Stock revisado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListDescuentoAlbaranClienteView</name>
    <message>
        <location filename="listdescalbaranclienteview.cpp" line="36"/>
        <source>Idd albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescalbaranclienteview.cpp" line="37"/>
        <source>Conceptd albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescalbaranclienteview.cpp" line="38"/>
        <source>Proporciond albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescalbaranclienteview.cpp" line="39"/>
        <source>Id albaran</source>
        <translation type="unfinished">Id albarÃ¡n</translation>
    </message>
</context>
<context>
    <name>ListDescuentoAlbaranProvView</name>
    <message>
        <location filename="listdescalbaranprovview.cpp" line="36"/>
        <source>Idd albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescalbaranprovview.cpp" line="37"/>
        <source>Conceptd albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescalbaranprovview.cpp" line="38"/>
        <source>Proporciond albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescalbaranprovview.cpp" line="39"/>
        <source>Id albaranp</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListDescuentoFacturaProvView</name>
    <message>
        <location filename="listdescfacturaprovview.cpp" line="36"/>
        <source>Idd facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescfacturaprovview.cpp" line="37"/>
        <source>Conceptd facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescfacturaprovview.cpp" line="38"/>
        <source>Proporciond facturap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescfacturaprovview.cpp" line="39"/>
        <source>Id facturap</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListDescuentoFacturaView</name>
    <message>
        <location filename="listdescfacturaview.cpp" line="36"/>
        <source>iddfactura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescfacturaview.cpp" line="37"/>
        <source>conceptdfactura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescfacturaview.cpp" line="38"/>
        <source>proporciondfactura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescfacturaview.cpp" line="39"/>
        <source>idfactura</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListDescuentoPedidoClienteView</name>
    <message>
        <location filename="listdescpedidoclienteview.cpp" line="36"/>
        <source>Idd pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpedidoclienteview.cpp" line="37"/>
        <source>Conceptd pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpedidoclienteview.cpp" line="38"/>
        <source>Proporciond pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpedidoclienteview.cpp" line="39"/>
        <source>Id pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListDescuentoPedidoProveedorView</name>
    <message>
        <location filename="listdescpedidoproveedorview.cpp" line="36"/>
        <source>Idd pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpedidoproveedorview.cpp" line="37"/>
        <source>Conceptd pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpedidoproveedorview.cpp" line="38"/>
        <source>Proporciond pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpedidoproveedorview.cpp" line="39"/>
        <source>Id pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListDescuentoPresupuestoView</name>
    <message>
        <location filename="listdescpresupuestoview.cpp" line="36"/>
        <source>Idd pedidocliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpresupuestoview.cpp" line="37"/>
        <source>Conceptod presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpresupuestoview.cpp" line="38"/>
        <source>Proporciond presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listdescpresupuestoview.cpp" line="39"/>
        <source>Id presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinAlbaranClienteView</name>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="35"/>
        <source>Id articulo</source>
        <translation type="unfinished">Id artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="36"/>
        <source>Codigo completo articulo</source>
        <translation type="unfinished">CÃ³digo completo artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="37"/>
        <source>Nombre articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="38"/>
        <source>Numerol albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="39"/>
        <source>Descripcionl albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="40"/>
        <source>Cantidadl albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="41"/>
        <source>PVPl albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="42"/>
        <source>IVAl albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="44"/>
        <source>Descontl albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="45"/>
        <source>Id albaran</source>
        <translation type="unfinished">Id albarÃ¡n</translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="46"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranclienteview.cpp" line="43"/>
        <source>% Recargo E.Q.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinAlbaranProveedorView</name>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="35"/>
        <source>Id articulo</source>
        <translation type="unfinished">Id artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="36"/>
        <source>Codigo completo articulo</source>
        <translation type="unfinished">CÃ³digo completo artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="37"/>
        <source>Nombre articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="38"/>
        <source>Numerol albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="39"/>
        <source>Descripcionl albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="40"/>
        <source>Cantidadl albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="41"/>
        <source>PVPl albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="42"/>
        <source>IVAl albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="44"/>
        <source>Descontl albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="45"/>
        <source>Id albaranp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="46"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinalbaranproveedorview.cpp" line="43"/>
        <source>Recargo albaranp</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinFacturaProveedorView</name>
    <message>
        <location filename="listlinfacturapview.cpp" line="36"/>
        <source>Articulo</source>
        <translation type="unfinished">ArtÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="37"/>
        <source>Codigo completo</source>
        <translation type="unfinished">CÃ³digo completo</translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="38"/>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="39"/>
        <source>Linea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="40"/>
        <source>Descripcion</source>
        <translation type="unfinished">DescripciÃ³n</translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="41"/>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="42"/>
        <source>P.V.P.</source>
        <translation type="unfinished">P.V.P.</translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="43"/>
        <source>% I.V.A.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="45"/>
        <source>Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="46"/>
        <source>Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="44"/>
        <source>% Recargo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturapview.cpp" line="47"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinFacturaView</name>
    <message>
        <location filename="listlinfacturaview.cpp" line="35"/>
        <source>Id articulo</source>
        <translation type="unfinished">Id artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="36"/>
        <source>Codigo completo articulo</source>
        <translation type="unfinished">CÃ³digo completo artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="37"/>
        <source>Nombre articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="38"/>
        <source>Idl factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="39"/>
        <source>Descripcionl factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="40"/>
        <source>Cantidadl factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="41"/>
        <source>PVPl factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="42"/>
        <source>IVAl factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="44"/>
        <source>Descuentol factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="45"/>
        <source>Id factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="43"/>
        <source>% Recargo E.Q.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinfacturaview.cpp" line="46"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinPedidoClienteView</name>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="35"/>
        <source>Puntl pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="36"/>
        <source>Id articulo</source>
        <translation type="unfinished">Id artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="37"/>
        <source>Codigo completo articulo</source>
        <translation type="unfinished">CÃ³digo completo artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="38"/>
        <source>Nombre articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="39"/>
        <source>Numl pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="40"/>
        <source>Descl pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="41"/>
        <source>Cantl pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="42"/>
        <source>PVPl pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="43"/>
        <source>IVAl pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="45"/>
        <source>Descuentol pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="46"/>
        <source>Id pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="44"/>
        <source>% Recargo E.Q.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoclienteview.cpp" line="47"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinPedidoProveedorView</name>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="34"/>
        <source>puntlpedidoproveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="35"/>
        <source>Id articulo</source>
        <translation type="unfinished">Id artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="36"/>
        <source>Codigo completo articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="37"/>
        <source>Nombre articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="38"/>
        <source>Numerol pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="39"/>
        <source>Descripcionl pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="40"/>
        <source>Cantidadl pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="41"/>
        <source>PVPl pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="42"/>
        <source>IVAl pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="44"/>
        <source>Descuentol pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="45"/>
        <source>Id pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="46"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpedidoproveedorview.cpp" line="43"/>
        <source>Recargo pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinPresupuestoView</name>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="36"/>
        <source>Id articulo</source>
        <translation type="unfinished">Id artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="37"/>
        <source>Codigo completo</source>
        <translation type="unfinished">CÃ³digo completo</translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="38"/>
        <source>Nombre del articulo</source>
        <translation type="unfinished">Nombre del artÃ­culo</translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="39"/>
        <source>No de linea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="40"/>
        <source>Descripcion presupuesto</source>
        <translation type="unfinished">DescripciÃ³n presupuesto</translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="41"/>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="42"/>
        <source>Precio de venta s/IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="43"/>
        <source>% IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="44"/>
        <source>% Recargo E.Q.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="45"/>
        <source>% Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="46"/>
        <source>Id presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinpresupuestoview.cpp" line="47"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListProvinciasBase</name>
    <message>
        <location filename="listprovinciasbase.ui" line="16"/>
        <source>Provincias</source>
        <translation></translation>
    </message>
    <message>
        <location filename="listprovinciasbase.ui" line="135"/>
        <source>&amp;Cerrar</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="listprovinciasbase.ui" line="70"/>
        <source>&amp;Nuevo</source>
        <translation>&amp;Nuevo</translation>
    </message>
    <message>
        <location filename="listprovinciasbase.ui" line="77"/>
        <source>&amp;Borrar</source>
        <translation>&amp;Borrar</translation>
    </message>
    <message>
        <location filename="listprovinciasbase.ui" line="84"/>
        <source>&amp;Guardar</source>
        <translation>&amp;Guardar</translation>
    </message>
</context>
<context>
    <name>ListProvinciasView</name>
    <message>
        <location filename="listprovinciasview.cpp" line="64"/>
        <source>Provincia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListSerieFacturaBase</name>
    <message>
        <location filename="listseriefacturabase.ui" line="55"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="listseriefacturabase.ui" line="62"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="listseriefacturabase.ui" line="16"/>
        <source>Series de factura</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ListSerieFacturaSubForm</name>
    <message>
        <location filename="listseriefacturaview.cpp" line="70"/>
        <source>Codigo serie factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listseriefacturaview.cpp" line="71"/>
        <source>Descripcion serie factura</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Pago</name>
    <message>
        <location filename="pago.cpp" line="33"/>
        <source>Id pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pago.cpp" line="34"/>
        <source>Id proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pago.cpp" line="35"/>
        <source>Previcion de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pago.cpp" line="36"/>
        <source>Fecha de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pago.cpp" line="37"/>
        <source>Referencia de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pago.cpp" line="38"/>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pago.cpp" line="39"/>
        <source>Comentario del pago</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagoBase</name>
    <message>
        <location filename="pagobase.ui" line="99"/>
        <source>Guardar pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="133"/>
        <source>Borrar pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="176"/>
        <source>Referencia:</source>
        <translation>Referencia:</translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="240"/>
        <source>Total pago:</source>
        <translation>Total pago:</translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="16"/>
        <source>Nuevo pago a proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="280"/>
        <source>0.00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="301"/>
        <source>Descripcion del pago:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="314"/>
        <source>Fecha de pago:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="360"/>
        <source>Provision de fondos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="393"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished">&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="pagobase.ui" line="400"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished">&amp;Cancelar</translation>
    </message>
</context>
<context>
    <name>PagoView</name>
    <message>
        <location filename="pagoview.cpp" line="53"/>
        <source>Error al crear el pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoview.h" line="77"/>
        <source>Pago</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagosList</name>
    <message>
        <location filename="pagoslist.cpp" line="147"/>
        <source>Editar pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="148"/>
        <source>Borrar pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="193"/>
        <source>Error al borrar el pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="181"/>
        <source>Debe seleccionar una linea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="172"/>
        <source>Pagos a proveedores</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagosListBase</name>
    <message>
        <location filename="pagoslistbase.ui" line="88"/>
        <source>Nuevo pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="122"/>
        <source>Editar pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="156"/>
        <source>Borrar pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="190"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="224"/>
        <source>Filtrar pagos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="261"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="298"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="346"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="467"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="500"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="565"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="399"/>
        <source>Pagos Efectivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="406"/>
        <source>Previsiones de Pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslistbase.ui" line="17"/>
        <source>Pagos a proveedores</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagosListSubForm</name>
    <message>
        <location filename="pagoslist.cpp" line="205"/>
        <source>Id pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="206"/>
        <source>Id proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="207"/>
        <source>Nombre proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="208"/>
        <source>C.I.F. proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="209"/>
        <source>Telefono proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="210"/>
        <source>Email proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="211"/>
        <source>Fecha de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="212"/>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="213"/>
        <source>Referencia de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="214"/>
        <source>Prevision pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="215"/>
        <source>Comentario pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="216"/>
        <source>Id trabajador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="217"/>
        <source>Nombre de trabajador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagoslist.cpp" line="218"/>
        <source>Apellidos trabajador</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PedidoCliente</name>
    <message>
        <location filename="pedidocliente.cpp" line="34"/>
        <source>Identificador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="35"/>
        <source>Cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="36"/>
        <source>Almacen</source>
        <translation>AlmacÃ©n</translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="37"/>
        <source>Numero pedido cliente</source>
        <translation>NÃºmero pedido cliente</translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="38"/>
        <source>Identificador presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="39"/>
        <source>Fecha</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="40"/>
        <source>Forma pago</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="41"/>
        <source>Trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="42"/>
        <source>Contacto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="43"/>
        <source>Telefono</source>
        <translation>TelÃ©fono</translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="44"/>
        <source>Comentarios</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="45"/>
        <source>Procesado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidocliente.cpp" line="46"/>
        <source>Referencia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="251"/>
        <source>Total</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="249"/>
        <source>Descuento</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="250"/>
        <source>Porcentaje</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="281"/>
        <source>Base </source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="294"/>
        <source>Iva </source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="297"/>
        <source>Total </source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PedidoClienteBase</name>
    <message>
        <location filename="pedidoclientebase.ui" line="730"/>
        <source>Procesado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="755"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="771"/>
        <source>Desc&amp;uentos</source>
        <translation>Desc&amp;uentos</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="787"/>
        <source>&amp;Comentarios</source>
        <translation>&amp;Comentarios</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="1444"/>
        <source>0.00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="89"/>
        <source>Guardar pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="123"/>
        <source>Borrar pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="157"/>
        <source>Imprimir pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="335"/>
        <source>Referencia:</source>
        <translation>Referencia:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="440"/>
        <source>Descripcion del pedido:</source>
        <translation>DescripciÃ³n del pedido:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="479"/>
        <source>Numero de pedido cliente:</source>
        <translation>NÃºmero de pedido cliente:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="588"/>
        <source>Fecha creacion:</source>
        <translation>Fecha creaciÃ³n:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="539"/>
        <source>Almacen:</source>
        <translation>AlmacÃ©n:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="709"/>
        <source>Foma de pago:</source>
        <translation>Foma de pago:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="617"/>
        <source>Trabajador:</source>
        <translation>Trabajador:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="650"/>
        <source>Telefono de contacto:</source>
        <translation>TelÃ©fono de contacto:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="1514"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="1496"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="14"/>
        <source>Nuevo pedido de cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="388"/>
        <source>Mostrar/ocultar cabecera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="671"/>
        <source>Persona de contacto:</source>
        <translation type="unfinished">Persona de contacto:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="841"/>
        <source>Descuentos:</source>
        <translation type="unfinished">Descuentos:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="950"/>
        <source>Base imponible:</source>
        <translation type="unfinished">Base imponible:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="1056"/>
        <source>I.R.P.F.:</source>
        <translation type="unfinished">I.R.P.F.:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="1162"/>
        <source>Impuestos:</source>
        <translation type="unfinished">Impuestos:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="1268"/>
        <source>R.E.:</source>
        <translation type="unfinished">R.E.:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="1374"/>
        <source>Total:</source>
        <translation type="unfinished">Total:</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="207"/>
        <source>Ver presupuesto de este pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="244"/>
        <source>Generar albaran a partir de este pedido</source>
        <translation type="unfinished">Generar albarÃ¡n a partir de este pedido</translation>
    </message>
    <message>
        <location filename="pedidoclientebase.ui" line="281"/>
        <source>Registrar cobro a cliente</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PedidoClienteView</name>
    <message>
        <location filename="pedidoclienteview.cpp" line="132"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="pedidoclienteview.cpp" line="132"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="pedidoclienteview.cpp" line="62"/>
        <source>Error al crear el pedido cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoclienteview.cpp" line="212"/>
        <source>Pedido de cliente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoclienteview.cpp" line="130"/>
        <source>Albaran ya existe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoclienteview.cpp" line="131"/>
        <source>Existe un albaran a este cliente con la misma referencia que este pedido. Desea abrirlo para verificar?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PedidoProveedor</name>
    <message>
        <location filename="pedidoproveedor.cpp" line="35"/>
        <source>Id pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="36"/>
        <source>Id proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="37"/>
        <source>Id almacen</source>
        <translation type="unfinished">Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="38"/>
        <source>Numero pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="39"/>
        <source>Fecha pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="40"/>
        <source>Comentario pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="41"/>
        <source>Pedido procesado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="42"/>
        <source>Descripcion pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="43"/>
        <source>Referencia pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="44"/>
        <source>Id forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="45"/>
        <source>Id trabajador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="46"/>
        <source>Persona de contacto proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidoproveedor.cpp" line="47"/>
        <source>Telefono proveedor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PedidoProveedorBase</name>
    <message>
        <location filename="pedidoproveedorbase.ui" line="696"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="1405"/>
        <source>0.00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="486"/>
        <source>Foma de pago:</source>
        <translation>Forma de pago:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="618"/>
        <source>Telefono de contacto:</source>
        <translation>TelÃ©fono de contacto:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="1453"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="1446"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="182"/>
        <source>Imprimir pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="238"/>
        <source>Generar albaran a partir de este pedido</source>
        <translation>Generar albarÃ¡n a partir de este pedido</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="318"/>
        <source>Referencia del pedido:</source>
        <translation>Referencia del pedido:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="602"/>
        <source>Persona de contacto:</source>
        <translation>Persona de contacto:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="716"/>
        <source>Descuen&amp;tos</source>
        <translation>Descuen&amp;tos</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="736"/>
        <source>Comentario&amp;s</source>
        <translation>Comentario&amp;s</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="22"/>
        <source>Nuevo pedido a proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="410"/>
        <source>Descripcion:</source>
        <translation>DescripciÃ³n:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pedidoproveedorbase.ui" line="431"/>
        <source>NÂº de pedido:</source>
        <translation>NÂº de pedido:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="504"/>
        <source>Almacen de destino:</source>
        <translation>AlmacÃ©n de destino:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="522"/>
        <source>Emisor responsable:</source>
        <translation>Emisor responsable:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="547"/>
        <source>Fecha del pedido:</source>
        <translation>Fecha del pedido:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="663"/>
        <source>Pedido &amp;tramitado</source>
        <translation>Pedido &amp;tramitado</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="802"/>
        <source>Descuentos:</source>
        <translation>Descuentos:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="911"/>
        <source>Base imponible:</source>
        <translation>Base imponible:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="1123"/>
        <source>Impuestos:</source>
        <translation>Impuestos:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="1335"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="108"/>
        <source>Guardar pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="145"/>
        <source>Borrar pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="1017"/>
        <source>I.R.P.F.:</source>
        <translation>I.R.P.F.:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="1229"/>
        <source>R.E.:</source>
        <translation>R.E.:</translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="123"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="160"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="197"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="275"/>
        <source>Registrar pago a proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="374"/>
        <source>Mostrar/ocultar cabecera</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorbase.ui" line="389"/>
        <source>Ctrl+G</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PedidoProveedorView</name>
    <message>
        <location filename="pedidoproveedorview.cpp" line="64"/>
        <source>Error al crear el pedido a proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorview.cpp" line="118"/>
        <source>Pedido a proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidoproveedorview.cpp" line="199"/>
        <source>El albaran de proveedor no existe</source>
        <translation>El albarÃ¡n de proveedor no existe</translation>
    </message>
    <message>
        <location filename="pedidoproveedorview.cpp" line="201"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="pedidoproveedorview.cpp" line="201"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="pedidoproveedorview.cpp" line="200"/>
        <source>No existe un albaran asociado a este pedido.
Desea crearlo?</source>
        <translation>No existe un albarÃ¡n asociado a este pedido.(new line)Â¿Desea crearlo?</translation>
    </message>
</context>
<context>
    <name>PedidosClienteList</name>
    <message>
        <location filename="pedidosclientelist.cpp" line="138"/>
        <source>Error al cargar el pedido cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="166"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="157"/>
        <source>Pedidos de clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="181"/>
        <source>Error al borrar el pedido de cliente</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PedidosClienteListBase</name>
    <message>
        <location filename="pedidosclientelistbase.ui" line="424"/>
        <source>Procesados</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="92"/>
        <source>Nuevo pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="129"/>
        <source>Editar pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="166"/>
        <source>Borrar pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="240"/>
        <source>Filtrar pedidos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="280"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="320"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="379"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="454"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="487"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="552"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="17"/>
        <source>Pedidos de clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="255"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="295"/>
        <source>Ctrl+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelistbase.ui" line="335"/>
        <source>F5</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PedidosClienteListSubform</name>
    <message>
        <location filename="pedidosclientelist.cpp" line="213"/>
        <source>Id pedido cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="200"/>
        <source>Codigo de almacen</source>
        <translation>CÃ³digo de almacÃ©n</translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="199"/>
        <source>Referencia pedido cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="198"/>
        <source>Numero pedido cliente</source>
        <translation>NÃºmero pedido cliente</translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="201"/>
        <source>Descripcion pedido cliente</source>
        <translation>DescripciÃ³n pedido cliente</translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="202"/>
        <source>Nombre cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="203"/>
        <source>Fecha pedido cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="204"/>
        <source>Persona de contacto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="205"/>
        <source>Telefono pedido cliente</source>
        <translation>TelÃ©fono pedido cliente</translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="206"/>
        <source>Comentario pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="210"/>
        <source>Id trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="211"/>
        <source>Id cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="212"/>
        <source>Id almacen</source>
        <translation>Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="207"/>
        <source>Total pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="208"/>
        <source>Base imponible</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosclientelist.cpp" line="209"/>
        <source>Impuestos</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PedidosProveedorList</name>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="154"/>
        <source>Error al cargar el pedido proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="108"/>
        <source>Pedidos a proveedores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="163"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="132"/>
        <source>Error al borrar el pedido a proveedor</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PedidosProveedorListBase</name>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="240"/>
        <source>Filtrar pedidos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="280"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="320"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="358"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="448"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="418"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="403"/>
        <source>Solo procesados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="585"/>
        <source>0.00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="17"/>
        <source>Pedidos a proveedores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="513"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="92"/>
        <source>Nuevo pedido a proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="129"/>
        <source>Editar pedido a proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="166"/>
        <source>Borrar pedido a proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="255"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="295"/>
        <source>Ctrl+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlistbase.ui" line="335"/>
        <source>F5</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PedidosProveedorListSubform</name>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="185"/>
        <source>Codigo de almacen</source>
        <translation type="unfinished">CÃ³digo de almacÃ©n</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="184"/>
        <source>Descripcion pedido proveedor</source>
        <translation>DescripciÃ³n pedido proveedor</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="178"/>
        <source>Nombre de proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="179"/>
        <source>Fecha pedido proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="186"/>
        <source>Persona de contacto proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="187"/>
        <source>Telefono proveedor</source>
        <translation>TelÃ©fono proveedor</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="188"/>
        <source>Comentario pedido proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="190"/>
        <source>Id trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="191"/>
        <source>Id proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="192"/>
        <source>Id almacen</source>
        <translation>Id almacÃ©n</translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="182"/>
        <source>Impuestos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="180"/>
        <source>Referencia pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="181"/>
        <source>Base Imponible</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="183"/>
        <source>Total pedido</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pedidosproveedorlist.cpp" line="189"/>
        <source>Id pedido</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Presupuesto</name>
    <message>
        <location filename="presupuesto.cpp" line="46"/>
        <source>Descuento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fichabf.cpp" line="266"/>
        <source>Porcentaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fichabf.cpp" line="267"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fichabf.cpp" line="296"/>
        <source>Base </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fichabf.cpp" line="310"/>
        <source>I.V.A. </source>
        <translation type="unfinished">(sp)I.V.A.</translation>
    </message>
    <message>
        <location filename="fichabf.cpp" line="325"/>
        <source>R.E. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fichabf.cpp" line="332"/>
        <source>I.R.P.F  (-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fichabf.cpp" line="336"/>
        <source>Total </source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="36"/>
        <source>ID Presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="37"/>
        <source>ID cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="38"/>
        <source>ID almacen</source>
        <translation>ID almacÃ©n</translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="39"/>
        <source>Numero de Presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="40"/>
        <source>Fecha de creacion</source>
        <translation>Fecha de creaciÃ³n</translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="41"/>
        <source>Fecha de vencimiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="42"/>
        <source>Persona de contacto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="43"/>
        <source>Numero de telefono</source>
        <translation>NÃºmero de telÃ©fono</translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="44"/>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="45"/>
        <source>Presupuesto procesado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="47"/>
        <source>Referencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="48"/>
        <source>ID forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuesto.cpp" line="49"/>
        <source>ID trabajador</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PresupuestoClienteBase</name>
    <message>
        <location filename="presupuestoclientebase.ui" line="22"/>
        <source>Nuevo presupuesto a cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="120"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="157"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="194"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="286"/>
        <source>Referencia:</source>
        <translation>Referencia:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="339"/>
        <source>Mostrar/Ocultar cabecera</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="386"/>
        <source>Descripcion:</source>
        <translation>Descripcion:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="427"/>
        <source>Numero de presupuesto:</source>
        <translation>NÃºmero de presupuesto:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="493"/>
        <source>Almacen:</source>
        <translation>AlmacÃ©n:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="529"/>
        <source>Trabajador:</source>
        <translation>Trabajador:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="653"/>
        <source>Persona de contacto:</source>
        <translation>Persona de contacto:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="689"/>
        <source>Fecha de creacion:</source>
        <translation>Fecha de creaciÃ³n:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="710"/>
        <source>Fecha de vencimiento:</source>
        <translation>Fecha de vencimiento:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="731"/>
        <source>Forma de pago:</source>
        <translation>Forma de pago:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="752"/>
        <source>Telefono de contacto:</source>
        <translation>TelÃ©fono de contacto:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="791"/>
        <source>Pro&amp;cesado</source>
        <translation>Pro&amp;cesado</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="826"/>
        <source>&amp;Detalle</source>
        <translation>&amp;Detalle</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="842"/>
        <source>Desc&amp;uentos</source>
        <translation>Desc&amp;uentos</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="858"/>
        <source>Datos &amp;generales</source>
        <translation>Datos &amp;generales</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="912"/>
        <source>Descuentos:</source>
        <translation>Descuentos:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1542"/>
        <source>0.00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1048"/>
        <source>Base imponible:</source>
        <translation>Base imponible:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1154"/>
        <source>I.R.P.F.:</source>
        <translation>I.R.P.F.:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1260"/>
        <source>Impuestos:</source>
        <translation>Impuestos:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1366"/>
        <source>R.E.:</source>
        <translation>R.E.:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1472"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1594"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="1612"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="105"/>
        <source>Guardar presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="142"/>
        <source>Borrar presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="179"/>
        <source>Imprimir presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="232"/>
        <source>Generar pedido a partir de este presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoclientebase.ui" line="354"/>
        <source>Ctrl+G</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PresupuestoList</name>
    <message>
        <location filename="presupuestolist.cpp" line="146"/>
        <source>Error al editar el presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="188"/>
        <source>Error al borrar el presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="174"/>
        <source>Debe seleccionar una linea</source>
        <translation>Debe seleccionar una lÃ­nea</translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="165"/>
        <source>Presupuestos a clientes</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PresupuestoListSubForm</name>
    <message>
        <location filename="presupuestolist.cpp" line="206"/>
        <source>Codigo de almacen</source>
        <translation>CÃ³digo de almacÃ©n</translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="208"/>
        <source>Referencia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="209"/>
        <source>Descripcion</source>
        <translation>DescripciÃ³n</translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="210"/>
        <source>Nombre del cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="212"/>
        <source>Persona de contacto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="213"/>
        <source>Numero de telefono</source>
        <translation>NÃºmero de telÃ©fono</translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="214"/>
        <source>Comentarios</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="215"/>
        <source>ID trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="216"/>
        <source>ID cliente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="217"/>
        <source>ID almacen</source>
        <translation>ID almacÃ©n</translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="218"/>
        <source>Total Base imponible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="219"/>
        <source>Total impuestos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="205"/>
        <source>ID presupuesto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="207"/>
        <source>Numero de presupuesto</source>
        <translation type="unfinished">NÃºmero de presupuesto</translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="211"/>
        <source>Fecha del presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestolist.cpp" line="220"/>
        <source>Total presupuesto</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PresupuestoView</name>
    <message>
        <location filename="presupuestoview.cpp" line="141"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="presupuestoview.cpp" line="141"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="presupuestoview.cpp" line="85"/>
        <source>Error al crear el presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoview.cpp" line="223"/>
        <source>Presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoview.cpp" line="139"/>
        <source>Pedido existente</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoview.cpp" line="140"/>
        <source>Existe un pedido a este cliente con la misma referencia que este presupuesto. Desea abrirla para verificar?</source>
        <translation>Existe un pedido a este cliente con la misma referencia que este presupuesto. Â¿Desea abrirla para verificar?</translation>
    </message>
</context>
<context>
    <name>PresupuestosListBase</name>
    <message>
        <location filename="presupuestoslistbase.ui" line="17"/>
        <source>Presupuestos a clientes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="92"/>
        <source>Nuevo presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="107"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="129"/>
        <source>Editar presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="144"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="166"/>
        <source>Borrar presupuesto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="181"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="203"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="218"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="240"/>
        <source>Filtrar pedidos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="277"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="314"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="329"/>
        <source>F5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="373"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="418"/>
        <source>Fecha inicial:</source>
        <translation>Fecha inicial:</translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="451"/>
        <source>Fecha final:</source>
        <translation>Fecha final:</translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="494"/>
        <source>Procesados</source>
        <translation></translation>
    </message>
    <message>
        <location filename="presupuestoslistbase.ui" line="548"/>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
</context>
<context>
    <name>Proveedor</name>
    <message>
        <location filename="provedit.cpp" line="54"/>
        <source>Regimen Fiscal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="55"/>
        <source>Forma_Pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="56"/>
        <source>Recargo de Equivalencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="57"/>
        <source>IRPF</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProveedorBase</name>
    <message>
        <location filename="proveditbase.ui" line="14"/>
        <source>Proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="1048"/>
        <source>Ver</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="1059"/>
        <source>Vigentes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="1064"/>
        <source>Vencidos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="1069"/>
        <source>Todos</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="79"/>
        <source>Nuevo proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="107"/>
        <source>Guardar proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="157"/>
        <source>Imprimir proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="135"/>
        <source>Borrar proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="430"/>
        <source>Provincia:</source>
        <translation>Provincia:</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="1136"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="1129"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="1099"/>
        <source>Resumen por articulos</source>
        <translation>Resumen por artÃ­culos</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="94"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="122"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="172"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="204"/>
        <source>&amp;Datos generales</source>
        <translation>&amp;Datos generales</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="239"/>
        <source>&amp;Comentarios:</source>
        <translation>&amp;Comentarios:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="283"/>
        <source>Datos de comercio &amp;electrÃ³nico:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="330"/>
        <source>Forma de pago:</source>
        <translation>Forma de pago:</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="343"/>
        <source>&amp;IRPF que aplica:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="356"/>
        <source>E-&amp;mail:</source>
        <translation>E-&amp;mail:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="372"/>
        <source>PÃ¡gina &amp;web:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="401"/>
        <source>NÃºmero de &amp;fax:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="417"/>
        <source>&amp;TelÃ©fono:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="443"/>
        <source>PoblaciÃ³&amp;n:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="456"/>
        <source>DirecciÃ³&amp;n:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="480"/>
        <source>CÃ³digo &amp;postal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="518"/>
        <source>Di&amp;visiÃ³n:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="544"/>
        <source>Nombre comercia&amp;l:</source>
        <translation>Nombre comercia&amp;l:</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="557"/>
        <source>&amp;Nombre empresa:</source>
        <translation>&amp;Nombre empresa:</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="583"/>
        <source>C.I.&amp;F. / N.I.F.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="596"/>
        <source>&amp;CÃ³digo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="proveditbase.ui" line="615"/>
        <source>Nuestro cÃ³digo de c&amp;liente:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="631"/>
        <source>Datos &amp;bancarios:</source>
        <translation>Datos &amp;bancarios:</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="647"/>
        <source>Regimen &amp;fiscal:</source>
        <translation>Regimen &amp;fiscal:</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="670"/>
        <source>&amp;Aplicar Recargo de Equivalencia.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="691"/>
        <source>&amp;Pedidos</source>
        <translation>&amp;Pedidos</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="707"/>
        <source>&amp;Albaranes</source>
        <translation>&amp;Albaranes</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="723"/>
        <source>&amp;Facturas</source>
        <translation>&amp;Facturas</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="739"/>
        <source>&amp;Pagos</source>
        <translation>&amp;Pagos</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="755"/>
        <source>Di&amp;visiones</source>
        <translation>Di&amp;visiones</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="859"/>
        <source>Productos &amp;suministrados</source>
        <translation>Productos &amp;suministrados</translation>
    </message>
    <message>
        <location filename="proveditbase.ui" line="938"/>
        <source>&amp;Contratos</source>
        <translation type="unfinished">&amp;Contratos</translation>
    </message>
</context>
<context>
    <name>ProveedorList</name>
    <message>
        <location filename="providerslist.cpp" line="161"/>
        <source>Proveedores (*.xml)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="144"/>
        <source>Seleccione el archivo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="159"/>
        <source>Elija el archivo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="49"/>
        <source>Selector de proveedores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="128"/>
        <source>Error al borrar el proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="137"/>
        <source>Listado de Proveedores</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProveedorListBase</name>
    <message>
        <location filename="providerslistbase.ui" line="239"/>
        <source>Exportar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="261"/>
        <source>Importar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="338"/>
        <source>Procesa&amp;dos</source>
        <translation>Procesa&amp;dos</translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="76"/>
        <source>Nuevo proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="98"/>
        <source>Editar proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="120"/>
        <source>Borrar proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="142"/>
        <source>Imprimir listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="164"/>
        <source>Filtrar proveedores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="189"/>
        <source>Configurar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="214"/>
        <source>Actualizar listado</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="236"/>
        <source>Exportar proveedores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="258"/>
        <source>Importar proveedores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="293"/>
        <source>Buscar:</source>
        <translation>Buscar:</translation>
    </message>
    <message>
        <location filename="providerslistbase.ui" line="25"/>
        <source>Proveedores</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ProveedorListSubform</name>
    <message>
        <location filename="providerslist.cpp" line="179"/>
        <source>ID proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="182"/>
        <source>Nombre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="183"/>
        <source>Nombre alternativo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="181"/>
        <source>C.I.F.</source>
        <translation>C.I.F.</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="184"/>
        <source>Codigo</source>
        <translation>CÃ³digo</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="185"/>
        <source>Numero de cuenta corriente</source>
        <translation>NÃºmero de cuenta corriente</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="186"/>
        <source>Comentarios</source>
        <translation></translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="187"/>
        <source>Direccion</source>
        <translation>DirecciÃ³n</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="188"/>
        <source>Poblacion</source>
        <translation>PoblaciÃ³n</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="189"/>
        <source>Codigo postal</source>
        <translation>CÃ³digo postal</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="190"/>
        <source>Numero de telefono</source>
        <translation>NÃºmero de telÃ©fono</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="191"/>
        <source>Numero de fax</source>
        <translation>NÃºmero de fax</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="192"/>
        <source>Direccion de correo electronico</source>
        <translation>DirecciÃ³n de correo electrÃ³nico</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="193"/>
        <source>Direccion de URL</source>
        <translation>DirecciÃ³n de URL</translation>
    </message>
    <message>
        <location filename="providerslist.cpp" line="194"/>
        <source>Clave de acceso a la web del proveedor</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ProveedorView</name>
    <message>
        <location filename="provedit.cpp" line="172"/>
        <source>Guardar proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="173"/>
        <source>Desea guardar los cambios?</source>
        <translation>Â¿Desea guardar los cambios?</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="252"/>
        <source>Borrar proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="253"/>
        <source>Esta a punto de borrar un proveedor. Estos datos pueden dar problemas.</source>
        <translation>Esta a punto de borrar un proveedor. Estos datos pueden dar problemas.</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="174"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="174"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="174"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="44"/>
        <source>Direccion</source>
        <translation>DirecciÃ³n</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="45"/>
        <source>Poblacion</source>
        <translation>PoblaciÃ³n</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="46"/>
        <source>Provincia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="47"/>
        <source>Codigo postal</source>
        <translation>CÃ³digo postal</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="48"/>
        <source>Numero de telefono</source>
        <translation>NÃºmero de telÃ©fono</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="49"/>
        <source>Numero de fax</source>
        <translation>NÃºmero de fax</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="50"/>
        <source>Direccion electronica</source>
        <translation>DirecciÃ³n electrÃ³nica</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="51"/>
        <source>URL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="52"/>
        <source>Comentarios</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="53"/>
        <source>Codigo</source>
        <translation>CÃ³digo</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="38"/>
        <source>ID proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="39"/>
        <source>Nombre del proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="40"/>
        <source>Nombre alternativo del proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="41"/>
        <source>C.I.F. del proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="42"/>
        <source>Codigo cliente</source>
        <translation>CÃ³digo cliente</translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="43"/>
        <source>Banco proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="91"/>
        <source>Error al crear el proveedor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="provedit.cpp" line="156"/>
        <source>Proveedor</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Splash</name>
    <message>
        <location filename="splashscreen.cpp" line="42"/>
        <source>&lt;center&gt;&lt;font size=+1 color=&quot;#a3ffa3&quot;&gt;BulmaFact&lt;/font&gt;&amp;nbsp;&lt;font color=&quot;#0000ff&quot;&gt;0.9.1&lt;/font&gt;&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="107"/>
        <source>Calibrando los lasers del lector de CD</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="108"/>
        <source>Comprobando la disquetera y la memoria RAM</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="109"/>
        <source>Induciendo energia cuantica, entre su RAM y su ROM</source>
        <translation>Induciendo energÃ­a cuÃ¡ntica, entre su RAM y su ROM</translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="110"/>
        <source>Pequenyos golpecitos de reajuste del HD</source>
        <translation>PequeÃ±os golpecitos de reajuste del HD</translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="111"/>
        <source>Probando la velocidad del ventilador de la CPU</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="112"/>
        <source>Haciendo PING contra el servidor de la MetaBase</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="113"/>
        <source>Fallando a Segmento</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="114"/>
        <source>Dejando tiempo libre al sistema</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="115"/>
        <source>Sincronizando fases Alfa Beta</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="116"/>
        <source>Flusheando datos con vidas inteligentes superiores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="117"/>
        <source>Permutando las particiones del Sistema Operativo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="118"/>
        <source>Crackeando BulmaFact</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SubForm2Bf</name>
    <message>
        <location filename="subform2bf.cpp" line="199"/>
        <source>Borrar registro</source>
        <translation></translation>
    </message>
    <message>
        <location filename="subform2bf.cpp" line="201"/>
        <source>Ajustar columna</source>
        <translation></translation>
    </message>
    <message>
        <location filename="subform2bf.cpp" line="202"/>
        <source>Ajustar altura</source>
        <translation></translation>
    </message>
    <message>
        <location filename="subform2bf.cpp" line="204"/>
        <source>Ajustar columnas</source>
        <translation></translation>
    </message>
    <message>
        <location filename="subform2bf.cpp" line="205"/>
        <source>Ajustar alturas</source>
        <translation></translation>
    </message>
    <message>
        <location filename="subform2bf.cpp" line="208"/>
        <source>Ver/Ocultar configurador de subformulario</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>TipoArticuloList</name>
    <message>
        <location filename="tiposarticuloview.cpp" line="188"/>
        <source>Guardar familia</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tiposarticuloview.cpp" line="189"/>
        <source>Desea guardar los cambios?</source>
        <translation>Â¿Desea guardar los cambios?</translation>
    </message>
    <message>
        <location filename="tiposarticuloview.cpp" line="41"/>
        <source>Id</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tiposarticuloview.cpp" line="41"/>
        <source>Codigo</source>
        <translation>CÃ³digo</translation>
    </message>
    <message>
        <location filename="tiposarticuloview.cpp" line="41"/>
        <source>Descripcion</source>
        <translation>DescripciÃ³n</translation>
    </message>
</context>
<context>
    <name>TrabajadorBase</name>
    <message>
        <location filename="trabajadorbase.ui" line="14"/>
        <source>Trabajadores</source>
        <translation></translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="160"/>
        <source>Activo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="397"/>
        <source>Nuevo trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="363"/>
        <source>Guardar trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="329"/>
        <source>Borrar trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="29"/>
        <source>Informacion del trabajador:</source>
        <translation>InformaciÃ³n del trabajador:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="150"/>
        <source>Nombre:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="140"/>
        <source>Apellidos:</source>
        <translation>Apellidos:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="121"/>
        <source>Direccion:</source>
        <translation>DirecciÃ³n:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="74"/>
        <source>Telefono:</source>
        <translation>TelÃ©fono:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="64"/>
        <source>Telefono movil:</source>
        <translation>TelÃ©fono mÃ³vil:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="104"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="221"/>
        <source>Cambiar imagen</source>
        <translation>Cambiar imagen</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="175"/>
        <source>Numero de la Seguridad Social:</source>
        <translation>NÃºmero de la Seguridad Social:</translation>
    </message>
    <message>
        <location filename="trabajadorbase.ui" line="231"/>
        <source>Lista de trabajadores:</source>
        <translation>Lista de trabajadores:</translation>
    </message>
</context>
<context>
    <name>TrabajadorView</name>
    <message>
        <location filename="trabajadorview.cpp" line="147"/>
        <source>Guardar datos del trabajador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="trabajadorview.cpp" line="148"/>
        <source>Desea guardar los cambios?</source>
        <translation>Â¿Desea guardar los cambios?</translation>
    </message>
    <message>
        <location filename="trabajadorview.cpp" line="149"/>
        <source>&amp;Si</source>
        <translation>&amp;SÃ­</translation>
    </message>
    <message>
        <location filename="trabajadorview.cpp" line="149"/>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <location filename="trabajadorview.cpp" line="201"/>
        <source>Seleccione archivo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="trabajadorview.cpp" line="203"/>
        <source>Imagenes (*.jpg)</source>
        <translation>ImÃ¡genes (*.jpg)</translation>
    </message>
</context>
<context>
    <name>aboutdlg</name>
    <message>
        <location filename="aboutbase.ui" line="502"/>
        <source>Acerca de BulmaFact</source>
        <translation></translation>
    </message>
    <message>
        <location filename="aboutbase.ui" line="583"/>
        <source>&amp;Acerca de</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="aboutbase.ui" line="606"/>
        <source>A&amp;utores</source>
        <translation>A&amp;utores</translation>
    </message>
    <message>
        <location filename="aboutbase.ui" line="638"/>
        <source>Sopor&amp;te</source>
        <translation>Sopor&amp;te</translation>
    </message>
    <message>
        <location filename="aboutbase.ui" line="661"/>
        <source>Acuerdo de &amp;licencia</source>
        <translation>Acuerdo de &amp;licencia</translation>
    </message>
    <message>
        <location filename="aboutbase.ui" line="708"/>
        <source>&amp;Cerrar</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="aboutbase.ui" line="554"/>
        <source>FacturaciÃ³n GPL - VersiÃ³n 0.9.1 -</source>
        <translation></translation>
    </message>
    <message>
        <location filename="aboutbase.ui" line="627"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bulmafact</name>
    <message>
        <location filename="bulmafact.cpp" line="93"/>
        <source>Listo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafact.cpp" line="139"/>
        <source>BulmaFact</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafact.cpp" line="127"/>
        <source>Pulse aceptar para emitir un monton de facturas</source>
        <translation>Pulse aceptar para emitir un montÃ³n de facturas</translation>
    </message>
    <message>
        <location filename="bulmafact.cpp" line="140"/>
        <source>Pulse aceptar para recibir(destruir) un monton de facturas</source>
        <translation>Pulse aceptar para recibir(destruir) un montÃ³n de facturas</translation>
    </message>
</context>
<context>
    <name>bulmafactbase</name>
    <message>
        <location filename="bulmafactbase.ui" line="148"/>
        <source>Listados</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="520"/>
        <source>Fichas</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="106"/>
        <source>Venta&amp;na</source>
        <translation>Venta&amp;na</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="113"/>
        <source>A&amp;yuda</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="67"/>
        <source>&amp;Ventas</source>
        <translation>&amp;Ventas</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="251"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="318"/>
        <source>F4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="369"/>
        <source>F6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="387"/>
        <source>&amp;Tipos de articulo</source>
        <translation>&amp;Tipos de artÃ­culo</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="398"/>
        <source>F2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="411"/>
        <source>&amp;Inventarios</source>
        <translation>&amp;Inventarios</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="451"/>
        <source>Pro&amp;vincias</source>
        <translation>Pro&amp;vincias</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="456"/>
        <source>Se&amp;ries de factura</source>
        <translation>Se&amp;ries de factura</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="461"/>
        <source>&amp;Trabajadores</source>
        <translation>&amp;Trabajadores</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="469"/>
        <source>Ventana &amp;completa</source>
        <translation>Ventana &amp;completa</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="525"/>
        <source>&amp;Formas de pago</source>
        <translation>&amp;Formas de pago</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="530"/>
        <source>&amp;Almacenes</source>
        <translation>&amp;Almacenes</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="535"/>
        <source>&amp;Documentacion</source>
        <translation>&amp;DocumentaciÃ³n</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="538"/>
        <source>F1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="382"/>
        <source>Gestion de &amp;familias</source>
        <translation>Gestion de &amp;familias</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="16"/>
        <source>BulmaFact - Facturacion GPL</source>
        <translation>BulmaFact - FacturaciÃ³n GPL</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="49"/>
        <source>E&amp;mpresa</source>
        <translation>E&amp;mpresa</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="33"/>
        <source>Com&amp;pras</source>
        <translation>Com&amp;pras</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="56"/>
        <source>Articulo&amp;s</source>
        <translation>ArtÃ­culo&amp;s</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="86"/>
        <source>Maest&amp;ro</source>
        <translation>Maest&amp;ro</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="472"/>
        <source>F11</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="558"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="267"/>
        <source>Nuevo pe&amp;dido a proveedor...</source>
        <translation>Nuevo pe&amp;dido a proveedor...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="283"/>
        <source>Nuevo &amp;albaran de proveedor...</source>
        <translation>Nuevo &amp;albarÃ¡n de proveedor...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="299"/>
        <source>Nueva &amp;factura de proveedor...</source>
        <translation>Nueva &amp;factura de proveedor...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="315"/>
        <source>Nuevo &amp;presupuesto a cliente...</source>
        <translation>Nuevo &amp;presupuesto a cliente...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="334"/>
        <source>Nuevo pe&amp;dido de cliente...</source>
        <translation>Nuevo pe&amp;dido de cliente...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="350"/>
        <source>Nuevo &amp;albaran a cliente...</source>
        <translation>Nuevo &amp;albarÃ¡n a cliente...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="366"/>
        <source>Nueva &amp;factura a cliente...</source>
        <translation>Nueva &amp;factura a cliente...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="395"/>
        <source>Nuevo &amp;articulo...</source>
        <translation>Nuevo &amp;artÃ­culo...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="419"/>
        <source>Nuevo &amp;proveedor...</source>
        <translation>Nuevo &amp;proveedor...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="435"/>
        <source>Nuevo &amp;cliente...</source>
        <translation>Nuevo &amp;cliente...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="477"/>
        <source>&amp;Acerca de BulmaFact</source>
        <translation>&amp;Acerca de BulmaFact</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="493"/>
        <source>Nuevo pa&amp;go a proveedor...</source>
        <translation>Nuevo pa&amp;go a proveedor...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="501"/>
        <source>Nuevo co&amp;bro a cliente...</source>
        <translation>Nuevo co&amp;bro a cliente...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="248"/>
        <source>&amp;Salir del programa</source>
        <translation>&amp;Salir del programa</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="259"/>
        <source>Configurar &amp;BulmaFact...</source>
        <translation>Configurar &amp;BulmaFact...</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="275"/>
        <source>Pe&amp;didos a proveedores</source>
        <translation>Pe&amp;didos a proveedores</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="291"/>
        <source>&amp;Albaranes de proveedores</source>
        <translation>&amp;Albaranes de proveedores</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="307"/>
        <source>&amp;Facturas de proveedores</source>
        <translation>&amp;Facturas de proveedores</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="326"/>
        <source>&amp;Presupuestos a clientes</source>
        <translation>&amp;Presupuestos a clientes</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="342"/>
        <source>Pe&amp;didos de clientes</source>
        <translation>Pe&amp;didos de clientes</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="358"/>
        <source>&amp;Albaranes a clientes</source>
        <translation>&amp;Albaranes a clientes</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="377"/>
        <source>&amp;Facturas a clientes</source>
        <translation>&amp;Facturas a clientes</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="406"/>
        <source>&amp;Articulos</source>
        <translation>&amp;ArtÃ­culos</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="427"/>
        <source>&amp;Proveedores</source>
        <translation>&amp;Proveedores</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="446"/>
        <source>&amp;Clientes</source>
        <translation>&amp;Clientes</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="485"/>
        <source>Pa&amp;gos a proveedores</source>
        <translation>Pa&amp;gos a proveedores</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="509"/>
        <source>Co&amp;bros a clientes</source>
        <translation>Co&amp;bros a clientes</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="549"/>
        <source>&amp;Indexador</source>
        <translation>&amp;Indexador</translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="555"/>
        <source>Indexador</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bulmafactbase.ui" line="438"/>
        <source>F3</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>familiasbase</name>
    <message>
        <location filename="familiasbase.ui" line="14"/>
        <source>Familias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="103"/>
        <source>Nueva Familia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="137"/>
        <source>Borrar Familia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="171"/>
        <source>Guardar Familia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="205"/>
        <source>Imprimir Familias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="271"/>
        <source>Mostrar / Ocultar Detalle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="311"/>
        <source>Contenido de la familia:</source>
        <translation type="unfinished">Contenido de la familia:</translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="334"/>
        <source>Descripcion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="341"/>
        <source>Codigo:</source>
        <translation>CÃ³digo:</translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="357"/>
        <source>Codigo completo:</source>
        <translation>CÃ³digo completo:</translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="370"/>
        <source>Nombre:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="404"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="familiasbase.ui" line="411"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.cpp" line="174"/>
        <source>Error inesperado en BulmaFact. El programa se cerrara.</source>
        <translation>Error inesperado en BulmaFact. El programa se cerrarÃ¡.</translation>
    </message>
</context>
<context>
    <name>tiposarticulobase</name>
    <message>
        <location filename="tiposarticulobase.ui" line="14"/>
        <source>Tipos de articulo</source>
        <translation type="unfinished">Tipos de artÃ­culo</translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="89"/>
        <source>Guardar Tipo de articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="104"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="126"/>
        <source>Borrar Tipo de articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="141"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="179"/>
        <source>Nuevo Tipo de articulo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="194"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="232"/>
        <source>Mostrar / Ocultar Detalle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="272"/>
        <source>Contenido de la familia:</source>
        <translation type="unfinished">Contenido de la familia:</translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="292"/>
        <source>Codigo:</source>
        <translation>CÃ³digo:</translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="312"/>
        <source>Descripcion:</source>
        <translation>DescripciÃ³n:</translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="346"/>
        <source>&amp;Cancelar</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="tiposarticulobase.ui" line="353"/>
        <source>&amp;Aceptar</source>
        <translation>&amp;Aceptar</translation>
    </message>
</context>
</TS>
