<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>AmortizacionBase</name>
    <message>
        <location filename="amortizacionbase.ui" line="13"/>
        <source>Amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="110"/>
        <source>Guardar amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="212"/>
        <source>Nombre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="232"/>
        <source>Agrupacion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="247"/>
        <source>Amor&amp;tizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="amortizacionbase.ui" line="283"/>
        <source>NÂº de cuotas:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="293"/>
        <source>Fecha de compra:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="330"/>
        <source>Anual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="335"/>
        <source>Semestral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="340"/>
        <source>Trimestral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="345"/>
        <source>Mensual</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="amortizacionbase.ui" line="353"/>
        <source>Fecha 1Âª cuota:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="378"/>
        <source>Cuenta de activo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="388"/>
        <source>Periodicidad:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="398"/>
        <source>Valor de compra:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="408"/>
        <source>Cuenta de amortizacion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="458"/>
        <source>Metodo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="507"/>
        <source>Li&amp;neal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="484"/>
        <source>&amp;Incremental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="487"/>
        <source>Alt+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="477"/>
        <source>&amp;Decremental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="470"/>
        <source>Porcent&amp;ual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="530"/>
        <source>&amp;Calcular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="533"/>
        <source>Alt+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="550"/>
        <source>Cuotas:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="586"/>
        <source>Amortizado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="1069"/>
        <source>Pendiente:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="1590"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="1608"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="125"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="168"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionbase.ui" line="153"/>
        <source>Borrar amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AmortizacionView</name>
    <message>
        <location filename="amortizacionview.cpp" line="88"/>
        <source>Id lineas de amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="78"/>
        <source>Identificador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="204"/>
        <source>Error en la carga de la amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="321"/>
        <source>Anual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="323"/>
        <source>Mensual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="325"/>
        <source>Semestral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="327"/>
        <source>Trimestral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="64"/>
        <source>Nombre de la amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="65"/>
        <source>Descripcion de la amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="66"/>
        <source>Fecha de la compra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="67"/>
        <source>Fecha 1a cuota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="68"/>
        <source>Valor de la compra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="69"/>
        <source>Periodicidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="70"/>
        <source>Numero de cuotas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="71"/>
        <source>Metodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="72"/>
        <source>NIF del proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="73"/>
        <source>Nombre del proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="74"/>
        <source>Direccion del proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="75"/>
        <source>Telefono del proveedor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="76"/>
        <source>Agrupacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="89"/>
        <source>Id amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="79"/>
        <source>Id cuenta amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="84"/>
        <source>Ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="85"/>
        <source>Fecha prevista</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="86"/>
        <source>Cantidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionview.cpp" line="87"/>
        <source>Id asiento</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AmortizacionesBase</name>
    <message>
        <location filename="amortizacionesbase.ui" line="13"/>
        <source>Listado de amortizaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="amortizacionesbase.ui" line="85"/>
        <source>Nueva amortizaciÃ³n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionesbase.ui" line="100"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionesbase.ui" line="156"/>
        <source>Borrar amortizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="amortizacionesbase.ui" line="159"/>
        <source>Borrar amortizaciÃ³n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionesbase.ui" line="137"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="amortizacionesbase.ui" line="174"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AplInteligentesBase</name>
    <message>
        <location filename="aplinteligentesbase.ui" line="13"/>
        <source>Aplicar Asiento Inteligente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aplinteligentesbase.ui" line="107"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aplinteligentesbase.ui" line="170"/>
        <source>&amp;Fecha del asiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aplinteligentesbase.ui" line="183"/>
        <source>&amp;Plantilla:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aplinteligentesbase.ui" line="233"/>
        <source>Datos del asiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aplinteligentesbase.ui" line="264"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aplinteligentesbase.ui" line="274"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Asiento1</name>
    <message>
        <location filename="asiento1.cpp" line="37"/>
        <source>Id asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1.cpp" line="38"/>
        <source>Descripcion del asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1.cpp" line="39"/>
        <source>Fecha del asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1.cpp" line="40"/>
        <source>Comentarios del asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1.cpp" line="41"/>
        <source>Orden de asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1.cpp" line="42"/>
        <source>Tipo de asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1.cpp" line="60"/>
        <source>Borrar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1.cpp" line="61"/>
        <source>Se va a borrar el asiento. Esta seguro?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Asiento1View</name>
    <message>
        <location filename="asiento1view.cpp" line="274"/>
        <source>Asiento inexistente.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1view.cpp" line="275"/>
        <source>Desea crear un nuevo asiento en esa posicion?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1view.cpp" line="276"/>
        <source>&amp;Si</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asiento1view.cpp" line="276"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AsientoBase</name>
    <message>
        <location filename="asientobase.ui" line="140"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="185"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="275"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="260"/>
        <source>Nuevo asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="416"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="536"/>
        <source>Registro de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="551"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="581"/>
        <source>Asientos Inteligentes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="596"/>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="767"/>
        <source>Apertura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="772"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="asientobase.ui" line="777"/>
        <source>RegularizaciÃ³n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="782"/>
        <source>Cierre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="14"/>
        <source>Asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="125"/>
        <source>Abrir asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="170"/>
        <source>Cerrar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="215"/>
        <source>Guardar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="230"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="305"/>
        <source>Extender asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="320"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="356"/>
        <source>Borrar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="401"/>
        <source>Duplicar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="449"/>
        <source>Exportar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="494"/>
        <source>Importar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="632"/>
        <source>Fecha:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="649"/>
        <source>Orden del asiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="669"/>
        <source>Descuadre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="835"/>
        <source>Saldo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="928"/>
        <source>Total Debe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientobase.ui" line="1007"/>
        <source>Total Haber:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AsientoListBase</name>
    <message>
        <location filename="asientolistbase.ui" line="13"/>
        <source>Listado de asientos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="91"/>
        <source>Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="125"/>
        <source>Filtrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="165"/>
        <source>Configurar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="205"/>
        <source>Actualizar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="279"/>
        <source>Ejercicio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="299"/>
        <source>Asientos que tengan apuntes con cantidad igual a:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="309"/>
        <source>Asientos con saldo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistbase.ui" line="316"/>
        <source>Asientos cuyo nombre se parezca a:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AsientoListSubform</name>
    <message>
        <location filename="asientolistsubform.cpp" line="34"/>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="35"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="36"/>
        <source>Apuntes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="37"/>
        <source>Borrador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="38"/>
        <source>Debe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="39"/>
        <source>Haber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="40"/>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="41"/>
        <source>Clase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="80"/>
        <source>Borrar registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="83"/>
        <source>Ajustar columa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="84"/>
        <source>Ajustar altura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="85"/>
        <source>Ajustar columnas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="86"/>
        <source>Ajustar alturas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="88"/>
        <source>Ver configurador de subformulario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientolistsubform.cpp" line="33"/>
        <source>Id asiento</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BBloqFechaBase</name>
    <message>
        <location filename="bbloqfechabase.ui" line="13"/>
        <source>Bloquear fechas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfechabase.ui" line="93"/>
        <source>Agregar Ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfechabase.ui" line="108"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BalanceBase</name>
    <message>
        <location filename="balancebase.ui" line="28"/>
        <source>Balance de Cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="463"/>
        <source>Tipo de balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="504"/>
        <source>Abreviado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="519"/>
        <source>Sumas y Saldos</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="balancebase.ui" line="486"/>
        <source>PÃ©rdidas y Ganancias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="178"/>
        <source>Actualizar balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="304"/>
        <source>Configurar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="119"/>
        <source>Filtrar balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="224"/>
        <source>Guardar balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="267"/>
        <source>Imprimir balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="134"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="193"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="239"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="282"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="319"/>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="388"/>
        <source>Centro de coste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="411"/>
        <source>Nivel:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="431"/>
        <source>Fecha final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="balancebase.ui" line="456"/>
        <source>Balance jerÃ¡rquico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="558"/>
        <source>Fecha inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="565"/>
        <source>Cuenta inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="595"/>
        <source>Cuenta final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="626"/>
        <source>GroupBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="775"/>
        <source>Saldo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="844"/>
        <source>Haber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="919"/>
        <source>Saldo anterior:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancebase.ui" line="926"/>
        <source>Debe:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BalancePrintBase</name>
    <message encoding="UTF-8">
        <location filename="balanceprintbase.ui" line="13"/>
        <source>ImpresiÃ³n del Balance de Sumas y Saldos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="105"/>
        <source>Datos del listado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="balanceprintbase.ui" line="133"/>
        <source>CÃ³digo Inicial
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="154"/>
        <source>Fecha Inicial</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="balanceprintbase.ui" line="184"/>
        <source>CÃ³digo Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="204"/>
        <source>Fecha Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="234"/>
        <source>Nivel de Cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="254"/>
        <source>Incluir &amp;niveles superiores.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="261"/>
        <source>Incl&amp;uir resultados parciales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="283"/>
        <source>Formato:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="295"/>
        <source>&amp;Texto Plano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="305"/>
        <source>Propietario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="312"/>
        <source>HT&amp;ML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceprintbase.ui" line="319"/>
        <source>&amp;Kugar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BalanceSubForm</name>
    <message>
        <location filename="balancesubform.cpp" line="30"/>
        <source>idcuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="31"/>
        <source>tipocuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="32"/>
        <source>codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="33"/>
        <source>descripcion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="34"/>
        <source>asaldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="35"/>
        <source>tdebe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="36"/>
        <source>thaber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="37"/>
        <source>tsaldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="38"/>
        <source>ejdebe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="39"/>
        <source>ejhaber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="40"/>
        <source>ejsaldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="72"/>
        <source>Borrar registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="74"/>
        <source>Ajustar columa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="75"/>
        <source>Ajustar altura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="76"/>
        <source>Ajustar columnas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="77"/>
        <source>Ajustar alturas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancesubform.cpp" line="79"/>
        <source>Ver configurador de subformulario</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BalanceTreeBase</name>
    <message>
        <location filename="balancetreebase.ui" line="185"/>
        <source>Imprimir albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="111"/>
        <source>Borrar albaran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="14"/>
        <source>Balance jerarquico de Cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="290"/>
        <source>Cuenta final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="300"/>
        <source>Fecha final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="310"/>
        <source>Fecha inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="340"/>
        <source>Cuenta inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="379"/>
        <source>Nivel:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="389"/>
        <source>Centro de coste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="455"/>
        <source>Saldo anterior:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="522"/>
        <source>Total Debe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="589"/>
        <source>Total Haber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balancetreebase.ui" line="656"/>
        <source>Saldo:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BalanceTreeView</name>
    <message>
        <location filename="balance1view.cpp" line="76"/>
        <source>Codigo cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="77"/>
        <source>Nombre de la cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="78"/>
        <source>Saldo anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="79"/>
        <source>Debe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="80"/>
        <source>Haber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="81"/>
        <source>Saldo periodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="82"/>
        <source>Debe ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="83"/>
        <source>Haber ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="84"/>
        <source>Saldo ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="85"/>
        <source>Nivel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="86"/>
        <source>ID cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="86"/>
        <source>Padre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="430"/>
        <source>Ver Diario (este dia)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="431"/>
        <source>Ver Diario (este mes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="432"/>
        <source>Ver Diario (este anyo)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="434"/>
        <source>Ver extracto (este dia)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="435"/>
        <source>Ver extracto (este mes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balance1view.cpp" line="436"/>
        <source>Ver extracto (este anyo)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BalanceView</name>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Denominacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Saldo anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Debe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Haber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Saldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Debe ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Haber ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="balanceview.cpp" line="177"/>
        <source>Saldo ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BbloqFecha</name>
    <message>
        <location filename="bbloqfecha.cpp" line="91"/>
        <source>Octubre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="95"/>
        <source>Septiembre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="51"/>
        <source>Ejercicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="51"/>
        <source>Estado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="83"/>
        <source>Diciembre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="87"/>
        <source>Noviembre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="99"/>
        <source>Agosto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="103"/>
        <source>Julio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="107"/>
        <source>Junio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="111"/>
        <source>Mayo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="115"/>
        <source>Abril</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="119"/>
        <source>Marzo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="123"/>
        <source>Febrero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="127"/>
        <source>Enero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="144"/>
        <source>Bloqueado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bbloqfecha.cpp" line="145"/>
        <source>Abierto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BulmaContBase</name>
    <message>
        <location filename="bulmacontbase.ui" line="426"/>
        <source>Anterior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="415"/>
        <source>Siguiente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="319"/>
        <source>Asientos Inteligentes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="437"/>
        <source>Inicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="448"/>
        <source>Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="399"/>
        <source>A&amp;yuda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="57"/>
        <source>&amp;Herramientas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="30"/>
        <source>&amp;Maestro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="79"/>
        <source>&amp;Listados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="102"/>
        <source>&amp;Empresa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="172"/>
        <source>&amp;Ordenar asientos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="177"/>
        <source>Asiento de a&amp;pertura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="182"/>
        <source>Asiento de &amp;regularizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="187"/>
        <source>Asiento de &amp;cierre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="192"/>
        <source>Cuentas a&amp;nuales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="197"/>
        <source>Masas &amp;patrimoniales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="202"/>
        <source>Registro de &amp;IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="207"/>
        <source>&amp;Modelo 347 no oficial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="212"/>
        <source>&amp;Cobros y pagos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="217"/>
        <source>&amp;Amortizaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="225"/>
        <source>&amp;Plan Contable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="233"/>
        <source>&amp;Asientos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="244"/>
        <source>Apuntes &amp;contables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="255"/>
        <source>Libro &amp;Mayor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="263"/>
        <source>Libro &amp;Diario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="290"/>
        <source>Formas de &amp;pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="295"/>
        <source>Tipos de &amp;IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="303"/>
        <source>Centros de cos&amp;te</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="311"/>
        <source>&amp;Canales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="327"/>
        <source>&amp;Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="335"/>
        <source>&amp;Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="343"/>
        <source>&amp;Actualizar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="351"/>
        <source>&amp;Filtrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="356"/>
        <source>&amp;Recalcular saldos iniciales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="361"/>
        <source>&amp;Sustituir cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="366"/>
        <source>&amp;Bloquear fechas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="371"/>
        <source>&amp;Canal por defecto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="376"/>
        <source>Centro de cos&amp;te por defecto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="381"/>
        <source>&amp;Pantalla completa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="389"/>
        <source>Ordenar &amp;ventanas</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="bulmacontbase.ui" line="394"/>
        <source>OrganizaciÃ³n en &amp;cascada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="407"/>
        <source>&amp;Acerca de BulmaCont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="13"/>
        <source>BulmaCont - Contabilidad GPL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="48"/>
        <source>Ventana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="90"/>
        <source>&amp;Ver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="148"/>
        <source>Co&amp;nfiguracion...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="154"/>
        <source>Configuracion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="159"/>
        <source>&amp;Salir del programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="162"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="167"/>
        <source>&amp;Espaciar asientos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="236"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="247"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="271"/>
        <source>&amp;Balance de Cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="279"/>
        <source>Balance &amp;jerarquico de Sumas y Saldos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="285"/>
        <source>Balance jerarquico de Sumas y Saldos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="384"/>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="402"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="418"/>
        <source>Ctrl+PgDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="429"/>
        <source>Ctrl+PgUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="440"/>
        <source>Ctrl+Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="451"/>
        <source>Ctrl+End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="462"/>
        <source>Indexador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacontbase.ui" line="465"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bulmacont</name>
    <message>
        <location filename="bulmacont.cpp" line="150"/>
        <source>Listo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="109"/>
        <source>Deshaciendo la ultima accion...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="115"/>
        <source>Cortando seleccion...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="121"/>
        <source>Copiando la seleccion al portapapeles...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="127"/>
        <source>Insertando el contenido del portapapeles...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="133"/>
        <source>Cambinado barra de estado...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="144"/>
        <source>Cambiando a modo de pantalla completa...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="161"/>
        <source>Listado de cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bulmacont.cpp" line="85"/>
        <source>Listo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BusquedaCuentaBase</name>
    <message>
        <location filename="busquedacuentabase.ui" line="13"/>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="busquedacuentabase.ui" line="67"/>
        <source>Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAnualesBase</name>
    <message>
        <location filename="canualesbase.ui" line="16"/>
        <source>Cuentas Anuales</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAnualesPrintBase</name>
    <message encoding="UTF-8">
        <location filename="canualesprintbase.ui" line="15"/>
        <source>ImpresiÃ³n de Balances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canualesprintbase.ui" line="38"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canualesprintbase.ui" line="54"/>
        <source>Primer Periodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canualesprintbase.ui" line="106"/>
        <source>Fecha Inicial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canualesprintbase.ui" line="116"/>
        <source>Fecha Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canualesprintbase.ui" line="91"/>
        <source>Segundo Periodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canualesprintbase.ui" line="162"/>
        <source>Acep&amp;tar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canualesprintbase.ui" line="172"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAnualesView</name>
    <message>
        <location filename="canualesview.cpp" line="58"/>
        <source>Archivo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CambiaCuentaBase</name>
    <message>
        <location filename="cambiactabase.ui" line="16"/>
        <source>Cambiar Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="44"/>
        <source>Asiento Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="81"/>
        <source>Asiento Inicial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="118"/>
        <source>Fecha Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="155"/>
        <source>Fecha Inicial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="192"/>
        <source>Cuenta Destino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="229"/>
        <source>Cuenta Origen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="277"/>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cambiactabase.ui" line="287"/>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CuentaBase</name>
    <message>
        <location filename="cuentabase.ui" line="13"/>
        <source>Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="178"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="208"/>
        <source>Duplicar Asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="250"/>
        <source>Cargar Asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="304"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="344"/>
        <source>&amp;Datos contables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="359"/>
        <source>Datos de la cuenta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="403"/>
        <source>Cuenta padre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="451"/>
        <source>Nombre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="461"/>
        <source>Grupo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="484"/>
        <source>Opciones de cuenta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="504"/>
        <source>node&amp;be</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="507"/>
        <source>Alt+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="514"/>
        <source>&amp;bloqueada</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="cuentabase.ui" line="521"/>
        <source>Reg&amp;ularizaciÃ³n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="528"/>
        <source>nohaber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="535"/>
        <source>&amp;Imputacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="538"/>
        <source>Alt+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="550"/>
        <source>Tipo de cuenta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="570"/>
        <source>&amp;Neto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="577"/>
        <source>Sin &amp;Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="584"/>
        <source>A&amp;ctivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="587"/>
        <source>Alt+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="594"/>
        <source>&amp;Ingreso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="601"/>
        <source>&amp;Gasto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="604"/>
        <source>Alt+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="611"/>
        <source>&amp;Pasivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="614"/>
        <source>Alt+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="626"/>
        <source>Saldos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1731"/>
        <source>C.P.:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1761"/>
        <source>C.I.F.:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1771"/>
        <source>Nombre de la entidad:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1828"/>
        <source>Comentarios:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1871"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1889"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="121"/>
        <source>Guardar cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="136"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="163"/>
        <source>Nueva cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="289"/>
        <source>Borrar cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="429"/>
        <source>Codigo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1133"/>
        <source>Debe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1143"/>
        <source>Haber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1661"/>
        <source>&amp;Otros datos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1676"/>
        <source>URL de la pagina web:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1689"/>
        <source>Correo electronico:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1702"/>
        <source>Codigo cuenta corriente.:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1741"/>
        <source>Direccion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentabase.ui" line="1751"/>
        <source>Telefono:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DiarioBase</name>
    <message>
        <location filename="diariobase.ui" line="13"/>
        <source>Diario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="366"/>
        <source>&amp;Incluir asientos abiertos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="285"/>
        <source>Apuntes con contrapartida:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="110"/>
        <source>Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="144"/>
        <source>Mostrar/ocultar filtro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="184"/>
        <source>Configurar listado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="224"/>
        <source>Actualizar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="298"/>
        <source>Apuntes con saldo inferior a:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="308"/>
        <source>Apuntes con saldo superior a:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="318"/>
        <source>Fecha final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="328"/>
        <source>Fecha inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="418"/>
        <source>Total Debe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariobase.ui" line="497"/>
        <source>Total Haber:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DiarioPrintBase</name>
    <message encoding="UTF-8">
        <location filename="diarioprintbase.ui" line="16"/>
        <source>ImpresiÃ³n del Diario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="40"/>
        <source>&amp;Texto Plano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="53"/>
        <source>HT&amp;ML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="66"/>
        <source>&amp;Kugar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="79"/>
        <source>Propietario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="174"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="164"/>
        <source>&amp;Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="28"/>
        <source>Documento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="92"/>
        <source>Formato del listado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="104"/>
        <source>Formato &amp;normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioprintbase.ui" line="114"/>
        <source>&amp;Formato de aprendizaje</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DiarioSubForm</name>
    <message>
        <location filename="diariosubform.cpp" line="54"/>
        <source>idcuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="35"/>
        <source>codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="36"/>
        <source>tipocuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="92"/>
        <source>Borrar registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="95"/>
        <source>Ajustar columa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="96"/>
        <source>Ajustar altura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="97"/>
        <source>Ajustar columnas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="98"/>
        <source>Ajustar alturas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="100"/>
        <source>Ver configurador de subformulario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="30"/>
        <source>idborrador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="31"/>
        <source>codigoborrador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="55"/>
        <source>orden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="33"/>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="34"/>
        <source>Concepto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="37"/>
        <source>descripcion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="39"/>
        <source>Debe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="40"/>
        <source>Haber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="41"/>
        <source>Contrapartida</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="42"/>
        <source>Comentario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="43"/>
        <source>Canal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="44"/>
        <source>MarcaConciliacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="45"/>
        <source>Centro Coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="46"/>
        <source>Factura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="47"/>
        <source>idapunte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="48"/>
        <source>idtipoiva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="49"/>
        <source>idregistroiva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="50"/>
        <source>idasiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="51"/>
        <source>idcanal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="52"/>
        <source>idc_coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="53"/>
        <source>iddiario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diariosubform.cpp" line="38"/>
        <source>descripcion Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DiarioView</name>
    <message>
        <location filename="diarioview.cpp" line="117"/>
        <source>Guardar Libro Diario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="diarioview.cpp" line="119"/>
        <source>Diarios (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DuplicarAsientoBase</name>
    <message>
        <location filename="duplicarasientobase.ui" line="13"/>
        <source>Duplicar Asientos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="28"/>
        <source>Origen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="48"/>
        <source>Fecha inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="58"/>
        <source>Asiento inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="65"/>
        <source>Asiento final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="92"/>
        <source>Destino:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="duplicarasientobase.ui" line="115"/>
        <source>Fecha con la que quedarÃ¡ el asiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="139"/>
        <source>Tratamiento de la fecha:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="172"/>
        <source>Todos con la misma fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="179"/>
        <source>Mantener distacia entre fechas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="250"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="duplicarasientobase.ui" line="260"/>
        <source>&amp;Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExtractoBase</name>
    <message>
        <location filename="extractobase.ui" line="13"/>
        <source>Extracto de Cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="513"/>
        <source>Actualizar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="87"/>
        <source>&amp;Incluir asientos abiertos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="275"/>
        <source>&amp;Todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="94"/>
        <source>Apuntes con contrapartida:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="1070"/>
        <source>Totales:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="193"/>
        <source>Punteo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="55"/>
        <source>Apuntes con saldo superior a:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="77"/>
        <source>Apuntes con saldo inferior a:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="107"/>
        <source>Fecha inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="137"/>
        <source>Fecha final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="157"/>
        <source>Cuenta inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="167"/>
        <source>Cuenta final:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="245"/>
        <source>Apuntes &amp;no punteados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="260"/>
        <source>Ap&amp;untes punteados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="359"/>
        <source>Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="399"/>
        <source>Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="433"/>
        <source>Mostrar/Oculatar filtro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="473"/>
        <source>Configurar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="569"/>
        <source>Casacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="603"/>
        <source>Guardar punteo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="637"/>
        <source>Cargar punteo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="671"/>
        <source>Borrar punteo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="723"/>
        <source>Saldo inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="730"/>
        <source>Cuenta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="737"/>
        <source>Haber inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="744"/>
        <source>Debe inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="812"/>
        <source>Nombre de la cuenta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="1088"/>
        <source>Debe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="1101"/>
        <source>Haber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractobase.ui" line="1169"/>
        <source>Saldo:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExtractoPrintBase</name>
    <message encoding="UTF-8">
        <location filename="extractoprintbase.ui" line="16"/>
        <source>ImpresiÃ³n del Extracto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoprintbase.ui" line="64"/>
        <source>&amp;Texto Plano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoprintbase.ui" line="82"/>
        <source>HT&amp;ML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoprintbase.ui" line="97"/>
        <source>Propietario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoprintbase.ui" line="159"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoprintbase.ui" line="149"/>
        <source>&amp;Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoprintbase.ui" line="36"/>
        <source>Formato:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExtractoSubForm</name>
    <message>
        <location filename="extractosubform.cpp" line="38"/>
        <source>idcuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="39"/>
        <source>codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="40"/>
        <source>tipocuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="85"/>
        <source>Borrar registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="88"/>
        <source>Ajustar columa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="89"/>
        <source>Ajustar altura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="90"/>
        <source>Ajustar columnas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="91"/>
        <source>Ajustar alturas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="93"/>
        <source>Ver configurador de subformulario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="31"/>
        <source>punteo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="32"/>
        <source>idapunte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="33"/>
        <source>codigoborrador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="34"/>
        <source>idasiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="35"/>
        <source>iddiario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="36"/>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="37"/>
        <source>Concepto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="41"/>
        <source>Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="42"/>
        <source>Debe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="43"/>
        <source>Haber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="44"/>
        <source>contrapartida</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="45"/>
        <source>comentario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="46"/>
        <source>idcanal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="47"/>
        <source>Canal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="48"/>
        <source>marcaconciliacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="49"/>
        <source>idc_coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="50"/>
        <source>idtipoiva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractosubform.cpp" line="51"/>
        <source>orden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FPagoBase</name>
    <message>
        <location filename="fpagobase.ui" line="246"/>
        <source>Plazo del primer recibo (dias):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="13"/>
        <source>Formas de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="73"/>
        <source>Nueva forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="104"/>
        <source>Borrar forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="135"/>
        <source>Guardar forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="183"/>
        <source>Forma de pago:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="204"/>
        <source>Datos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="225"/>
        <source>Nombre de la forma de pago:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="264"/>
        <source>Numero de plazos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="285"/>
        <source>Tipo plazo primer pago:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="303"/>
        <source>Plazo entre recibos (dias):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagobase.ui" line="321"/>
        <source>Tipo plazo entre recibos:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListConfiguracionSubForm</name>
    <message>
        <location filename="propiedadesempresa.cpp" line="144"/>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="145"/>
        <source>Valor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListCuentasBase</name>
    <message>
        <location filename="listcuentasbase.ui" line="136"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="166"/>
        <source>Editar cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="226"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="460"/>
        <source>S&amp;ubcuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="15"/>
        <source>Plan de cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="121"/>
        <source>Nueva cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="181"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="211"/>
        <source>Borrar cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="248"/>
        <source>Imprimir cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="263"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="293"/>
        <source>Exportar cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="335"/>
        <source>Importar cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="377"/>
        <source>Actualizar listado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="392"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="listcuentasbase.ui" line="428"/>
        <source>BÃºsqueda:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasbase.ui" line="444"/>
        <source>Plan &amp;contable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListLinAsiento1View</name>
    <message>
        <location filename="listlinasiento1view.cpp" line="33"/>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="37"/>
        <source>Concepto contable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="50"/>
        <source>Id cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="34"/>
        <source>Codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="51"/>
        <source>Tipo de cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="35"/>
        <source>Descripcion de la cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="36"/>
        <source>Descripcion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="38"/>
        <source>Debe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="39"/>
        <source>Haber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="40"/>
        <source>Contrapartida</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="41"/>
        <source>Comentario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="42"/>
        <source>ID Canal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="43"/>
        <source>Conciliacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="44"/>
        <source>Id centro de coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="45"/>
        <source>Id apunte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="46"/>
        <source>Id tipo de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="47"/>
        <source>Orden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="48"/>
        <source>Id borrador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="49"/>
        <source>Id asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="86"/>
        <source>Borrar registro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="88"/>
        <source>Ajustar columa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="89"/>
        <source>Ajustar altura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="90"/>
        <source>Ajustar columnas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="91"/>
        <source>Ajustar alturas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="93"/>
        <source>Ver configurador de subformulario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="71"/>
        <source>Mostrar asiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="73"/>
        <source>Mostrar extracto (dia)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="74"/>
        <source>Mostrar extracto (mes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="75"/>
        <source>Mostrar extracto (ano)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="77"/>
        <source>Mostrar balance (dia)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="78"/>
        <source>Mostrar balance (mes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="79"/>
        <source>Mostrar balance (ano)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="81"/>
        <source>Mostrar balance jerarquico (dia)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="82"/>
        <source>Mostrar balance jerarquico (mes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listlinasiento1view.cpp" line="83"/>
        <source>Mostrar balance jerarquico (ano)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MPatrimonialBase</name>
    <message>
        <location filename="mpatrimonialbase.ui" line="186"/>
        <source>Masa Patrimonial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="49"/>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="56"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="69"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="89"/>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="133"/>
        <source>Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="377"/>
        <source>Agregar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="384"/>
        <source>Quitar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="321"/>
        <source>Suman</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="401"/>
        <source>Restan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialbase.ui" line="430"/>
        <source>Comentarios</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MPatrimonialesBase</name>
    <message>
        <location filename="mpatrimonialesbase.ui" line="13"/>
        <source>Masas Patrimoniales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialesbase.ui" line="49"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialesbase.ui" line="66"/>
        <source>Nuevo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialesbase.ui" line="73"/>
        <source>Borrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialesbase.ui" line="80"/>
        <source>Editar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialesbase.ui" line="87"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Mod300ps</name>
    <message>
        <location filename="modelo300.cpp" line="148"/>
        <source>Creando formulario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300.cpp" line="148"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Modelo300Base</name>
    <message>
        <location filename="modelo300base.ui" line="16"/>
        <source>Modelo 300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="42"/>
        <source>Periodo a declarar</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modelo300base.ui" line="49"/>
        <source>Seleccione periodo de declaraciÃ³n</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modelo300base.ui" line="53"/>
        <source>1Âº trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modelo300base.ui" line="58"/>
        <source>2Âº trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modelo300base.ui" line="63"/>
        <source>3Âº trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modelo300base.ui" line="68"/>
        <source>4Âº trimestre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="78"/>
        <source>Cuenta a devolver:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="96"/>
        <source>0123456789</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="134"/>
        <source>1234</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="153"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="169"/>
        <source>Personalizada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="176"/>
        <source>En el banco</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="197"/>
        <source>Generar borrador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="204"/>
        <source>Vista Previa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300base.ui" line="211"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Modelo347Base</name>
    <message>
        <location filename="modelo347base.ui" line="14"/>
        <source>Listado para el modelo 347</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="179"/>
        <source>Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="129"/>
        <source>Recalcular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="283"/>
        <source>Ventas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="299"/>
        <source>Compras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="104"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="141"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="194"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="246"/>
        <source>Fecha inicial:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="256"/>
        <source>Importe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo347base.ui" line="269"/>
        <source>Fecha final:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropiedadesEmpresaBase</name>
    <message>
        <location filename="propiedadesempresabase.ui" line="16"/>
        <source>Propiedades de la empresa</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="propiedadesempresabase.ui" line="161"/>
        <source>xxxx --&gt; DÃ­gitos de plan contable.
yyyy --&gt; DÃ­gitos de cuenta.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresabase.ui" line="192"/>
        <source>Modi&amp;ficar plan contable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresabase.ui" line="67"/>
        <source>Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresabase.ui" line="82"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="propiedadesempresabase.ui" line="117"/>
        <source>DÃ­&amp;gitos de cuentas</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="propiedadesempresabase.ui" line="129"/>
        <source>Modelo del cÃ³digo de cuenta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="propiedadesempresabase.ui" line="144"/>
        <source>DÃ­gitos estanda&amp;r</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresabase.ui" line="231"/>
        <source>Propiedades generales</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="modelo300.cpp" line="133"/>
        <source>Formulario 300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300.cpp" line="102"/>
        <source>Generar de todas formas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300.cpp" line="102"/>
        <source>Volver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300.cpp" line="101"/>
        <source>Aviso: El numero de cuenta bancario introducido
no se corresponde con un CCC correcto.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300.cpp" line="137"/>
        <source>Lo siento, no encuentro el formulario original en pdf.
Pruebe a descargarlo desde www.aeat.es y guaedelo en
/usr/share/bulmages/formularios/ o en
~/.bulmages/formularios/.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modelo300.cpp" line="138"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegIvaPrintBase</name>
    <message encoding="UTF-8">
        <location filename="regivaprintbase.ui" line="16"/>
        <source>ImpresiÃ³n del Registro de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="28"/>
        <source>Datos del listado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="56"/>
        <source>Fecha Inicial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="86"/>
        <source>Fecha Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="126"/>
        <source>Incluir resultados parciales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="148"/>
        <source>Formato:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="168"/>
        <source>Texto Plano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="178"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="185"/>
        <source>Postscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="213"/>
        <source>Imprimir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="regivaprintbase.ui" line="223"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectCCosteBase</name>
    <message>
        <location filename="selectccostebase.ui" line="13"/>
        <source>Selector de Centros de Coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccostebase.ui" line="55"/>
        <source>Invertir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccostebase.ui" line="62"/>
        <source>S. Nada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccostebase.ui" line="69"/>
        <source>S. Todo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccostebase.ui" line="76"/>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectCanalBase</name>
    <message>
        <location filename="selectcanalbase.ui" line="13"/>
        <source>Selector de Canales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalbase.ui" line="36"/>
        <source>S. Nada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalbase.ui" line="43"/>
        <source>Invertir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalbase.ui" line="50"/>
        <source>S. Todo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalbase.ui" line="57"/>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SobreBase</name>
    <message>
        <location filename="sobrebase.ui" line="502"/>
        <source>Acerca de BulmaCont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sobrebase.ui" line="573"/>
        <source>Contabilidad GPL - Version 0.9.1 -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sobrebase.ui" line="605"/>
        <source>&amp;Acerca de</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sobrebase.ui" line="628"/>
        <source>A&amp;utores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sobrebase.ui" line="649"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sobrebase.ui" line="660"/>
        <source>Sopor&amp;te</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sobrebase.ui" line="683"/>
        <source>Acuerdo de &amp;licencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sobrebase.ui" line="730"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Splash</name>
    <message>
        <location filename="splashscreen.cpp" line="111"/>
        <source>Comprobando nivel de combustible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="112"/>
        <source>Calibrando los lasers del lector de CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="117"/>
        <source>Haciendo PING contra el servidor de la MetaBase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="118"/>
        <source>Dejando tiempo libre al sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="119"/>
        <source>Sincronizando fases Alfa Beta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="115"/>
        <source>Golpecitos de reajuste del HD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="113"/>
        <source>Comprobando la disquetera y la memoria fisica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="114"/>
        <source>Induciendo energia quantica, entre su RAM y su ROM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="116"/>
        <source>Probando la velocidad del ventilador de la CPU y su frecuencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="120"/>
        <source>Flusheando datos con vidas inteligentes superiores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="121"/>
        <source>Permutando las tablas de particion del Sistema Operativo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="40"/>
        <source>&lt;center&gt;&lt;font size=+1 color=&quot;#fff8a1&quot;&gt;BulmaCont&lt;/font&gt;&amp;nbsp;&lt;font color=&quot;#ff5e00&quot;&gt;0.9.1&lt;/font&gt;&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splashscreen.cpp" line="122"/>
        <source>Crackeando BulmaCont</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubForm2Bc</name>
    <message>
        <location filename="subform2bc.cpp" line="280"/>
        <source>Submenu de contabilidad</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TipoIvaBase</name>
    <message>
        <location filename="tipoivabase.ui" line="13"/>
        <source>Tipos de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivabase.ui" line="174"/>
        <source>Tipo de IVA:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="tipoivabase.ui" line="195"/>
        <source>InformaciÃ³n del tipo de IVA:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivabase.ui" line="239"/>
        <source>Nombre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivabase.ui" line="257"/>
        <source>Porcentaje:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivabase.ui" line="275"/>
        <source>Cuenta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivabase.ui" line="315"/>
        <source>&amp;Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivabase.ui" line="322"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>aplinteligentesview</name>
    <message>
        <location filename="aplinteligentesview.cpp" line="498"/>
        <source>Error al crear el asiento</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>asientosview</name>
    <message>
        <location filename="asientosview.cpp" line="140"/>
        <source>Asientos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asientosview.cpp" line="46"/>
        <source>(todos)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>canaldlg</name>
    <message>
        <location filename="canalbase.ui" line="16"/>
        <source>Canales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalbase.ui" line="190"/>
        <source>Canal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="canalbase.ui" line="227"/>
        <source>InformaciÃ³n del canal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalbase.ui" line="247"/>
        <source>Nombre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="canalbase.ui" line="267"/>
        <source>DescripciÃ³n:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalbase.ui" line="306"/>
        <source>&amp;Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>canalview</name>
    <message>
        <location filename="canalview.cpp" line="121"/>
        <source>Desea guardar los cambios.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="163"/>
        <source>Guardar canal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="122"/>
        <source>&amp;Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="165"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="142"/>
        <source>Borrar canal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="144"/>
        <source>Se va a borrar la forma de pago,
                                     Esto puede ocasionar perdida de datos
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="145"/>
        <source>&amp;Borrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="164"/>
        <source>Desea guardar los cambios?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="165"/>
        <source>&amp;Si</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="canalview.cpp" line="165"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ccostedlg</name>
    <message>
        <location filename="ccostebase.ui" line="13"/>
        <source>Centros de Coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="197"/>
        <source>Imprimir pedido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="249"/>
        <source>Contenido del centro de coste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="269"/>
        <source>Nombre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ccostebase.ui" line="297"/>
        <source>DescripciÃ³n:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="336"/>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="97"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="128"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="159"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccostebase.ui" line="212"/>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ccosteview</name>
    <message>
        <location filename="ccosteview.cpp" line="42"/>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="211"/>
        <source>Guardar centro de coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="212"/>
        <source>Desea guardar los cambios?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="119"/>
        <source>&amp;Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="213"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="192"/>
        <source>Borrar centro de coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="193"/>
        <source>Se va a borrar el centro de coste.
Esta operacion puede ocasionar perdida de datos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="194"/>
        <source>&amp;Borrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="213"/>
        <source>&amp;Si</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="213"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="42"/>
        <source>Descripcion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ccosteview.cpp" line="42"/>
        <source>Id centro de coste</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cuentaview</name>
    <message>
        <location filename="cuentaview.cpp" line="148"/>
        <source>Guardar cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentaview.cpp" line="149"/>
        <source>Desea guardar los cambios?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentaview.cpp" line="150"/>
        <source>&amp;Si</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentaview.cpp" line="150"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentaview.cpp" line="150"/>
        <source>&amp;Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentaview.cpp" line="193"/>
        <source>Cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentaview.cpp" line="431"/>
        <source>Borrar cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="cuentaview.cpp" line="432"/>
        <source>Se va a borrar la cuenta,
Esto puede ocasionar perdida de datos
Tal vez deberia pensarselo mejor antes
porque igual su trabajo se pierde.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extractoview1</name>
    <message>
        <location filename="extractoview1.cpp" line="170"/>
        <source>Diarios (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoview1.cpp" line="371"/>
        <source>Punteos (*.pto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoview1.cpp" line="168"/>
        <source>Guardar libro diario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoview1.cpp" line="369"/>
        <source>Guardar punteo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoview1.cpp" line="399"/>
        <source>Borrar punteo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoview1.cpp" line="402"/>
        <source>Se dispone a borrar el punteo. Este cambio                                         es irrecuperable si no ha guardado su el punte.                                         Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoview1.cpp" line="423"/>
        <source>Cargar punteo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="extractoview1.cpp" line="425"/>
        <source>Punteo (*.pto)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fpagoview</name>
    <message>
        <location filename="fpagoview.cpp" line="200"/>
        <source>Guardar forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagoview.cpp" line="201"/>
        <source>Desea guardar los cambios?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagoview.cpp" line="180"/>
        <source>Borrar forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagoview.cpp" line="162"/>
        <source>Nueva forma de pago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagoview.cpp" line="176"/>
        <source>Tiene que seleccionar una forma de pago antes de borrarla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fpagoview.cpp" line="181"/>
        <source>Se va a borrar la forma de pago.
Esto puede ocasionar perdida de datos.
Tal vez deberia pensarselo mejor antes
porque igual su trabajo se pierde.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>listcuentasview1</name>
    <message>
        <location filename="listcuentasview1.cpp" line="78"/>
        <source>CODIGO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="78"/>
        <source>NOMBRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Codigo cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Nombre cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Debe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Haber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>ID cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Bloqueada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Nodebe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Nohaber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Regularizacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Imputacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Grupo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="52"/>
        <source>Tipo cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="344"/>
        <source>Debe seleccionar una cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="348"/>
        <source>Borrar cuenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="349"/>
        <source>Se procedera a borrar la cuenta.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="486"/>
        <source>Elija el archivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="listcuentasview1.cpp" line="488"/>
        <source>Plan contable (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mpatrimonialesview</name>
    <message>
        <location filename="mpatrimonialesview.cpp" line="62"/>
        <source>CODIGO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialesview.cpp" line="62"/>
        <source>Masa patrimonial</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mpatrimonialview</name>
    <message>
        <location filename="mpatrimonialview.cpp" line="37"/>
        <source>identificador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialview.cpp" line="37"/>
        <source>codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialview.cpp" line="37"/>
        <source>descripcion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mpatrimonialview.cpp" line="37"/>
        <source>tipo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>propiedadesempresa</name>
    <message>
        <location filename="propiedadesempresa.cpp" line="89"/>
        <source>Guardar cambios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="90"/>
        <source>Desea guardar los cambios?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="91"/>
        <source>&amp;Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="91"/>
        <source>&amp;No guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="128"/>
        <source>Salir del programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="129"/>
        <source>Para que los cambios tengan efecto
debe salir del programa y volver a entrar.

Salir ahora?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="130"/>
        <source>&amp;Salir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="propiedadesempresa.cpp" line="130"/>
        <source>&amp;No salir</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>selectcanalview</name>
    <message>
        <location filename="selectcanalview.cpp" line="40"/>
        <source>nom_canal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalview.cpp" line="40"/>
        <source>desc_canal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalview.cpp" line="40"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalview.cpp" line="40"/>
        <source>idcanal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectcanalview.cpp" line="40"/>
        <source>Seleccion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>selectccosteview</name>
    <message>
        <location filename="selectccosteview.cpp" line="37"/>
        <source>nom_coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccosteview.cpp" line="37"/>
        <source>desc_coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccosteview.cpp" line="37"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccosteview.cpp" line="37"/>
        <source>idc_coste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectccosteview.cpp" line="37"/>
        <source>Seleccion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sobreview</name>
    <message>
        <location filename="sobreview.cpp" line="36"/>
        <source>Compilado usando la version de QT:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tipoivaview</name>
    <message>
        <location filename="tipoivaview.cpp" line="173"/>
        <source>Guardar tipo de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivaview.cpp" line="174"/>
        <source>Desea guardar los cambios?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivaview.cpp" line="151"/>
        <source>Borrar tipo de IVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tipoivaview.cpp" line="152"/>
        <source>Se va a borrar el tipo de IVA. 
Esto puede ocasionar perdida de datos.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
